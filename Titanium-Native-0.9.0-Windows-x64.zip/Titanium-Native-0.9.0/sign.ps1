# Signs an already assembled executable using a certificate in the Windows store.
# Private keys and passwords never belong in this repository.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$File,
 [Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{40}$')][string]$Thumbprint,
 [string]$SignTool = 'signtool.exe',
 [string]$TimestampUrl = 'https://timestamp.digicert.com'
)
$ErrorActionPreference = 'Stop'
$resolved = (Resolve-Path -LiteralPath $File).Path
if (!(Get-Command $SignTool -ErrorAction SilentlyContinue)) {
 throw 'Install Windows SDK Signing Tools and pass -SignTool with the path to signtool.exe.'
}
& $SignTool sign /sha1 $Thumbprint /fd SHA256 /tr $TimestampUrl /td SHA256 /d 'Titanium Studio - Oxide Studios' $resolved
if ($LASTEXITCODE -ne 0) { throw 'Authenticode signing failed. The file must not be published as signed.' }
& $SignTool verify /pa /all /v $resolved
if ($LASTEXITCODE -ne 0) { throw 'Authenticode verification failed.' }
$status = Get-AuthenticodeSignature -LiteralPath $resolved
if ($status.Status -ne 'Valid') { throw "Windows trust verification failed: $($status.Status)" }
Write-Output "Verified signature: $($status.SignerCertificate.Subject)"
