# Podpis wydawcy Oxide Studios

Nazwa firmy w zasobach EXE nie jest podpisem kryptograficznym. Bieżące wydanie nie ma zaufanego podpisu: właściciel nie ma jeszcze certyfikatu. Nie używamy certyfikatu samopodpisanego jako substytutu zaufanej tożsamości.

Na Windows zainstaluj certyfikat podpisywania kodu wydany dla uprawnionego wydawcy i Windows SDK Signing Tools. Klucz prywatny pozostaje w magazynie/urządzeniu dostawcy. Nie zapisuj PFX, haseł ani kluczy w repozytorium.

Po ostatecznym zbudowaniu/wyeksportowaniu EXE:

```powershell
./tools/sign.ps1 -File ./wydanie/Titanium-Native-0.9.0.exe -Thumbprint ODCISK_CERTYFIKATU -SignTool 'C:/sciezka/signtool.exe'
```

W paczce binarnej skrypt jest bezpośrednio w folderze głównym. Podpisuje SHA-256, żąda znacznika czasu RFC3161 i sprawdza podpis przez SignTool oraz Get-AuthenticodeSignature. Używa magazynu bieżącego użytkownika. Sprzętowe klucze mogą wymagać interakcji dostawcy. Nazwa podpisującego wynika z certyfikatu, a nie z pola CompanyName.

Każdy eksportowany program trzeba podpisać oddzielnie po eksporcie. Edycja kodu albo ponowny eksport unieważnia poprzedni podpis, dlatego pakowanie usuwa metadane starego podpisu z kopiowanej bazy. Czytnik programu rozpoznaje tabelę certyfikatów PE i poprzedzające ją dopełnienie, aby nadal odnajdywać kod Titanium. Nie zastępuje to weryfikacji zaufania podpisu przez Windows.

Podpisz EXE przed przygotowaniem końcowego ZIP-a i odtwórz listę SHA-256 po podpisaniu. release.py tworzy paczkę niepodpisaną z nowymi eksportami; nie zachowuje podpisu Studia w zmodyfikowanych demach. Podpisuj końcowe pliki w rozpakowanej paczce, następnie przelicz SUMY-SHA256.txt i spakuj ją ponownie. Nie publikuj starych sum dla zmienionych EXE.
