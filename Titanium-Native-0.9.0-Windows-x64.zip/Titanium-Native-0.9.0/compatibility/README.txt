ZGODNOSC HISTORYCZNA TITANIUM 0.1 I 0.2

Titanium-0.1.html i Titanium-0.2.html sa niezmienionymi, samodzielnymi
srodowiskami HTML z historycznych paczek zrodlowych. Dzialaja offline
w aktualnej przegladarce z Canvas 2D, Web Audio i TextDecoder.
Otwarcie tych plikow pozwala edytowac, wczytac i uruchomic stare programy.

0.1: oryginalny Titanium-0.1/Titanium.html, 71299 bajtow
SHA-256: 6ef80dfc1116fa27c4daa7f0d675314a57f6340d56b984b1ef0d295d822e8000
0.2: oryginalny Titanium-Studio-0.2/Titanium-Start.html, 69727 bajtow
SHA-256: b549e4ef7f06a76ba875f52620823c49f6de498bf1d75ce2497da945b19bfea8

Wybierz dokladna wersje dla starego programu. Wersja 0.2 wprowadzila m.in.
polecenia gra/sterowanie/monety i wywolania bez nawiasow; 0.1 ma wlasne
oryginalne reguly. Kod z 0.1/0.2 nie jest kompilowany do natywnej maszyny
wirtualnej 0.3+. Dotyczy to m.in. list, pol obiektow, zdarzen, fizyki,
losowania, rysowania i limitow. Zachowujemy oryginalny interpreter oraz
silnik gry zamiast obiecywac identyczne zachowanie innego silnika.

Automatyczne rozpoznawanie jest tylko konserwatywna podpowiedzia. Niejednoznaczny
kod pozostaje w trybie natywnym; uzyj jawnego wyboru 0.1 lub 0.2. Dotyczy to
np. podstawowego pisz, losuj i polecen majacych te sama nazwe w obu jezykach.
Jawny wybor daje dostep do calego oryginalnego jezyka, z jego oryginalnymi
ograniczeniami i bledami. Nie obiecujemy zgodnosci kazdego programu ze starymi
wersjami przegladarek ani zachowania funkcji historycznej powloki Windows.

Uruchamianie z nowego edytora tworzy tymczasowy plik HTML, wstawia zrodlo
jako dane base64, odtwarza UTF-8, ustawia oryginalny edytor i naciska jego
Uruchom. Ten sam mechanizm eksportuje samodzielny plik HTML. Kod Titanium
nie jest wstawiany jako JavaScript, nawet gdy zawiera </script> lub znaki
U+2028/U+2029. Uruchomienie otwiera domyslna przegladarke. Plik tymczasowy
pozostaje w systemowym katalogu plikow tymczasowych, aby przegladarka mogla
go pozniej odczytac lub przeladowac.

Eksport HTML zachowuje przegladarkowe srodowisko; nie udaje natywnego EXE.
Historyczny przycisk Eksport EXE w HTML 0.2 wymaga dawnej powloki Windows
i nie stanowi sposobu eksportu z nowego edytora. Dzwiek wlacza sie recznie.

original-0.1/ i original-0.2/ zawieraja niezmienione moduly, przyklady
i testy zrodlowe do weryfikacji (nie sa potrzebne do uruchomienia HTML).
Sprawdzenie: node compatibility/verify.cjs
Wymaga Node.js i kompilatora C (zmienna CC lub cc); bez npm i bez internetu.
Test sprawdza sumy obu HTML, bezpieczne przeniesienie zrodla, rozpoznawanie
skladni oraz wszystkie 54 oryginalne testy obu interpreterow i silnikow.
