/* Run from any directory: node compatibility/verify.cjs. No npm dependencies. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict'),crypto=require('node:crypto'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'titanium-legacy-'));
function run(command,args){const p=spawnSync(command,args,{cwd:root,stdio:'inherit'});if(p.error)throw p.error;assert.equal(p.status,0,command+' failed');}
try{
 const cc=process.env.CC||'cc';
 run(cc,['-std=c11','-Wno-misleading-indentation','src/legacy.c','tests/legacy.c','-o',path.join(temp,'scanner')]);run(path.join(temp,'scanner'),[]);
 const helper=path.join(temp,'export.c');
 fs.writeFileSync(helper,`#include "legacy.h"
#include <stdlib.h>
int main(int n,char **a){if(n!=4)return 2;char error[256];FILE *h=fopen(a[1],"rb"),*s=fopen(a[2],"rb"),*o=fopen(a[3],"wb");if(!h||!s||!o)return 3;fseek(h,0,SEEK_END);long hn=ftell(h);rewind(h);fseek(s,0,SEEK_END);long sn=ftell(s);rewind(s);char *html=malloc(hn),*source=malloc(sn);if(fread(html,1,hn,h)!=(size_t)hn||fread(source,1,sn,s)!=(size_t)sn)return 4;int ok=ti_legacy_write_html(o,html,hn,source,sn,error);fclose(h);fclose(s);fclose(o);free(html);free(source);return !ok;}
`);
 run(cc,['-std=c11','-Wno-misleading-indentation','-Isrc','src/legacy.c',helper,'-o',path.join(temp,'export')]);
 const value='</script><script>globalThis.PWNED=1</script> łódź \u2028\u2029',source='pisz('+JSON.stringify(value)+')\n';
 fs.writeFileSync(path.join(temp,'source.ti'),source);
 const hashes={'0.1':'6ef80dfc1116fa27c4daa7f0d675314a57f6340d56b984b1ef0d295d822e8000','0.2':'b549e4ef7f06a76ba875f52620823c49f6de498bf1d75ce2497da945b19bfea8'};
 for(const version of ['0.1','0.2']){
  const original=fs.readFileSync(path.join(__dirname,'Titanium-'+version+'.html'));
  assert.equal(crypto.createHash('sha256').update(original).digest('hex'),hashes[version],'original HTML changed');
  const output=path.join(temp,version+'.html');run(path.join(temp,'export'),[path.join(__dirname,'Titanium-'+version+'.html'),path.join(temp,'source.ti'),output]);
  const html=fs.readFileSync(output,'utf8'),tag="<script>\n(()=>{'use strict';const bytes=Uint8Array.from(atob('",start=html.indexOf(tag),end=html.indexOf('</script>',start);
  assert(start>=0&&end>start);const hook=html.slice(start+8,end);
  assert(!hook.includes('PWNED'));assert(!hook.includes('łódź'));assert(!hook.includes('\u2028'));assert(!hook.includes('\u2029'));
  assert.equal(Buffer.from(hook.match(/atob\('([^']*)'\)/)[1],'base64').toString('utf8'),source);
  let changed=0,clicked=0;const out=[],T=require('./original-'+version+'/src/titanium.js'),editor={value:'',dispatchEvent(e){assert.equal(e.type,'input');changed++;}},button={click(){clicked++;new T.Runtime(editor.value,{pisz:s=>out.push(s)}).run();}};
  const sandbox={Uint8Array,TextDecoder,atob,Event:class {constructor(type){this.type=type;}},document:{querySelector:s=>s==='#code'?editor:s==='#run'?button:null}};
  vm.runInNewContext(hook,sandbox,{timeout:1000});assert.equal(editor.value,source);assert.equal(changed,1);assert.equal(clicked,1);assert.deepEqual(out,[value]);assert.equal(sandbox.PWNED,undefined);
  console.log('Original '+version+' checksum and source loader safety: OK');
 }
 const tests=[];for(const version of ['0.1','0.2'])for(const f of fs.readdirSync(path.join(__dirname,'original-'+version,'tests')))if(f.endsWith('.test.cjs'))tests.push(path.join(__dirname,'original-'+version,'tests',f));
 run(process.execPath,['--test',...tests]);
}finally{fs.rmSync(temp,{recursive:true,force:true});}
