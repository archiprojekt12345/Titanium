/* Titanium 0.1 — własny lekser, parser i interpreter AST. Brak eval. */
(function (root) {
'use strict';
const norm=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').replace(/Ł/g,'L');
const VALIDATE_WRITE=Symbol('Titanium.validateWrite');
class TiError extends Error {
 constructor(message,line=1){super(`Wiersz ${line}: ${message}`);this.name='Błąd Titanium';this.line=line;}
}
function fail(message,line){throw new TiError(message,line);}
function tokenize(source){
 if(source.length>250000)fail('Program jest za długi (maksymalnie 250 000 znaków).');
 const out=[];let p=0,line=1,depth=0;
 const push=(type,value,l=line)=>out.push({type,value,line:l});
 while(p<source.length){
  let c=source[p];
  if(c===' '||c==='\t'||c==='\r'){p++;continue;}
  if(c==='\n'){if(!depth)push('nl','\n');line++;p++;continue;}
  if(c==='#'){while(p<source.length&&source[p]!=='\n')p++;continue;}
  if(c==='"'||c==="'"){
   const quote=c,l=line;let s='';p++;let closed=false;
   while(p<source.length){c=source[p++];if(c===quote){closed=true;break;}
    if(c==='\n')fail('Niedomknięty napis. Zamknij cudzysłów.',l);
    if(c==='\\'){if(p>=source.length)break;let e=source[p++];const esc={n:'\n',t:'\t',r:'\r','\\':'\\','"':'"',"'":"'"};if(!(e in esc))fail('Nieznana sekwencja po znaku \\.',l);s+=esc[e];}else s+=c;
   }
   if(!closed)fail('Niedomknięty napis. Zamknij cudzysłów.',l);push('literal',s,l);continue;
  }
  if(/[0-9]/.test(c)){
   const start=p;while(/[0-9]/.test(source[p]||''))p++;
   if(source[p]==='.'&&/[0-9]/.test(source[p+1]||'')){p++;while(/[0-9]/.test(source[p]||''))p++;}
   const n=Number(source.slice(start,p));if(!Number.isFinite(n))fail('Liczba jest za duża.',line);push('literal',n);continue;
  }
  if(/[\p{L}_]/u.test(c)){
   const start=p++;while(/[\p{L}\p{N}_]/u.test(source[p]||''))p++;
   push('id',norm(source.slice(start,p)));continue;
  }
  const pair=source.slice(p,p+2);
  if(['==','!=','<=','>='].includes(pair)){push('op',pair);p+=2;continue;}
  if('+-*/%<>=(),.[]'.includes(c)){
   if(c==='('||c==='[')depth++;
   if(c===')'||c===']'){depth--;if(depth<0)fail('Nadmiarowy nawias zamykający.',line);}
   push('op',c);p++;continue;
  }
  fail(`Nie rozumiem znaku „${c}”.`,line);
 }
 push('nl','\n');push('eof','');return out;
}
const PREC={lub:1,i:2,'==':3,'!=':3,'<':4,'>':4,'<=':4,'>=':4,'+':5,'-':5,'*':6,'/':6,'%':6};
class Parser {
 constructor(source){this.tokens=tokenize(source);this.pos=0;this.fn=0;this.blocks=0;this.exprDepth=0;}
 peek(){return this.tokens[this.pos];}
 is(value){return this.peek().value===value;}
 take(){return this.tokens[this.pos++];}
 expect(value){if(!this.is(value))fail(`Oczekuję „${value}”, jest „${this.peek().value||'koniec pliku'}”.`,this.peek().line);return this.take();}
 name(){const t=this.take();if(t.type!=='id'||['koniec','inaczej','jesli','dla','w','co','funkcja','zwroc','powtorz','dopoki','prawda','falsz','nic','i','lub','nie'].includes(t.value))fail('Oczekuję nazwy zmiennej lub funkcji.',t.line);return t.value;}
 newline(){if(this.peek().type!=='nl'&&this.peek().type!=='eof')fail('Zakończ polecenie i zacznij następny wiersz.',this.peek().line);while(this.peek().type==='nl')this.take();}
 block(stops=[]){
  if(++this.blocks>80)fail('Za dużo zagnieżdżonych bloków (limit 80).',this.peek().line);
  const body=[];while(this.peek().type==='nl')this.take();
  while(this.peek().type!=='eof'&&!stops.includes(this.peek().value)){body.push(this.statement());while(this.peek().type==='nl')this.take();}
  this.blocks--;return body;
 }
 statement(){
  const t=this.peek(),line=t.line;let n;
  if(this.is('jesli')){
   this.take();const cond=this.expression();this.newline();const yes=this.block(['inaczej','koniec']);let no=[];
   if(this.is('inaczej')){this.take();this.newline();no=this.block(['koniec']);}
   this.expect('koniec');n={kind:'if',cond,yes,no,line};
  }else if(this.is('powtorz')||this.is('dopoki')){
   const kind=this.take().value==='powtorz'?'repeat':'while',value=this.expression();this.newline();const body=this.block(['koniec']);this.expect('koniec');n={kind,value,body,line};
  }else if(this.is('dla')){
   this.take();const name=this.name();this.expect('w');const value=this.expression();this.newline();const body=this.block(['koniec']);this.expect('koniec');n={kind:'for',name,value,body,line};
  }else if(this.is('funkcja')){
   this.take();const name=this.name();this.expect('(');const args=[];
   if(!this.is(')')){do{if(args.length)this.expect(',');args.push(this.name());}while(this.is(','));}
   if(new Set(args).size!==args.length)fail('Parametry funkcji muszą mieć różne nazwy.',line);
   this.expect(')');this.newline();this.fn++;const body=this.block(['koniec']);this.fn--;this.expect('koniec');n={kind:'function',name,args,body,line};
  }else if(this.is('zwroc')){
   this.take();if(!this.fn)fail('„zwróć” używaj wewnątrz funkcji.',line);
   const value=this.peek().type==='nl'?{kind:'literal',value:null,line}:this.expression();n={kind:'return',value,line};
  }else if(this.is('co')){
   if(this.blocks!==1)fail('Zdarzenia „co” umieszczaj poza funkcjami i innymi blokami.',line);
   this.take();let interval=null;
   if(this.is('klatke'))this.take();else {interval=this.expression();if(!['sekund','sekundy','sekunde'].includes(this.take().value))fail('Napisz: co 1 sekundę',line);}
   this.newline();const body=this.block(['koniec']);this.expect('koniec');n={kind:'event',interval,body,line};
  }else{
   const target=this.expression();
   if(this.is('=')){
    this.take();if(!['name','member','index'].includes(target.kind))fail('Po lewej stronie przypisania podaj zmienną, pole albo indeks listy.',line);
    n={kind:'assign',target,value:this.expression(),line};
   }else n={kind:'expr',value:target,line};
  }
  this.newline();return n;
 }
 expression(min=0){
  if(++this.exprDepth>100)fail('Wyrażenie jest zbyt głęboko zagnieżdżone (limit 100).',this.peek().line);
  let left=this.primary();
  while(Object.hasOwn(PREC,this.peek().value)&&PREC[this.peek().value]>=min){const t=this.take();const right=this.expression(PREC[t.value]+1);left={kind:'binary',op:t.value,left,right,line:t.line};}
  this.exprDepth--;return left;
 }
 primary(){
  const t=this.take(),line=t.line;let n;
  if(t.type==='literal')n={kind:'literal',value:t.value,line};
  else if(['-','+','nie'].includes(t.value))n={kind:'unary',op:t.value,value:this.expression(7),line};
  else if(['prawda','falsz','nic'].includes(t.value))n={kind:'literal',value:t.value==='nic'?null:t.value==='prawda',line};
  else if(t.value==='('){n=this.expression();this.expect(')');}
  else if(t.value==='['){const values=[];if(!this.is(']')){do{if(values.length)this.expect(',');values.push(this.expression());}while(this.is(','));}this.expect(']');n={kind:'array',values,line};}
  else if(t.type==='id')n={kind:'name',name:t.value,line};
  else fail('Oczekuję liczby, napisu, nazwy albo wyrażenia.',line);
  while(true){
   if(this.is('(')){this.take();const args=[];if(!this.is(')')){do{if(args.length)this.expect(',');args.push(this.expression());}while(this.is(','));}this.expect(')');n={kind:'call',callee:n,args,line};}
   else if(this.is('.')){this.take();n={kind:'member',object:n,key:this.name(),line};}
   else if(this.is('[')){this.take();const index=this.expression();this.expect(']');n={kind:'index',object:n,index,line};}
   else break;
  }
  return n;
 }
}
class Env {
 constructor(parent=null){this.parent=parent;this.values=Object.create(null);}
 own(k){return Object.hasOwn(this.values,k);}
 get(k){if(this.own(k))return this.values[k];if(this.parent)return this.parent.get(k);throw new Error(`Nie znam nazwy „${k}”. Najpierw nadaj jej wartość.`);}
 define(k,v){if(this.locked)throw new Error('Nazwy poleceń wbudowanych są chronione.');this.values[k]=v;}
 set(k,v){if(this.own(k)){this.define(k,v);return;}if(this.parent&&this.parent.has(k)){this.parent.set(k,v);return;}this.define(k,v);}
 has(k){return this.own(k)||!!this.parent?.has(k);}
}
class Returned {constructor(value){this.value=value;}}
const forbidden=new Set(['__proto__','prototype','constructor']);
function num(v){if(typeof v!=='number'||!Number.isFinite(v))throw new Error('Oczekuję skończonej liczby.');return v;}
function list(v){if(!Array.isArray(v))throw new Error('Oczekuję listy.');return v;}
function safeValue(v){if(typeof v==='number'&&!Number.isFinite(v))throw new Error('Wynik obliczenia nie jest skończoną liczbą.');if(typeof v==='string'&&v.length>1000000)throw new Error('Przekroczono limit długości napisu.');return v;}
class Runtime {
 constructor(source,host={},options={}){
  this.ast=new Parser(source).block();this.limit=options.budget??60000;this.steps=0;this.depth=0;this.time=0;this.events=[];
  this.builtins=new Env();this.globals=new Env(this.builtins);
  const builtins={
   pisz:(...args)=>console.log(...args),
   dlugosc:v=>{if(!Array.isArray(v)&&typeof v!=='string')throw new Error('długość wymaga listy lub napisu.');return v.length;},
   dodaj:(xs,v)=>{list(xs);if(xs.length>=10000)throw new Error('Przekroczono limit listy (10 000).');xs.push(v);return xs.length;},
   usun:(xs,v)=>{list(xs);const i=xs.indexOf(v);if(i>=0)xs.splice(i,1);return null;},
   losuj:(a=0,b=1)=>num(a)+Math.random()*(num(b)-a),
   calkowita:v=>Math.floor(num(v)),pierwiastek:v=>safeValue(Math.sqrt(num(v))),
   sin:v=>Math.sin(num(v)),cos:v=>Math.cos(num(v)),abs:v=>Math.abs(num(v)),
   minimum:(...v)=>Math.min(...v.map(num)),maksimum:(...v)=>Math.max(...v.map(num)),
   ogranicz:(v,a,b)=>Math.max(num(a),Math.min(num(b),num(v))),
   napis:v=>this.display(v),
   liczba:v=>{if(typeof v!=='string'&&typeof v!=='number')throw new Error('liczba wymaga napisu albo liczby.');if(v==='')throw new Error('Pusty napis nie jest liczbą.');return safeValue(Number(v));}
  };
  for(const [k,v] of Object.entries({...builtins,...host}))this.builtins.define(norm(k),v);
  this.builtins.locked=true;
  this.globals.define('delta',0);this.globals.define('czas',0);this.globals.define('pi',Math.PI);
 }
 display(v){
  const seen=new Set();let left=4093,nodes=200;const parts=[];
  const append=s=>{if(left<=0)return;const piece=s.slice(0,left);parts.push(piece);left-=piece.length;};
  const visit=(value,depth=0)=>{
   if(left<=0)return;
   if(--nodes<=0||depth>10){append('…');return;}
   if(Array.isArray(value)){
    if(seen.has(value)){append('[…]');return;}seen.add(value);append('[');
    for(let j=0;j<Math.min(value.length,100)&&left>0;j++){if(j)append(', ');visit(value[j],depth+1);if(nodes<=0)break;}
    if(value.length>100||nodes<=0)append(', …');append(']');return;
   }
   if(value===true)append('prawda');else if(value===false)append('fałsz');else if(value===null)append('nic');
   else if(typeof value==='function')append('[funkcja wbudowana]');else if(value?.kind==='ti-function')append('[funkcja]');
   else if(value&&typeof value==='object')append('[obiekt]');else append(String(value));
  };
  visit(v);if(left<=0)parts.push('…');return parts.join('');
 }
 tick(line){if(++this.steps>this.limit)fail(`Przekroczono limit ${this.limit} kroków. Sprawdź pętle lub podziel pracę na klatki.`,line);}
 wrap(node,fn){try{return fn();}catch(e){if(e instanceof TiError||e instanceof Returned)throw e;fail(e.message||'Nie udało się wykonać polecenia.',node.line);}}
 run(){this.steps=0;this.execute(this.ast,this.globals);return this;}
 frame(dt){
  num(dt);if(dt<0||dt>1)fail('Czas klatki musi mieścić się między 0 a 1 sekundą.');
  this.steps=0;this.time+=dt;this.globals.define('delta',dt);this.globals.define('czas',this.time);
  for(const event of this.events){
   if(event.interval===null)this.execute(event.body,this.globals);
   else {event.elapsed+=dt;let catchup=0;while(event.elapsed+1e-10>=event.interval&&catchup++<8){event.elapsed-=event.interval;this.execute(event.body,this.globals);}if(catchup>8)event.elapsed=0;}
  }
 }
 execute(body,env){for(const n of body)this.statement(n,env);}
 statement(n,env){this.tick(n.line);return this.wrap(n,()=>{
  switch(n.kind){
   case 'assign':{const v=this.value(n.value,env),t=n.target;if(t.kind==='name'){
    if(env===this.globals&&this.builtins.own(t.name))throw new Error('Ta nazwa jest poleceniem wbudowanym. Wybierz inną nazwę.');env.set(t.name,v);
   }else {const obj=this.value(t.object,env),key=t.kind==='member'?t.key:this.value(t.index,env);this.property(obj,key,true);if(Object.hasOwn(obj,VALIDATE_WRITE))obj[VALIDATE_WRITE](key,v);obj[key]=v;}break;}
   case 'expr':this.value(n.value,env);break;
   case 'if':this.execute(this.value(n.cond,env)?n.yes:n.no,env);break;
   case 'repeat':{const count=num(this.value(n.value,env));if(!Number.isInteger(count)||count<0)throw new Error('Liczba powtórzeń musi być nieujemną liczbą całkowitą.');for(let j=0;j<count;j++){this.tick(n.line);this.execute(n.body,env);}break;}
   case 'while':while(this.value(n.value,env)){this.tick(n.line);this.execute(n.body,env);}break;
   case 'for':{const xs=list(this.value(n.value,env)).slice();for(const v of xs){this.tick(n.line);env.set(n.name,v);this.execute(n.body,env);}break;}
   case 'function':if(env===this.globals&&this.builtins.own(n.name))throw new Error('Ta nazwa jest poleceniem wbudowanym. Wybierz inną nazwę.');env.define(n.name,{kind:'ti-function',args:n.args,body:n.body,closure:env});break;
   case 'return':throw new Returned(this.value(n.value,env));
   case 'event':{const interval=n.interval===null?null:num(this.value(n.interval,env));if(interval!==null&&interval<.01)throw new Error('Odstęp zdarzenia to co najmniej 0.01 sekundy.');this.events.push({interval,elapsed:0,body:n.body});break;}
  }
 });}
 property(obj,key,write=false){
  if(Array.isArray(obj)){if(!Number.isInteger(key)||key<0||key>=obj.length)throw new Error('Indeks listy poza zakresem. Numerujemy od 0.');return obj[key];}
  if(!obj||typeof obj!=='object'||obj.kind==='ti-function'||typeof key!=='string'||forbidden.has(key)||!Object.hasOwn(obj,key))throw new Error(`Brak dostępu do pola „${String(key)}” tego obiektu.`);
  if(![null, Object.prototype].includes(Object.getPrototypeOf(obj)))throw new Error('Brak dostępu do tego obiektu.');
  if(typeof obj[key]==='function')throw new Error('Brak dostępu do metod hosta.');
  return obj[key];
 }
 value(n,env){this.tick(n.line);return this.wrap(n,()=>{
  switch(n.kind){
   case 'literal':return n.value;
   case 'name':return env.get(n.name);
   case 'array':if(n.values.length>10000)throw new Error('Przekroczono limit listy.');return n.values.map(v=>this.value(v,env));
   case 'member':return this.property(this.value(n.object,env),n.key);
   case 'index':return this.property(this.value(n.object,env),this.value(n.index,env));
   case 'unary':{const v=this.value(n.value,env);return n.op==='nie'?!v:n.op==='-'?-num(v):num(v);}
   case 'binary':{
    const a=this.value(n.left,env);if(n.op==='i')return a?this.value(n.right,env):a;if(n.op==='lub')return a?a:this.value(n.right,env);
    const b=this.value(n.right,env);
    switch(n.op){
     case '+':return safeValue(typeof a==='string'||typeof b==='string'?this.display(a)+this.display(b):num(a)+num(b));
     case '-':return safeValue(num(a)-num(b));case '*':return safeValue(num(a)*num(b));
     case '/':case '%':num(a);num(b);if(b===0)throw new Error('Nie można dzielić przez zero.');return safeValue(n.op==='/'?a/b:a%b);
     case '==':return a===b;case '!=':return a!==b;
     case '<':case '>':case '<=':case '>=':if(!(typeof a==='number'&&typeof b==='number'||typeof a==='string'&&typeof b==='string'))throw new Error('Porównuj dwie liczby albo dwa napisy.');return n.op==='<'?a<b:n.op==='>'?a>b:n.op==='<='?a<=b:a>=b;
    }break;
   }
   case 'call':{
    const f=this.value(n.callee,env),args=n.args.map(v=>this.value(v,env));
    if(typeof f==='function')return safeValue(f(...args)??null);
    if(f?.kind!=='ti-function')throw new Error('Ta wartość nie jest funkcją.');
    if(args.length!==f.args.length)throw new Error(`Funkcja oczekuje ${f.args.length} argumentów, podano ${args.length}.`);
    if(this.depth>=80)throw new Error('Przekroczono limit rekurencji (80 wywołań).');
    const local=new Env(f.closure);f.args.forEach((name,j)=>local.define(name,args[j]));this.depth++;
    try{this.execute(f.body,local);}catch(e){if(e instanceof Returned)return e.value;throw e;}finally{this.depth--;}
    return null;
   }
  }
 });}
}
const api={Runtime,Parser,tokenize,TiError,Env,norm,num,VALIDATE_WRITE};root.Titanium=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
