const {test}=require('node:test');
const a=require('node:assert/strict');
const T=require('../src/titanium.js');
function run(code,opts={}) {const out=[];const r=new T.Runtime(code,{pisz:(...v)=>out.push(v.join(' '))},opts);r.run();return {out,r};}
test('arytmetyka, komentarze, polskie nazwy i priorytet',()=>{a.deepEqual(run('żółw = 2 + 3 * 4\npisz(żółw, "# tekst") # komentarz').out,['14 # tekst']);});
test('warunki i krótkie spięcie',()=>{a.deepEqual(run('jeśli nie fałsz i (2 < 3)\n pisz("tak")\ninaczej\n pisz("nie")\nkoniec\npisz(prawda lub brak)').out,['tak','true']);});
test('pętle, listy, indeksy i iteracja po kopii',()=>{a.deepEqual(run('lista = [2, 3, 4]\nsuma = 0\ndla n w lista\n suma = suma + n\nkoniec\npowtórz 2\n suma = suma + 1\nkoniec\ndopóki suma < 12\n suma = suma + 1\nkoniec\nlista[0] = suma\npisz(lista[0])').out,['12']);});
test('funkcje, rekurencja i lokalne zmienne',()=>{const {out,r}=run('wynik = 0\nfunkcja silnia(n)\n jeśli n <= 1\n  zwróć 1\n koniec\n lokalna = n\n zwróć lokalna * silnia(n - 1)\nkoniec\nwynik = silnia(6)\npisz(wynik)');a.deepEqual(out,['720']);a.throws(()=>r.globals.get('lokalna'),/Nie znam/);});
test('zdarzenia klatkowe i czasowe',()=>{const {r}=run('n = 0\nco klatkę\n n = n + 1\nkoniec\nco 0.1 sekundy\n n = n + 10\nkoniec');r.frame(.05);r.frame(.05);a.equal(r.globals.get('n'),12);});
test('wariant bez polskich znaków',()=>a.deepEqual(run('jesli prawda\n powtorz 2\n pisz("OK")\n koniec\nkoniec').out,['OK','OK']));
test('błędy mają wiersze',()=>{a.throws(()=>run('a = 2\npisz(nieznana)'),/Wiersz 2.*Nie znam/);a.throws(()=>run('x = 1 / 0'),/Wiersz 1.*zero/);a.throws(()=>run('jeśli prawda\npisz(1)'),/koniec/);});
test('pętla i rekurencja przerywane limitem',()=>{a.throws(()=>run('dopóki prawda\nx = 1\nkoniec',{budget:200}),/limit/i);a.throws(()=>run('funkcja f()\n zwróć f()\nkoniec\nf()'),/rekurencji/);});
test('brak dostępu do hosta i prototypów',()=>{a.throws(()=>run('pisz.constructor("return process")()'),/pole|dostęp|obiektu/i);a.throws(()=>run('pisz(window)'),/Nie znam/);});
test('zwróć wyłącznie wewnątrz funkcji',()=>a.throws(()=>run('zwróć 4'),/funkcji/));
test('ujemne indeksy, typy i błędne przypisanie',()=>{a.throws(()=>run('x = [1]\npisz(x[-1])'),/indeks/i);a.throws(()=>run('x = "tekst" - 2'),/liczb/i);a.throws(()=>run('2 = 3'),/przypis/i);});
test('poleceń hosta nie można nadpisać z funkcji ani przez iterator',()=>{for(const source of ['funkcja psuj()\n dlugosc = 7\nkoniec\npsuj()','dla dlugosc w [7]\n pisz(1)\nkoniec','funkcja dlugosc(x)\n zwroc 0\nkoniec'])a.throws(()=>run(source),/wbudowan|chronion/);a.deepEqual(run('funkcja f(liczba)\n liczba = liczba + 1\n zwróć liczba\nkoniec\npisz(f(2))').out,['3']);});
test('formatowanie współdzielonych i cyklicznych list ma ograniczony rozmiar',()=>{const {r}=run('x = "x"\npowtórz 24\n x = [x, x]\nkoniec');const result=r.display(r.globals.get('x'));a.ok(result.length<5000);const cycle=[];cycle.push(cycle);a.ok(r.display(cycle).length<20);});
test('konsola skraca duże listy podczas formatowania',()=>{const {r}=run('x = []\npowtórz 100\n dodaj(x, "0123456789")\nkoniec');const big=Array(100).fill('x'.repeat(65536));a.ok(r.display(big).length<=4096);});
