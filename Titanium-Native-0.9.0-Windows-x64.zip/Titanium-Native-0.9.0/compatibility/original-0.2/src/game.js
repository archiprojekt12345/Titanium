/* Biblioteka 2D Titanium: geometria, obiekty, wejście, Canvas i dźwięk. */
(function(root){
'use strict';
const T=typeof module!=='undefined'?require('./titanium.js'):root.Titanium;
const num=T.num;
function radius(v){num(v);if(v<=0||v>2000)throw new Error('Niepoprawny promien: podaj liczbę od 0 do 2000 (bez zera).');return v;}
function color(v){if(typeof v!=='string'||v.length>80)throw new Error('Kolor podaj jako krótki napis, np. "#48e6ba".');return v;}
function object(o){if(!o||typeof o!=='object'||!Object.hasOwn(o,'aktywny'))throw new Error('Oczekuję obiektu gry utworzonego przez postać.');return o;}
class Game {
 constructor(canvas=null){
  this.canvas=canvas;this.ctx=canvas?.getContext('2d')??null;this.width=960;this.height=600;this.entities=[];this.particles=[];this.draws=[];this.keys=new Set();this.mouse={x:640,y:300,down:false};this.background='#08141d';this.shake=0;this.clock=0;this.nextId=1;this.muted=true;this.audio=null;this.lastSound=0;
  this.beginner=null;this.hasAnimation=false;this.title='Titanium';
  this.api={
   gra:(title='Moja gra')=>this.startSimple(title),
   sterowanie:(speed=250)=>{num(speed);if(speed<0||speed>2000)throw new Error('Podaj szybkość od 0 do 2000.');if(!this.beginner)this.startSimple('Moja gra');this.beginner.speed=speed;return null;},
   monety:(count=6)=>{num(count);if(!Number.isInteger(count)||count<0||count>100)throw new Error('Liczba monet musi być całkowita od 0 do 100.');if(!this.beginner)this.startSimple('Moja gra');for(const e of this.api.obiekty('moneta'))e.aktywny=false;for(let n=0;n<count;n++){const coin=this.spawn(40+Math.random()*880,90+Math.random()*460,11,'#ffe5a3');coin.rodzaj='moneta';}return null;},
   postac:(x,y,r,c)=>this.spawn(x,y,r,c),
   obiekty:kind=>this.entities.filter(e=>e.aktywny&&e.rodzaj===kind),
   zniszcz:o=>{object(o).aktywny=false;return null;},
   kolizja:(a,b)=>{object(a);object(b);return a.aktywny&&b.aktywny&&Math.hypot(a.x-b.x,a.y-b.y)<=a.r+b.r;},
   trafienie:(p,e)=>this.hit(p,e),
   odleglosc:(a,b)=>{object(a);object(b);return Math.hypot(a.x-b.x,a.y-b.y);},
   przesun:(o,x,y)=>{object(o);o.x+=num(x);o.y+=num(y);return null;},
   celuj:(o,x,y,s)=>{object(o);const dx=num(x)-o.x,dy=num(y)-o.y,d=Math.hypot(dx,dy)||1;num(s);o.vx=dx/d*s;o.vy=dy/d*s;o.kat=Math.atan2(dy,dx);return null;},
   strzel:(o,x,y,s=650,c='#ffe5a3')=>{object(o);const p=this.spawn(o.x,o.y,4,c);p.rodzaj='pocisk';p.czas=1.5;this.api.celuj(p,x,y,s);return p;},
   klawisz:key=>{if(typeof key!=='string')throw new Error('Klawisz podaj jako napis.');return this.keys.has(key.toLowerCase());},
   os:(plus,minus)=>(this.api.klawisz(plus)?1:0)-(this.api.klawisz(minus)?1:0),
   mysz:()=>this.mouse.down,
   wybuch:(x,y,c,n=24)=>this.burst(x,y,c,n),
   drganie:n=>{this.shake=Math.max(0,Math.min(30,num(n)));return null;},
   dzwiek:(hz=440,seconds=.06)=>this.tone(hz,seconds),
   tlo:c=>{this.background=color(c);return null;},
   tekst:(value,x,y,size=20,c='#e1edf5')=>{if(typeof value!=='string'&&typeof value!=='number'&&typeof value!=='boolean')throw new Error('tekst wymaga napisu, liczby lub wartości logicznej. Listę zamień poleceniem napis().');return this.draw({kind:'text',value:String(value).slice(0,500),x:num(x),y:num(y),size:Math.max(8,Math.min(150,num(size))),color:color(c)});},
   linia:(x,y,x2,y2,c='#345064')=>this.draw({kind:'line',x:num(x),y:num(y),x2:num(x2),y2:num(y2),color:color(c)}),
   kolo:(x,y,r,c='#48e6ba')=>this.draw({kind:'circle',x:num(x),y:num(y),r:radius(r),color:color(c)})
  };
 }
 startSimple(title){
  if(typeof title!=='string'||title.length>80)throw new Error('Tytuł gry podaj jako napis do 80 znaków.');
  if(this.beginner){this.beginner.player.aktywny=false;for(const e of this.api.obiekty('moneta'))e.aktywny=false;}
  this.title=title;const player=this.spawn(480,300,17,'#50edbe');player.rodzaj='gracz';this.beginner={player,speed:250,score:0};this.hasAnimation=true;return player;
 }
 spawn(x,y,r,c){
  num(x);num(y);radius(r);color(c);
  if(this.entities.length>=1200){this.entities=this.entities.filter(e=>e.aktywny);if(this.entities.length>=1200)throw new Error('Przekroczono limit obiektów (1200).');}
  const e=Object.assign(Object.create(null),{id:this.nextId++,x,y,r,kolor:c,vx:0,vy:0,kat:0,rodzaj:'obiekt',aktywny:true,zycie:1,obrazenia:1,czas:-1,wartosc:0,poprzednie_x:x,poprzednie_y:y});
  Object.defineProperty(e,T.VALIDATE_WRITE,{value:(key,value)=>{
   try{const type=typeof e[key];if(typeof value!==type)throw new Error(`Wymagany typ: ${type==='number'?'liczba':type==='boolean'?'wartość logiczna':'napis'}.`);if(type==='number')num(value);if(key==='r')radius(value);if(type==='string')color(value);}
   catch(err){throw new Error(`Pole „${key}”: ${err.message}`);}
  }});
  this.entities.push(e);return e;
 }
 hit(p,e){
  object(p);object(e);if(!p.aktywny||!e.aktywny)return false;
  const ax=p.poprzednie_x,ay=p.poprzednie_y,bx=p.x,by=p.y,dx=bx-ax,dy=by-ay;
  const t=Math.max(0,Math.min(1,((e.x-ax)*dx+(e.y-ay)*dy)/(dx*dx+dy*dy||1)));
  return Math.hypot(e.x-(ax+t*dx),e.y-(ay+t*dy))<=p.r+e.r;
 }
 draw(command){if(this.draws.length>=2000)throw new Error('Przekroczono limit rysowania w klatce (2000).');this.draws.push(command);return null;}
 beginFrame(){this.draws=[];}
 update(dt){
  num(dt);if(dt<0||dt>1)throw new Error('Czas aktualizacji musi być między 0 a 1 sekundą.');this.clock+=dt;
  if(this.beginner){
   const b=this.beginner,p=b.player;let dx=this.api.os('d','a')+this.api.os('arrowright','arrowleft'),dy=this.api.os('s','w')+this.api.os('arrowdown','arrowup');const len=Math.max(1,Math.hypot(dx,dy));
   p.x=Math.max(25,Math.min(935,p.x+dx/len*b.speed*dt));p.y=Math.max(80,Math.min(570,p.y+dy/len*b.speed*dt));if(dx||dy)p.kat=Math.atan2(dy,dx);
   for(const coin of this.api.obiekty('moneta'))if(this.api.kolizja(p,coin)){b.score++;this.burst(coin.x,coin.y,coin.kolor,24);this.tone(850,.08);coin.x=40+Math.random()*880;coin.y=90+Math.random()*460;}
  }
  for(const e of this.entities){
   if(!e.aktywny)continue;
   for(const k of ['x','y','r','vx','vy','kat','czas'])num(e[k]);
   radius(e.r);color(e.kolor);
   e.poprzednie_x=e.x;e.poprzednie_y=e.y;e.x+=e.vx*dt;e.y+=e.vy*dt;
   if(e.czas>=0){e.czas-=dt;if(e.czas<=0)e.aktywny=false;}
  }
  this.entities=this.entities.filter(e=>e.aktywny);
  for(const p of this.particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;p.vx*=Math.exp(-3*dt);p.vy*=Math.exp(-3*dt);}
  this.particles=this.particles.filter(p=>p.life>0);this.shake*=Math.exp(-12*dt);
 }
 burst(x,y,c,n){
  num(x);num(y);color(c);num(n);const count=Math.max(0,Math.min(120,Math.floor(n),1800-this.particles.length));
  for(let j=0;j<count;j++){const a=Math.random()*Math.PI*2,s=40+Math.random()*170;this.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.25+Math.random()*.5,max:.75,color:c});}return null;
 }
 enableAudio(){
  if(!this.audio&&typeof root.AudioContext==='function')this.audio=new root.AudioContext();
  if(this.audio?.state==='suspended')this.audio.resume().catch(()=>{});
 }
 tone(hz,seconds){
  num(hz);num(seconds);if(this.muted||!this.audio)return null;
  const now=this.audio.currentTime;if(now-this.lastSound<.025)return null;this.lastSound=now;
  const o=this.audio.createOscillator(),gain=this.audio.createGain();o.type='triangle';o.frequency.setValueAtTime(Math.max(40,Math.min(4000,hz)),now);
  gain.gain.setValueAtTime(.035,now);gain.gain.exponentialRampToValueAtTime(.001,now+Math.max(.02,Math.min(.5,seconds)));o.connect(gain);gain.connect(this.audio.destination);o.start(now);o.stop(now+Math.max(.02,Math.min(.5,seconds)));return null;
 }
 render(){
  const ctx=this.ctx;if(!ctx)return;const w=this.width,h=this.height;
  ctx.save();ctx.fillStyle=this.background;ctx.fillRect(0,0,w,h);
  ctx.translate((Math.random()-.5)*this.shake,(Math.random()-.5)*this.shake);
  const glow=ctx.createRadialGradient(w*.5,h*.5,0,w*.5,h*.5,w*.7);glow.addColorStop(0,'#173a482d');glow.addColorStop(1,'#01060a70');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#8bd6de0b';ctx.lineWidth=1;ctx.beginPath();for(let x=0;x<=w;x+=40){ctx.moveTo(x,0);ctx.lineTo(x,h);}for(let y=0;y<=h;y+=40){ctx.moveTo(0,y);ctx.lineTo(w,y);}ctx.stroke();
  ctx.strokeStyle='#3a857b55';ctx.strokeRect(14,14,w-28,h-28);
  for(const e of this.entities){
   if(!e.aktywny)continue;ctx.save();ctx.translate(e.x,e.y);ctx.shadowBlur=e.rodzaj==='pocisk'?15:12;ctx.shadowColor=e.kolor;ctx.fillStyle=e.kolor;ctx.strokeStyle=e.kolor;ctx.lineWidth=2;
   if(e.rodzaj==='gracz'){
    ctx.rotate(e.kat);ctx.beginPath();ctx.moveTo(e.r+7,0);ctx.lineTo(-e.r,-e.r*.75);ctx.lineTo(-e.r*.5,0);ctx.lineTo(-e.r,e.r*.75);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#f0fffa';ctx.beginPath();ctx.arc(0,0,4,0,Math.PI*2);ctx.fill();
   }else if(e.rodzaj==='apteczka'){
    ctx.rotate(Math.sin(this.clock*3)*.15);ctx.fillStyle='#48e6ba22';ctx.fillRect(-12,-12,24,24);ctx.strokeRect(-12,-12,24,24);ctx.fillStyle=e.kolor;ctx.fillRect(-3,-8,6,16);ctx.fillRect(-8,-3,16,6);
   }else if(e.rodzaj==='wrog'||e.rodzaj==='wróg'){
    ctx.rotate(this.clock*.5+e.id);ctx.beginPath();for(let j=0;j<6;j++){const a=j*Math.PI/3;ctx.lineTo(Math.cos(a)*e.r,Math.sin(a)*e.r);}ctx.closePath();ctx.fillStyle=e.kolor+'33';ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(0,0,e.r*.35,0,Math.PI*2);ctx.fillStyle=e.kolor;ctx.fill();
   }else{
    if(e.rodzaj==='pocisk'){ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-e.vx*.018,-e.vy*.018);ctx.stroke();}
    ctx.beginPath();ctx.arc(0,0,e.r,0,Math.PI*2);ctx.fill();
   }
   ctx.restore();
  }
  for(const p of this.particles){ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.fillRect(p.x-2,p.y-2,3,3);}ctx.globalAlpha=1;
  // Celownik jest elementem biblioteki wejścia; zasady trafiania definiuje skrypt.
  ctx.strokeStyle='#d5fff47f';ctx.lineWidth=1;ctx.beginPath();ctx.arc(this.mouse.x,this.mouse.y,9,0,Math.PI*2);ctx.moveTo(this.mouse.x-15,this.mouse.y);ctx.lineTo(this.mouse.x-5,this.mouse.y);ctx.moveTo(this.mouse.x+5,this.mouse.y);ctx.lineTo(this.mouse.x+15,this.mouse.y);ctx.moveTo(this.mouse.x,this.mouse.y-15);ctx.lineTo(this.mouse.x,this.mouse.y-5);ctx.moveTo(this.mouse.x,this.mouse.y+5);ctx.lineTo(this.mouse.x,this.mouse.y+15);ctx.stroke();ctx.restore();
  for(const d of this.draws){ctx.fillStyle=d.color;ctx.strokeStyle=d.color;
   if(d.kind==='text'){ctx.font=`${d.size>=30?'600':'500'} ${d.size}px system-ui, sans-serif`;ctx.textBaseline='top';ctx.fillText(d.value,d.x,d.y);}
   else if(d.kind==='line'){ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x2,d.y2);ctx.stroke();}
   else {ctx.beginPath();ctx.arc(d.x,d.y,d.r,0,Math.PI*2);ctx.fill();}
  }
  if(this.beginner){ctx.textBaseline='top';ctx.font='600 25px system-ui, sans-serif';ctx.fillStyle='#e5fcf2';ctx.fillText(this.title,30,25);ctx.font='500 19px system-ui, sans-serif';ctx.fillStyle='#ffe5a3';ctx.fillText('PUNKTY  '+this.beginner.score,760,30);ctx.font='13px system-ui, sans-serif';ctx.fillStyle='#8db8be';ctx.fillText('WASD lub strzałki / zbieraj złote monety',30,575);}
 }
}
root.TitaniumGame={Game};if(typeof module!=='undefined')module.exports={Game};
})(globalThis);
