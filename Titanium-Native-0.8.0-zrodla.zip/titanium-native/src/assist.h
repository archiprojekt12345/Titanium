#ifndef TI_ASSIST_H
#define TI_ASSIST_H
#include <stddef.h>
#include <wchar.h>
const char *ti_assist_word(size_t index);
const char *ti_assist_complete(const char *prefix,size_t index);
const char *ti_assist_suggest(const char *word);
int ti_assist_custom(const wchar_t *source,const wchar_t *word,size_t length);
int ti_assist_correct(const wchar_t *line,size_t length,char out[64]);
#endif
