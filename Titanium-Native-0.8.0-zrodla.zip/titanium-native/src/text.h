#ifndef TI_TEXT_H
#define TI_TEXT_H
#include <stdlib.h>
#include <wchar.h>
/* Blocks are delimited by koniec; presentation does not require indentation.
   Only line prefixes are changed, never spaces/tabs inside quoted text. */
static inline wchar_t *ti_flat_code(const wchar_t *text) {
    size_t n=wcslen(text);wchar_t *r=malloc((n+1)*sizeof *r);if(!r)return NULL;
    size_t j=0;int start=1,quoted=0,escaped=0;
    for(size_t i=0;i<n;i++){
        wchar_t c=text[i];if(start&&(c==' '||c=='\t'))continue;
        if(c=='\t'&&!quoted)c=' ';
        r[j++]=c;start=c=='\r'||c=='\n';
        if(start){quoted=escaped=0;}
        else if(c=='"'&&!escaped)quoted=!quoted;
        if(quoted&&c=='\\')escaped=!escaped;else escaped=0;
    }r[j]=0;return r;
}
/* Standard Win32 multiline EDIT controls use CRLF. Works with LF, CRLF and CR files. */
static inline wchar_t *ti_crlf(const wchar_t *text) {
    size_t n=wcslen(text);wchar_t *r=malloc((n*2+1)*sizeof *r);if(!r)return NULL;
    size_t j=0;
    for(size_t i=0;i<n;i++){
        if(text[i]=='\r'){r[j++]='\r';r[j++]='\n';if(text[i+1]=='\n')i++;}
        else if(text[i]=='\n'){r[j++]='\r';r[j++]='\n';}
        else r[j++]=text[i];
    }r[j]=0;return r;
}
#endif
