#ifndef TI_EDITOR_CORE_H
#define TI_EDITOR_CORE_H
#include <stddef.h>
#include <wchar.h>
#define TI_EDITOR_CHARS 8192
#define TI_EDITOR_SPANS 256
enum {TI_CODE_COMMAND=1,TI_CODE_GAME,TI_CODE_KEYWORD,TI_CODE_NUMBER,TI_CODE_STRING,TI_CODE_COMMENT};
typedef struct {unsigned start,end,style;} TiCodeSpan;
typedef struct {unsigned revision;long first,last;int valid;} TiEditorWork;
int ti_editor_work_needed(TiEditorWork *,unsigned revision,long first,long last);
size_t ti_editor_spans(const wchar_t *,TiCodeSpan *,size_t capacity);
#endif
