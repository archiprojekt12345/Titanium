#ifndef TI_PACKAGE_H
#define TI_PACKAGE_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
/* read: 1 valid package, 0 unbundled base, -1 corrupt/IO error. */
int ti_package_read(FILE *file,char **source,size_t *length,uint64_t *base);
int ti_package_write(FILE *base,FILE *output,const char *source,size_t length);
/* Exported programs use PE's console subsystem; editor keeps GUI subsystem. */
int ti_package_console(FILE *file);
#endif
