#include "package.h"
#include <stdlib.h>
#include <string.h>
static const unsigned char magic[16]="TITANIUM-NATIVE3";
static uint32_t checksum(const unsigned char *s,size_t n){uint32_t h=2166136261u;while(n--)h=(h^*s++)*16777619u;return h;}
static uint64_t u64(const unsigned char *s){uint64_t v=0;for(int i=7;i>=0;i--)v=(v<<8)|s[i];return v;}
static uint32_t u32(const unsigned char *s){return (uint32_t)u64((const unsigned char[8]){s[0],s[1],s[2],s[3],0,0,0,0});}
static void put(unsigned char *s,uint64_t x,int n){for(int i=0;i<n;i++){s[i]=(unsigned char)x;x>>=8;}}
int ti_package_console(FILE *f) {
    unsigned char dos[64],head[26];
    if(!f||fflush(f)||fseek(f,0,SEEK_END))return 0;long length=ftell(f);
    if(length<256||fseek(f,0,SEEK_SET)||fread(dos,1,64,f)!=64||memcmp(dos,"MZ",2))return 0;
    uint32_t offset=u32(dos+60);
    if(offset<64||offset>(uint32_t)length-94||fseek(f,(long)offset,SEEK_SET)||fread(head,1,26,f)!=26||memcmp(head,"PE\0\0",4))return 0;
    if(!((head[24]==0x0b&&head[25]==2)||(head[24]==0x0b&&head[25]==1)))return 0;
    unsigned char console[2]={3,0};return !fseek(f,(long)offset+24+68,SEEK_SET)&&fwrite(console,1,2,f)==2&&!fflush(f);
}
int ti_package_read(FILE *f,char **source,size_t *length,uint64_t *base) {
    if(!f||fseek(f,0,SEEK_END))return -1;long end=ftell(f);if(end<0)return -1;*base=(uint64_t)end;*source=NULL;*length=0;
    if(end<32)return 0;unsigned char footer[32];if(fseek(f,end-32,SEEK_SET)||fread(footer,1,32,f)!=32)return -1;
    if(memcmp(footer,magic,16))return 0;
    uint64_t b=u64(footer+16);uint32_t n=u32(footer+24),hash=u32(footer+28);
    if(!b||b>100*1024*1024||n>250000||b+n+32!=(uint64_t)end)return -1;
    char *src=malloc((size_t)n+1);if(!src)return -1;
    if(fseek(f,(long)b,SEEK_SET)||fread(src,1,n,f)!=n||checksum((unsigned char*)src,n)!=hash||memchr(src,0,n)){free(src);return -1;}
    src[n]=0;*source=src;*length=n;*base=b;return 1;
}
int ti_package_write(FILE *f,FILE *out,const char *src,size_t n) {
    if(!f||!out||n>250000||memchr(src,0,n))return 0;
    char *previous=NULL;size_t old;uint64_t base;
    int status=ti_package_read(f,&previous,&old,&base);free(previous);if(status<0||base==0||base>100*1024*1024)return 0;
    if(fseek(f,0,SEEK_SET))return 0;unsigned char buf[8192];uint64_t left=base;
    while(left){size_t k=left>sizeof buf?sizeof buf:(size_t)left;if(fread(buf,1,k,f)!=k||fwrite(buf,1,k,out)!=k)return 0;left-=k;}
    unsigned char footer[32];memcpy(footer,magic,16);put(footer+16,base,8);put(footer+24,n,4);put(footer+28,checksum((const unsigned char*)src,n),4);
    return fwrite(src,1,n,out)==n&&fwrite(footer,1,32,out)==32&&!fflush(out);
}
