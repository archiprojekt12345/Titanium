#include "physics.h"
#include <math.h>
#include <string.h>

#define EPS 0.000001
static double clamp(double v,double lo,double hi){return fmax(lo,fmin(v,hi));}
static int overlap(double a,double aw,double b,double bw){return a+aw>b+EPS&&a<b+bw-EPS;}
void ti_body_reset(TiObject *o){o->vx=o->vy=o->coyote=o->jump_buffer=0;o->grounded=0;}
static int support(const TiScene*s,const TiObject*o){
    for(unsigned j=0;j<s->count;j++){
        const TiObject*b=&s->objects[j];
        if(b==o||!b->visible||b->pinned||!b->solid)continue;
        if(fabs(o->y+o->h-b->y)<EPS&&overlap(o->x,o->w,b->x,b->w))return 1;
    }return 0;
}
int ti_physics_grounded(const TiScene*s,const TiObject*o){return o->visible&&o->body&&!o->pinned&&o->vy>=0&&support(s,o);}
/* Continuous swept AABB finds the earliest contact along the complete vector,
   then slides the unused displacement along the contacted face. */
static int move_body(TiScene*s,TiObject*o,double dx,double dy){
    int hit_x=0;o->grounded=0;
    for(int pass=0;pass<3&&(dx||dy);pass++){
        double first=2;int normal_x=0,normal_y=0;
        for(unsigned j=0;j<s->count;j++){
            TiObject*b=&s->objects[j];if(b==o||!b->visible||b->pinned||!b->solid)continue;
            double enter;int nx=0,ny=0;
            if(b->solid==2){
                if(dy<=0||o->y+o->h>b->y+EPS)continue;
                enter=(b->y-o->y-o->h)/dy;
                if(enter<0||enter>1||!overlap(o->x+dx*enter,o->w,b->x,b->w))continue;
                ny=-1;
            }else{
                double tx=-INFINITY,ty=-INFINITY,ex=INFINITY,ey=INFINITY;
                if(dx>0){tx=(b->x-o->x-o->w)/dx;ex=(b->x+b->w-o->x)/dx;}
                else if(dx<0){tx=(b->x+b->w-o->x)/dx;ex=(b->x-o->x-o->w)/dx;}
                else if(!overlap(o->x,o->w,b->x,b->w))continue;
                if(dy>0){ty=(b->y-o->y-o->h)/dy;ey=(b->y+b->h-o->y)/dy;}
                else if(dy<0){ty=(b->y+b->h-o->y)/dy;ey=(b->y-o->y-o->h)/dy;}
                else if(!overlap(o->y,o->h,b->y,b->h))continue;
                enter=fmax(tx,ty);double leave=fmin(ex,ey);
                if(enter < -EPS||enter>1||enter>leave||leave<0)continue;
                /* A simultaneous corner contact chooses the vertical face:
                   adjacent floor tiles must not snag horizontal movement. */
                if(tx>ty)nx=dx>0?-1:1;
                else ny=dy>0?-1:1;
            }
            enter=fmax(0,enter);
            if(enter<first-EPS){first=enter;normal_x=nx;normal_y=ny;}
            else if(fabs(enter-first)<EPS){if(nx)normal_x=nx;if(ny)normal_y=ny;}
        }
        if(o->controller&&dx){
            double bound=dx>0?fmax(0,s->world_width-o->w):0;
            double t=(bound-o->x)/dx;
            if(t>=0&&t<=1){if(t<first-EPS){first=t;normal_x=dx>0?-1:1;normal_y=0;}else if(fabs(t-first)<EPS)normal_x=dx>0?-1:1;}
        }
        if(first>1){o->x+=dx;o->y+=dy;break;}
        o->x+=dx*first;o->y+=dy*first;dx*=1-first;dy*=1-first;
        if(normal_x){dx=0;o->vx=0;hit_x=1;}
        if(normal_y){dy=0;o->vy=0;if(normal_y<0)o->grounded=1;}
    }
    if(o->controller)o->x=clamp(o->x,0,fmax(0,s->world_width-o->w));
    if(!o->grounded&&o->vy>=0&&support(s,o))o->grounded=1;
    return hit_x;
}
void ti_camera_update(TiScene*s){
    double zoom=s->zoom>0?s->zoom:1,vw=s->width/zoom,vh=s->height/zoom;
    if(s->camera_target[0])for(unsigned i=0;i<s->count;i++){
        TiObject*o=&s->objects[i];if(strcmp(o->name,s->camera_target))continue;
        if(!o->pinned){s->camera_x=o->x+(o->kind==TI_CIRCLE?0:o->w/2)-vw/2;s->camera_y=o->y+(o->kind==TI_CIRCLE?0:o->h/2)-vh/2;}
        break;
    }
    s->camera_x=clamp(s->camera_x,0,fmax(0,s->world_width-vw));
    s->camera_y=clamp(s->camera_y,0,fmax(0,s->world_height-vh));
}
void ti_physics_update(TiGame*g){
    double dt=g->dt;int steps=(int)ceil(dt*120);if(steps<1)steps=1;double h=dt/steps;
    for(unsigned i=0;i<g->scene.count;i++){
        TiObject*o=&g->scene.objects[i];if(!o->visible)continue;
        if(o->anim_frames>1&&o->anim_fps>0){o->anim_time=fmod(o->anim_time+dt,o->anim_frames/o->anim_fps);o->anim_frame=(int)(o->anim_time*o->anim_fps)%o->anim_frames;}
        if(!o->body||o->pinned)continue;
        if(o->controller&&g->input.keys[32]&&!g->previous.keys[32])o->jump_buffer=.12;
        for(int step=0;step<steps;step++){
            if(o->vy>=0)o->grounded=support(&g->scene,o);
            if(o->grounded)o->coyote=.10;else o->coyote=fmax(0,o->coyote-h);
            if(o->controller){
                int axis=(g->input.keys['D']||g->input.keys[39])-(g->input.keys['A']||g->input.keys[37]);
                o->vx=axis*o->walk_speed;if(axis)o->direction=axis;
                if(o->jump_buffer>0&&o->coyote>0&&o->jump_speed>0){o->vy=-o->jump_speed;o->jump_buffer=o->coyote=0;o->grounded=0;}
            }
            if(o->patrol_speed>0)o->vx=o->direction*o->patrol_speed;
            o->vy=clamp(o->vy+o->gravity*h,-2000,2000);
            int hit=move_body(&g->scene,o,o->vx*h,o->vy*h);
            if(o->patrol_speed>0){
                if(o->x<=o->patrol_min){o->x=o->patrol_min;o->direction=1;}
                else if(o->x>=o->patrol_max){o->x=o->patrol_max;o->direction=-1;}
                else if(hit)o->direction=-o->direction;
            }
            o->jump_buffer=fmax(0,o->jump_buffer-h);
            /* Keep off-screen falling bodies finite until user code respawns. */
            o->x=clamp(o->x,-1000000,1000000);o->y=clamp(o->y,-1000000,1000000);
        }
    }
    ti_camera_update(&g->scene);
}
