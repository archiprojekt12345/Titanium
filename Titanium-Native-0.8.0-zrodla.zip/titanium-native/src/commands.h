#ifndef TI_COMMANDS_H
#define TI_COMMANDS_H
#include <stdio.h>
#include <stddef.h>
typedef struct {const char *name;int min,max,prefix,game;unsigned names;const char *syntax,*description;} TiCommand;
size_t ti_command_count(void);
const TiCommand *ti_command_at(size_t index);
const TiCommand *ti_command(const char *name);
char *ti_commands_text(void);
void ti_write_commands(FILE *file);
#endif
