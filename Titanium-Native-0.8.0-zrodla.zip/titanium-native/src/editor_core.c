#include "editor_core.h"
#include "commands.h"
#include <string.h>
#include <wctype.h>
int ti_editor_work_needed(TiEditorWork*w,unsigned revision,long first,long last){
 if(w->valid&&w->revision==revision&&w->first==first&&w->last==last)return 0;
 w->valid=1;w->revision=revision;w->first=first;w->last=last;return 1;
}
static int id(wchar_t c){return iswalnum(c)||c=='_';}
static int keyword(const char*w){static const char*words[]={"ustaw","dodaj","odejmij","jesli","inaczej","koniec","zawsze","powtorz","dopoki","dla","od","do","funkcja","zwroc","prawda","falsz","nie","i","lub","rowne","rozne","wieksze","mniejsze","conajmniej","najwyzej"};for(size_t i=0;i<sizeof words/sizeof *words;i++)if(!strcmp(words[i],w))return 1;return 0;}
size_t ti_editor_spans(const wchar_t*s,TiCodeSpan*out,size_t capacity){
 size_t n=0,i=0;if(!s||!out)return 0;if(capacity>TI_EDITOR_SPANS)capacity=TI_EDITOR_SPANS;
 while(i<TI_EDITOR_CHARS&&s[i]&&n<capacity){size_t begin=i;unsigned style=0;
  if(s[i]=='#'||(s[i]=='/'&&i+1<TI_EDITOR_CHARS&&s[i+1]=='/')){while(i<TI_EDITOR_CHARS&&s[i]&&s[i]!='\r'&&s[i]!='\n')i++;style=TI_CODE_COMMENT;}
  else if(s[i]=='"'){i++;while(i<TI_EDITOR_CHARS&&s[i]&&s[i]!='\r'&&s[i]!='\n'){if(s[i]=='\\'&&i+1<TI_EDITOR_CHARS&&s[i+1]){i+=2;continue;}if(s[i++]=='"')break;}style=TI_CODE_STRING;}
  else if(iswdigit(s[i])){while(i<TI_EDITOR_CHARS&&(id(s[i])||s[i]=='.'))i++;style=TI_CODE_NUMBER;}
  else if(id(s[i])){while(i<TI_EDITOR_CHARS&&id(s[i]))i++;if(i-begin<64){char word[64];size_t k;for(k=0;k<i-begin;k++){if(s[begin+k]>127)break;word[k]=(char)towlower(s[begin+k]);}if(k==i-begin){word[k]=0;const TiCommand*c=ti_command(word);style=c?(c->game?TI_CODE_GAME:TI_CODE_COMMAND):keyword(word)?TI_CODE_KEYWORD:0;}}}
  else i++;
  if(style)out[n++]=(TiCodeSpan){(unsigned)begin,(unsigned)i,style};
 }return n;
}
