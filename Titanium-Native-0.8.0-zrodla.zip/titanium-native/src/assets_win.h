#ifndef TI_ASSETS_WIN_H
#define TI_ASSETS_WIN_H
#include <windows.h>
int ti_assets_root(const wchar_t *source_or_exe,wchar_t root[32768]);
int ti_assets_copy(const wchar_t *source_root,const wchar_t *destination_exe,wchar_t error[512]);
#endif
