#ifndef TI_VIEW_H
#define TI_VIEW_H
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "game.h"
typedef struct TiView TiView;
/* parent==NULL creates standalone top-level view; otherwise native child preview.
   owner creates inheritable mapping+mutex handles. Root is full path to assety. */
TiView *ti_view_create(HWND parent,const wchar_t *asset_root);
TiView *ti_view_connect(uintptr_t mapping,uintptr_t mutex,const wchar_t *asset_root);
HWND ti_view_hwnd(TiView *view);
void ti_view_handles(TiView *view,uintptr_t *mapping,uintptr_t *mutex);
TiHost ti_view_host(TiView *view);
void ti_view_set_root(TiView *view,const wchar_t *asset_root);
int ti_view_active(TiView *view);
int ti_view_alive(TiView *view);
void ti_view_stop(TiView *view);
void ti_view_destroy(TiView *view);
#endif
