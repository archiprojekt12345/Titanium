#ifndef TI_LEGACY_H
#define TI_LEGACY_H
#include <stddef.h>
#include <stdio.h>
/* Conservative routing hint, not a language/version validator. Ambiguous code
   stays native; users can explicitly select historical 0.1 or 0.2. */
int ti_legacy_detect(const char *source);
/* Preserve the original interpreter and HTML, adding only a source loader.
   Source is base64 encoded as data, never interpolated into JavaScript. */
int ti_legacy_write_html(FILE *output,const char *html,size_t html_length,
                         const char *source,size_t length,char error[256]);
#endif
