#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app_win.h"

typedef struct TiAppClick {char name[64];struct TiAppClick *next;} TiAppClick;
typedef struct {HWND hwnd;int kind;char name[64],text[TI_APP_TEXT];} TiNativeControl;
struct TiAppView {
 HWND window;HFONT font;HBRUSH background,field,button;
 wchar_t class_name[64];int registered,failed;unsigned count;
 TiNativeControl controls[TI_APP_CONTROLS];TiAppClick *first,*last;
 ULONGLONG tick;
};
static int fail(char error[256],const char *message){if(error)snprintf(error,256,"%s",message);return -1;}
static void clear_clicks(TiAppView *v){while(v->first){TiAppClick *next=v->first->next;free(v->first);v->first=next;}v->last=NULL;}
static void push_click(TiAppView *v,const char *name){TiAppClick *click=calloc(1,sizeof *click);if(!click){v->failed=1;return;}snprintf(click->name,sizeof click->name,"%s",name);if(v->last)v->last->next=click;else v->first=click;v->last=click;}
static void theme(HWND hwnd){
 HMODULE module=LoadLibraryW(L"uxtheme.dll");if(module){typedef HRESULT(WINAPI *Theme)(HWND,LPCWSTR,LPCWSTR);Theme set=(Theme)(void *)GetProcAddress(module,"SetWindowTheme");if(set)set(hwnd,L"DarkMode_Explorer",NULL);FreeLibrary(module);}
}
static void caption(HWND hwnd){
 HMODULE module=LoadLibraryW(L"dwmapi.dll");if(module){typedef HRESULT(WINAPI *Attribute)(HWND,DWORD,LPCVOID,DWORD);Attribute set=(Attribute)(void *)GetProcAddress(module,"DwmSetWindowAttribute");BOOL dark=TRUE;if(set)set(hwnd,20,&dark,sizeof dark);FreeLibrary(module);}
}
static wchar_t *wide(const char *text,int multiline){
 int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,text,-1,NULL,0);if(!n)return NULL;
 wchar_t *s=malloc(((size_t)n*2+1)*sizeof *s);if(!s)return NULL;
 if(!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,text,-1,s,n)){free(s);return NULL;}
 if(multiline){size_t j=(size_t)n-1;/* Normalize line endings in a separate buffer to keep CRLF edits stable. */
  wchar_t *out=malloc(((size_t)n*2+1)*sizeof *out);if(!out){free(s);return NULL;}j=0;
  for(size_t i=0;s[i];i++){if(s[i]=='\r'){out[j++]='\r';out[j++]='\n';if(s[i+1]=='\n')i++;}else if(s[i]=='\n'){out[j++]='\r';out[j++]='\n';}else out[j++]=s[i];}out[j]=0;free(s);return out;
 }return s;
}
static LRESULT CALLBACK window_proc(HWND hwnd,UINT message,WPARAM wparam,LPARAM lparam){
 TiAppView *v=(TiAppView *)(uintptr_t)GetWindowLongPtrW(hwnd,GWLP_USERDATA);
 if(message==WM_NCCREATE){v=((CREATESTRUCTW *)lparam)->lpCreateParams;SetWindowLongPtrW(hwnd,GWLP_USERDATA,(LONG_PTR)v);v->window=hwnd;}
 if(!v)return DefWindowProcW(hwnd,message,wparam,lparam);
 switch(message){
  case WM_COMMAND:if(HIWORD(wparam)==BN_CLICKED){unsigned id=LOWORD(wparam);if(id>=100&&id<100+v->count){TiNativeControl *c=&v->controls[id-100];if((HWND)lparam==c->hwnd&&(c->kind==TI_APP_BUTTON||c->kind==TI_APP_CHECK))push_click(v,c->name);}}return 0;
  case WM_CLOSE:DestroyWindow(hwnd);return 0;
  case WM_DESTROY:v->window=NULL;memset(v->controls,0,sizeof v->controls);v->count=0;v->failed=0;clear_clicks(v);return 0;
  case WM_ERASEBKGND:{RECT rect;GetClientRect(hwnd,&rect);FillRect((HDC)wparam,&rect,v->background);return 1;}
  case WM_CTLCOLORSTATIC:case WM_CTLCOLORBTN:SetTextColor((HDC)wparam,RGB(230,233,239));SetBkColor((HDC)wparam,RGB(27,31,40));return (LRESULT)v->background;
  case WM_CTLCOLOREDIT:SetTextColor((HDC)wparam,RGB(237,240,246));SetBkColor((HDC)wparam,RGB(40,46,59));return (LRESULT)v->field;
  case WM_DRAWITEM:{DRAWITEMSTRUCT *d=(DRAWITEMSTRUCT *)lparam;if(d->CtlType!=ODT_BUTTON)break;
   FillRect(d->hDC,&d->rcItem,v->button);RECT rect=d->rcItem;HBRUSH border=CreateSolidBrush((d->itemState&ODS_FOCUS)?RGB(103,177,248):RGB(75,87,108));if(border){FrameRect(d->hDC,&rect,border);DeleteObject(border);}
   SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,(d->itemState&ODS_DISABLED)?RGB(131,139,154):RGB(238,241,247));
   wchar_t text[TI_APP_TEXT];GetWindowTextW(d->hwndItem,text,TI_APP_TEXT);HFONT old=SelectObject(d->hDC,v->font);if(d->itemState&ODS_SELECTED)OffsetRect(&rect,1,1);DrawTextW(d->hDC,text,-1,&rect,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);SelectObject(d->hDC,old);
   if(d->itemState&ODS_FOCUS){InflateRect(&rect,-4,-4);DrawFocusRect(d->hDC,&rect);}return TRUE;}
 }
 return DefWindowProcW(hwnd,message,wparam,lparam);
}
TiAppView *ti_app_view_create(void){
 TiAppView *v=calloc(1,sizeof *v);if(!v)return NULL;
 swprintf(v->class_name,64,L"TitaniumApp_%p",(void *)v);
 v->background=CreateSolidBrush(RGB(27,31,40));v->field=CreateSolidBrush(RGB(40,46,59));v->button=CreateSolidBrush(RGB(53,65,84));
 v->font=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Segoe UI");
 if(!v->background||!v->field||!v->button||!v->font){ti_app_view_destroy(v);return NULL;}return v;
}
static int make_window(TiAppView *v,TiAppScene *s,char error[256]){
 if(!v->registered){WNDCLASSEXW klass={0};klass.cbSize=sizeof klass;klass.lpfnWndProc=window_proc;klass.hInstance=GetModuleHandleW(NULL);klass.hCursor=LoadCursorW(NULL,IDC_ARROW);klass.hbrBackground=v->background;klass.lpszClassName=v->class_name;
  if(!RegisterClassExW(&klass))return fail(error,"Nie mozna zarejestrowac okna aplikacji");v->registered=1;}
 wchar_t *title=wide(s->title,0);if(!title)return fail(error,"Niepoprawny tytul UTF-8 lub brak pamieci");
 DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;RECT rect={0,0,(LONG)s->width,(LONG)s->height};AdjustWindowRectEx(&rect,style,FALSE,WS_EX_CONTROLPARENT);
 HWND hwnd=CreateWindowExW(WS_EX_CONTROLPARENT,v->class_name,title,style,CW_USEDEFAULT,CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,NULL,NULL,GetModuleHandleW(NULL),v);free(title);
 if(!hwnd)return fail(error,"Nie mozna utworzyc natywnego okna aplikacji");caption(hwnd);ShowWindow(hwnd,SW_SHOW);UpdateWindow(hwnd);v->tick=GetTickCount64();return 1;
}
static int apply(TiAppView *v,TiAppScene *s,char error[256]){
 wchar_t *title=wide(s->title,0);if(!title)return fail(error,"Niepoprawny tytul UTF-8 lub brak pamieci");SetWindowTextW(v->window,title);free(title);
 RECT client;GetClientRect(v->window,&client);if(client.right!=(LONG)s->width||client.bottom!=(LONG)s->height){RECT rect={0,0,(LONG)s->width,(LONG)s->height};AdjustWindowRectEx(&rect,(DWORD)GetWindowLongPtrW(v->window,GWL_STYLE),FALSE,WS_EX_CONTROLPARENT);SetWindowPos(v->window,NULL,0,0,rect.right-rect.left,rect.bottom-rect.top,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);}
 for(unsigned i=s->count;i<v->count;i++){if(v->controls[i].hwnd)DestroyWindow(v->controls[i].hwnd);memset(v->controls+i,0,sizeof v->controls[i]);}v->count=s->count;
 for(unsigned i=0;i<s->count;i++){
  TiControl *model=&s->controls[i];TiNativeControl *native=&v->controls[i];int fresh=0;
  if(native->hwnd&&(native->kind!=model->kind||strcmp(native->name,model->name))){DestroyWindow(native->hwnd);memset(native,0,sizeof *native);}
  if(!native->hwnd){
   const wchar_t *klass=model->kind==TI_APP_EDIT||model->kind==TI_APP_MULTILINE?L"EDIT":model->kind==TI_APP_LABEL?L"STATIC":L"BUTTON";
   DWORD style=WS_CHILD;DWORD ex=0;
   if(model->kind==TI_APP_EDIT||model->kind==TI_APP_MULTILINE){style|=WS_TABSTOP|ES_LEFT|ES_AUTOHSCROLL;ex=WS_EX_CLIENTEDGE;if(model->kind==TI_APP_MULTILINE){style&=~ES_AUTOHSCROLL;style|=ES_MULTILINE|ES_AUTOVSCROLL|ES_WANTRETURN|WS_VSCROLL;}}
   else if(model->kind==TI_APP_BUTTON)style|=WS_TABSTOP|BS_OWNERDRAW;
   else if(model->kind==TI_APP_CHECK)style|=WS_TABSTOP|BS_AUTOCHECKBOX;
   else style|=SS_LEFT|SS_NOPREFIX;
   native->hwnd=CreateWindowExW(ex,klass,L"",style,model->x,model->y,model->w,model->h,v->window,(HMENU)(uintptr_t)(100+i),GetModuleHandleW(NULL),NULL);
   if(!native->hwnd)return fail(error,"Nie mozna utworzyc kontrolki aplikacji");
   native->kind=model->kind;snprintf(native->name,sizeof native->name,"%s",model->name);SendMessageW(native->hwnd,WM_SETFONT,(WPARAM)v->font,TRUE);theme(native->hwnd);
   if(model->kind==TI_APP_EDIT||model->kind==TI_APP_MULTILINE)SendMessageW(native->hwnd,EM_SETLIMITTEXT,TI_APP_TEXT-1,0);fresh=1;
  }
  if(fresh||strcmp(native->text,model->text)){wchar_t *text=wide(model->text,model->kind==TI_APP_MULTILINE);if(!text)return fail(error,"Niepoprawny tekst UTF-8 lub brak pamieci");SetWindowTextW(native->hwnd,text);free(text);snprintf(native->text,sizeof native->text,"%s",model->text);}
  SetWindowPos(native->hwnd,NULL,model->x,model->y,model->w,model->h,SWP_NOZORDER|SWP_NOACTIVATE);EnableWindow(native->hwnd,model->enabled);ShowWindow(native->hwnd,model->visible?SW_SHOW:SW_HIDE);
  if(model->kind==TI_APP_CHECK)SendMessageW(native->hwnd,BM_SETCHECK,model->checked?BST_CHECKED:BST_UNCHECKED,0);
 }
 return 1;
}
static int sync_edits(TiAppView *v,TiAppScene *s,char error[256]){
 for(unsigned i=0;i<s->count;i++){
  TiControl *model=&s->controls[i];TiNativeControl *native=&v->controls[i];
  if(model->kind==TI_APP_CHECK)model->checked=SendMessageW(native->hwnd,BM_GETCHECK,0,0)==BST_CHECKED;
  if(model->kind!=TI_APP_EDIT&&model->kind!=TI_APP_MULTILINE)continue;
  int length=GetWindowTextLengthW(native->hwnd);wchar_t *w=malloc(((size_t)length+1)*sizeof *w);if(!w)return fail(error,"Brak pamieci podczas odczytu kontrolki");GetWindowTextW(native->hwnd,w,length+1);
  /* Expose the language's LF newline convention, independently of Win32 CRLF. */
  size_t j=0;for(size_t k=0;w[k];k++){if(w[k]=='\r'){w[j++]='\n';if(w[k+1]=='\n')k++;}else w[j++]=w[k];}w[j]=0;
  int bytes=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,-1,NULL,0,NULL,NULL);if(!bytes){free(w);return fail(error,"Kontrolka zawiera niepoprawny tekst Unicode");}
  char *text=malloc((size_t)bytes);if(!text){free(w);return fail(error,"Brak pamieci podczas odczytu kontrolki");}WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,-1,text,bytes,NULL,NULL);free(w);
  if(bytes>TI_APP_TEXT){size_t end=TI_APP_TEXT-1;while(end&&((unsigned char)text[end]&0xc0)==0x80)end--;text[end]=0;wchar_t *limited=wide(text,model->kind==TI_APP_MULTILINE);if(!limited){free(text);return fail(error,"Brak pamieci podczas ograniczania tekstu");}SetWindowTextW(native->hwnd,limited);free(limited);}
  snprintf(model->text,sizeof model->text,"%s",text);snprintf(native->text,sizeof native->text,"%s",text);free(text);
 }return 1;
}
int ti_app_view_frame(TiAppView *v,TiAppScene *s,TiAppInput *input,char error[256]){
 if(error)error[0]=0;if(input)memset(input,0,sizeof *input);if(!v||!s||!input)return fail(error,"Brak stanu natywnej aplikacji");
 if(!s->active){if(v->window)DestroyWindow(v->window);clear_clicks(v);return 0;}
 if(s->count>TI_APP_CONTROLS||s->width<240||s->width>3840||s->height<160||s->height>2160)return fail(error,"Nieprawidlowy rozmiar natywnej aplikacji");
 if(!v->window&&make_window(v,s,error)<0)return -1;if(apply(v,s,error)<0)return -1;
 ULONGLONG now=GetTickCount64();DWORD wait=now-v->tick<16?(DWORD)(16-(now-v->tick)):0;
 if(wait)MsgWaitForMultipleObjects(0,NULL,FALSE,wait,QS_ALLINPUT);
 MSG message;while(PeekMessageW(&message,NULL,0,0,PM_REMOVE)){
  if(message.message==WM_QUIT){if(v->window)DestroyWindow(v->window);PostQuitMessage((int)message.wParam);break;}
  if(!v->window||!IsDialogMessageW(v->window,&message)){TranslateMessage(&message);DispatchMessageW(&message);}
 }
 v->tick=GetTickCount64();if(!v->window){s->active=0;return 0;}
 if(v->failed){v->failed=0;return fail(error,"Brak pamieci w kolejce klikniec aplikacji");}
 if(sync_edits(v,s,error)<0)return -1;
 if(v->first){TiAppClick *click=v->first;snprintf(input->click,sizeof input->click,"%s",click->name);v->first=click->next;if(!v->first)v->last=NULL;free(click);}return 1;
}
void ti_app_view_destroy(TiAppView *v){
 if(!v)return;if(v->window)DestroyWindow(v->window);clear_clicks(v);if(v->registered)UnregisterClassW(v->class_name,GetModuleHandleW(NULL));
 if(v->font)DeleteObject(v->font);if(v->background)DeleteObject(v->background);if(v->field)DeleteObject(v->field);if(v->button)DeleteObject(v->button);free(v);
}
