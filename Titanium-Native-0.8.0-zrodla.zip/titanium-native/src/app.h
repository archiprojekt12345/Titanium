#ifndef TI_APP_H
#define TI_APP_H
#include "game.h"
#define TI_APP_CONTROLS 64
#define TI_APP_TEXT 4096
enum {TI_APP_BUTTON=1,TI_APP_EDIT,TI_APP_MULTILINE,TI_APP_LABEL,TI_APP_CHECK};
typedef struct TiControl {
    char name[64],text[TI_APP_TEXT];
    int kind,x,y,w,h,visible,enabled,checked;
} TiControl;
typedef struct TiAppScene {
    int active;unsigned width,height,count;
    char title[256];TiControl controls[TI_APP_CONTROLS];
} TiAppScene;
typedef struct TiAppInput {char click[64];} TiAppInput;
typedef struct {TiAppScene scene;TiAppInput input;TiHost host;int started;} TiApp;
void ti_app_init(TiApp *app,const TiHost *host);
/* 1 handled, 0 unknown, -1 error. String results borrow model storage. */
int ti_app_call(TiApp *app,const char *name,int argc,const TiValue *args,TiValue *result,char error[256]);
#endif
