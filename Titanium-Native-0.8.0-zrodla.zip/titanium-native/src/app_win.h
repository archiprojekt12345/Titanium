#ifndef TI_APP_WIN_H
#define TI_APP_WIN_H
#include "app.h"
typedef struct TiAppView TiAppView;
TiAppView *ti_app_view_create(void);
int ti_app_view_frame(TiAppView *view,TiAppScene *scene,TiAppInput *input,char error[256]);
void ti_app_view_destroy(TiAppView *view);
#endif
