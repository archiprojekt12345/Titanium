#ifndef TI_LEGACY_WIN_H
#define TI_LEGACY_WIN_H
#include <windows.h>
#include <stddef.h>
/* version: 1 for the exact 0.1 runtime, 2 for the exact 0.2 runtime.
   self_path is the full path of Titanium.exe; templates are beside it in
   compatibility/Titanium-0.1.html and compatibility/Titanium-0.2.html. */
int ti_legacy_run(HWND owner,const wchar_t *self_path,const char *source,
                  size_t length,int version,char error[256]);
int ti_legacy_export(const wchar_t *self_path,const wchar_t *output_path,
                     const char *source,size_t length,int version,char error[256]);
#endif
