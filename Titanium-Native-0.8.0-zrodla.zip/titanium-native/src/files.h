#ifndef TI_FILES_H
#define TI_FILES_H
int ti_file_read(const char *path,char **text,char error[256]);
int ti_file_write(const char *path,const char *text,char error[256]);
#endif
