#ifndef TI_LOWLEVEL_H
#define TI_LOWLEVEL_H
#include "titanium.h"
#include <stddef.h>
#define TI_MEMORY_BUFFERS 16
#define TI_MEMORY_BYTES 65536
#define TI_MEMORY_NAME 63
typedef struct {
    int used;
    char name[TI_MEMORY_NAME + 1];
    size_t size;
    unsigned char bytes[TI_MEMORY_BYTES];
} TiMemoryBuffer;
/* Storage is owned by this state; no string result borrows buffer storage. */
typedef struct { TiMemoryBuffer buffers[TI_MEMORY_BUFFERS]; } TiMemory;
void ti_memory_init(TiMemory *memory);
/* Returns 1 for a handled command, -1 for invalid arguments, 0 if unknown. */
int ti_memory_call(TiMemory *memory,const char *name,int argc,
                   const TiValue *args,TiValue *result,char error[256]);
#endif
