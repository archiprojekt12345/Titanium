#include "assist.h"
#include "commands.h"
#include <string.h>
#include <ctype.h>
static const char *keywords[]={"ustaw","dodaj","odejmij","jesli","inaczej","koniec","powtorz","dopoki","dla","funkcja","zwroc","zawsze","prawda","falsz","i","lub","nie",NULL};
const char *ti_assist_word(size_t i){
 size_t n=ti_command_count();
 if(i<n)return ti_command_at(i)->name;i-=n;
 return i<sizeof keywords/sizeof *keywords?keywords[i]:NULL;
}
const char *ti_assist_complete(const char *prefix,size_t index){
 if(!prefix||!*prefix)return NULL;
 for(size_t i=0;;i++){const char *w=ti_assist_word(i);if(!w)break;if(!strncmp(w,prefix,strlen(prefix))){if(!index--)return w;}}
 return NULL;
}
static int distance(const char*a,const char*b){
 size_t n=strlen(a),m=strlen(b);if(n>63||m>63)return 99;
 int d[64][64];for(size_t i=0;i<=n;i++)d[i][0]=(int)i;for(size_t j=0;j<=m;j++)d[0][j]=(int)j;
 for(size_t i=1;i<=n;i++)for(size_t j=1;j<=m;j++){
  int v=d[i-1][j]+1;if(d[i][j-1]+1<v)v=d[i][j-1]+1;
  int sub=d[i-1][j-1]+(a[i-1]!=b[j-1]);if(sub<v)v=sub;
  if(i>1&&j>1&&a[i-1]==b[j-2]&&a[i-2]==b[j-1]&&d[i-2][j-2]+1<v)v=d[i-2][j-2]+1;d[i][j]=v;
 }return d[n][m];
}
const char *ti_assist_suggest(const char *word){
 if(!word||strlen(word)<4||strlen(word)>63)return NULL;
 /* Partial valid words are completion candidates, never automatic corrections. */
 if(ti_assist_complete(word,0))return NULL;
 const char *best=NULL;int score=strlen(word)>=7?2:1,tie=0;
 for(size_t i=0;;i++){const char*w=ti_assist_word(i);if(!w)break;int d=distance(word,w);
  if(!d)return NULL;if(d<score){score=d;best=w;tie=0;}else if(d==score){if(best)tie=1;else best=w;}}
 return tie?NULL:best;
}
int ti_assist_correct(const wchar_t *line,size_t length,char out[64]){
 if(!line||!out)return 0;size_t start=0;while(start<length&&(line[start]==' '||line[start]=='\t'))start++;
 size_t end=start;char word[64];while(end<length&&end-start<63){wchar_t c=line[end];if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||c=='_'))break;word[end-start]=(char)tolower((unsigned char)c);end++;}
 if(end==start||(end<length&&line[end]!=' '&&line[end]!='\t'))return 0;
 size_t tail=end;while(tail<length&&(line[tail]==' '||line[tail]=='\t'))tail++;
 if(tail<length&&line[tail]=='=')return 0;
 word[end-start]=0;
 const char *v=ti_assist_suggest(word);if(!v)return 0;strcpy(out,v);return 1;
}
static wchar_t fold(wchar_t c){
 if(c>='A'&&c<='Z')return c+32;
 switch(c){case L'Ą':case L'ą':return 'a';case L'Ć':case L'ć':return 'c';case L'Ę':case L'ę':return 'e';case L'Ł':case L'ł':return 'l';case L'Ń':case L'ń':return 'n';case L'Ó':case L'ó':return 'o';case L'Ś':case L'ś':return 's';case L'Ź':case L'ź':case L'Ż':case L'ż':return 'z';default:return c;}
}
static int idchar(wchar_t c){return (c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c>=128;}
int ti_assist_custom(const wchar_t*source,const wchar_t*word,size_t n){
 if(!source||!word||!n)return 0;
 while(*source){
  while(*source==' '||*source=='\t'||*source=='\r'||*source=='\n')source++;
  const wchar_t*key=L"funkcja";size_t i=0;while(key[i]&&source[i]&&fold(source[i])==key[i])i++;
  if(!key[i]&&(source[i]==' '||source[i]=='\t')){const wchar_t*p=source+i;while(*p==' '||*p=='\t')p++;size_t j=0;while(j<n&&p[j]&&fold(p[j])==fold(word[j]))j++;if(j==n&&!idchar(fold(p[j])))return 1;}
  while(*source&&*source!='\n'&&*source!='\r')source++;
 }return 0;
}
