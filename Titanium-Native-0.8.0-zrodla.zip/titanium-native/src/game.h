#ifndef TI_GAME_H
#define TI_GAME_H
#include "titanium.h"
#include <stdint.h>
#define TI_OBJECTS 128
#define TI_PARTICLES 512
#define TI_TRAILS 256 /* Independent of the legacy 512 burst-particle slots. */
enum {TI_RECT=1,TI_CIRCLE,TI_IMAGE,TI_LABEL};
typedef struct {
    char name[64]; int kind,visible; uint32_t color;
    double x,y,w,h,speed;
    double angle,scale,opacity,parallax,outline;
    uint32_t outline_color;int layer,mirror;
    /* Physics/controller state. Only rectangular shapes are physical bodies. */
    int solid,body,controller,grounded,pinned,has_home,direction;
    double vx,vy,gravity,walk_speed,jump_speed,coyote,jump_buffer;
    double home_x,home_y,patrol_min,patrol_max,patrol_speed;
    int anim_frames,anim_frame;
    double anim_fps,anim_time;
    /* Effects remain POD: scenes are copied between the editor and runner. */
    double glow_radius,glow_intensity,light_radius,light_strength;
    uint32_t glow_color,light_color,trail_color,effect_id;
    int trail_count; /* 0 disables emission; otherwise samples retained at 60 Hz. */
    double trail_clock,trail_x,trail_y;
    char text[512],asset[256];
} TiObject;
typedef struct {double x,y,vx,vy,life,total,size;uint32_t color;} TiParticle;
typedef struct {
    double x,y,size,life,total,parallax;uint32_t color,owner;int layer,pinned;
} TiTrail;
typedef struct {
    uint32_t active,width,height,background,count;
    char title[128];TiObject objects[TI_OBJECTS];
    double world_width,world_height,camera_x,camera_y;
    int world_custom;
    double zoom;uint32_t background2;int gradient;
    unsigned particle_count;uint32_t particle_seed;TiParticle particles[TI_PARTICLES];
    unsigned trail_count;uint32_t next_effect_id;TiTrail trails[TI_TRAILS];
    /* Shake offsets are logical screen pixels; physical/camera coordinates stay intact. */
    double shake_power,shake_duration,shake_remaining,shake_x,shake_y;
    char camera_target[64];
} TiScene;
typedef struct { unsigned char keys[256],buttons[2]; double mouse_x,mouse_y; } TiInput;
struct TiAppScene;struct TiAppInput;
typedef struct TiHost {
    void *context;
    /* frame: 1 continue, 0 closed, -1 error; publishes scene, gets current input,
       caps frame rate near 60Hz, sets dt in seconds. */
    int (*frame)(void *,const TiScene *,TiInput *,double *,char error[256]);
    /* asset: 1 readable supported image in asset root, 0 with error. */
    int (*asset)(void *,const char *filename,char error[256]);
    int (*app)(void *,struct TiAppScene *,struct TiAppInput *,char error[256]);
} TiHost;
typedef struct {
    TiScene scene;TiInput input,previous;TiHost host;
    double dt,elapsed;int started;
} TiGame;
void ti_game_init(TiGame *game,const TiHost *host);
/* Return 1 handled, 0 unknown command, -1 error. All Value.s pointers are borrowed.
   Results are numeric/bool only. The game copies names/text/assets to fixed buffers. */
int ti_game_call(TiGame *game,const char *name,int argc,const TiValue *args,TiValue *result,char error[256]);
int ti_game_asset_name(const char *name);
#endif
