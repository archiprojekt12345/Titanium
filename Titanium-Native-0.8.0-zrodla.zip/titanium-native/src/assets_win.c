#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include "assets_win.h"
#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
int ti_assets_root(const wchar_t *file,wchar_t out[32768]) {
    DWORD n=GetFullPathNameW(file,32768,out,NULL);if(!n||n>32000)return 0;
    wchar_t *slash=wcsrchr(out,L'\\');if(!slash)return 0;slash[1]=0;wcscat(out,L"assety");return 1;
}
static int same(const wchar_t *a,const wchar_t *b) {
    FILE *fa=_wfopen(a,L"rb"),*fb=_wfopen(b,L"rb");int ok=0;
    if(fa&&fb){unsigned char ba[4096],bb[4096];ok=1;for(;;){size_t na=fread(ba,1,sizeof ba,fa),nb=fread(bb,1,sizeof bb,fb);
        if(na!=nb||memcmp(ba,bb,na)){ok=0;break;}if(!na){if(ferror(fa)||ferror(fb))ok=0;break;}}}
    if(fa)fclose(fa);if(fb)fclose(fb);return ok;
}
int ti_assets_copy(const wchar_t *root,const wchar_t *exe,wchar_t error[512]) {
    wchar_t *dest=calloc(32768,sizeof *dest),*pattern=calloc(32768,sizeof *pattern),*a=calloc(32768,sizeof *a),*b=calloc(32768,sizeof *b);int ok=0;
    if(!dest||!pattern||!a||!b){swprintf(error,512,L"Brak pamieci przy kopiowaniu assetow.");goto done;}
    if(!ti_assets_root(exe,dest)||wcslen(root)>32000){swprintf(error,512,L"Sciezka do assetow jest za dluga.");goto done;}
    if(!_wcsicmp(root,dest)){ok=1;goto done;}
    DWORD attr=GetFileAttributesW(root);if(attr==INVALID_FILE_ATTRIBUTES){ok=1;goto done;}
    if(!(attr&FILE_ATTRIBUTE_DIRECTORY)){swprintf(error,512,L"assety musi byc folderem.");goto done;}
    if(!CreateDirectoryW(dest,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS){swprintf(error,512,L"Nie mozna utworzyc folderu assety obok EXE.");goto done;}
    swprintf(pattern,32768,L"%ls\\*",root);WIN32_FIND_DATAW data;HANDLE find=FindFirstFileW(pattern,&data);
    if(find==INVALID_HANDLE_VALUE){ok=GetLastError()==ERROR_FILE_NOT_FOUND;if(!ok)swprintf(error,512,L"Nie mozna odczytac folderu assety.");goto done;}
    unsigned count=0;uint64_t total=0;ok=1;
    do{
        if(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)continue;
        const wchar_t *ext=wcsrchr(data.cFileName,L'.');
        if(!ext||(_wcsicmp(ext,L".png")&&_wcsicmp(ext,L".jpg")&&_wcsicmp(ext,L".jpeg")&&_wcsicmp(ext,L".bmp")))continue;
        uint64_t size=((uint64_t)data.nFileSizeHigh<<32)|data.nFileSizeLow;total+=size;
        if(++count>128||size>16*1024*1024||total>64*1024*1024){swprintf(error,512,L"Za duzo assetow: limit 128 obrazow, 16 MB na plik i 64 MB lacznie.");ok=0;break;}
        swprintf(a,32768,L"%ls\\%ls",root,data.cFileName);swprintf(b,32768,L"%ls\\%ls",dest,data.cFileName);
        if(!CopyFileW(a,b,TRUE)){
            if(GetLastError()==ERROR_FILE_EXISTS&&same(a,b))continue;
            swprintf(error,512,L"Nie skopiowano %ls. Jesli plik juz istnieje i ma inna zawartosc, wybierz inny folder dla EXE.",data.cFileName);ok=0;break;
        }
    }while(FindNextFileW(find,&data));
    if(ok&&GetLastError()!=ERROR_NO_MORE_FILES){swprintf(error,512,L"Blad odczytu listy assetow.");ok=0;}FindClose(find);
done:free(dest);free(pattern);free(a);free(b);return ok;
}
