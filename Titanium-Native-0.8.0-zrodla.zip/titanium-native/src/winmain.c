#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <uxtheme.h>
#include <windowsx.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wchar.h>
#include <string.h>
#include "titanium.h"
#include "package.h"
#include "examples.h"
#include "text.h"
#include "view.h"
#include "commands.h"
#include "assets_win.h"
#include "version.h"
#include "editor_win.h"
#include "assist.h"
#include "layout.h"
#include "legacy.h"
#include "legacy_win.h"

enum {ID_NEW=100,ID_OPEN,ID_SAVE,ID_SAVEAS,ID_CHECK,ID_RUN,ID_STOP,ID_EXPORT,ID_SEND,
      ID_HELP,ID_ABOUT,ID_EXIT,ID_EDITOR,ID_INPUT,ID_CONSOLE,ID_COMMANDS,ID_ASSETS,ID_SAMPLE=200};
enum {MSG_OUTPUT=WM_APP+1,MSG_DONE,MSG_INPUT_DONE};
typedef struct {HWND window;HANDLE output,process;wchar_t temp[MAX_PATH];} Reader;
typedef struct {HWND window;HANDLE pipe;char *text;DWORD length;unsigned generation;} Sender;
static HWND window,editor,console,input,send_button,status,code_label,console_label,answer_label,buttons[8];
static HFONT mono,ui,brand_font;
static HWND brand,subtitle,searchbox,commandlist,commanddetail,insert_button,sidebar_label;
typedef struct {wchar_t text[128];int top,separator;} TiMenuLabel;
static TiMenuLabel menu_labels[256];static unsigned menu_label_count;
static HBRUSH page_brush,white_brush;static RECT gutter,splitter_rect;
static HWND category_box,find_box,find_button,nav_label,nav_buttons[5],menu_button,drawer_button;
static HMENU main_menu;static TiLayout studio_layout;static int engine_mode=0;
enum {ID_MENU=300,ID_SHOWCASE,ID_CLASSIC01,ID_CLASSIC02,ID_ENGINE_AUTO,ID_DRAWER};static double split_ratio=.64;
static int sidebar_open=1,preview_open=0,focus_mode=0,dragging=0,find_open=0;
enum {ID_CATEGORY=186,ID_FIND_BOX=187,ID_FIND_NEXT=188,ID_NEW_APP=250,ID_NEW_GAME,ID_FIND,ID_FOCUS,ID_SIDEBAR,ID_PREVIEW,ID_ZOOMIN,ID_ZOOMOUT,ID_ZOOMRESET,ID_SYNTAX};
static void layout(int w,int h);
enum {ID_CORRECT=180,ID_COMPLETE,ID_SEARCH,ID_REFERENCE,ID_INSERT};static WNDPROC input_proc;
static HANDLE process,input_pipe,job;static int dirty,loading,stopping,sending;
static unsigned generation;
static TiView *view;static HWND view_label,commands_window;static int preview_active;
static wchar_t current_path[32768],self_path[32768];
static const int button_ids[]={ID_NEW,ID_OPEN,ID_SAVE,ID_CHECK,ID_RUN,ID_STOP,ID_EXPORT,ID_COMMANDS};
static const wchar_t *button_names[]={L"Nowy",L"Otwórz",L"Zapisz",L"Sprawdź",L"▶  Uruchom",L"Stop",L"Zbuduj EXE",L"Komendy"};
static void error_box(const wchar_t *s){MessageBoxW(window,s,L"Titanium — uwaga",MB_OK|MB_ICONWARNING);}
static wchar_t *wide(const char *s,int length) {
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s,length,NULL,0);
    if(n==0&&length!=0)return NULL;
    wchar_t *w=calloc((size_t)n+1,sizeof *w);if(!w)return NULL;
    if(n)MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s,length,w,n);return w;
}
static char *utf8(const wchar_t *w,size_t *length) {
    int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,-1,NULL,0,NULL,NULL);if(!n)return NULL;
    char *s=malloc((size_t)n);if(!s)return NULL;
    WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,-1,s,n,NULL,NULL);if(length)*length=(size_t)n-1;return s;
}
static wchar_t *control_text(HWND c) {
    int n=GetWindowTextLengthW(c);wchar_t *w=calloc((size_t)n+1,sizeof *w);if(w)GetWindowTextW(c,w,n+1);return w;
}
static char *source(size_t *n) {
    wchar_t *w=ti_editor_get_text();if(!w)return NULL;
    size_t k=0;for(size_t i=0;w[i];i++){if(w[i]=='\r'){w[k++]='\n';if(w[i+1]=='\n')i++;}else w[k++]=w[i];}w[k]=0;
    char *s=utf8(w,n);free(w);
    if(!s||*n>250000){free(s);error_box(L"Program moze miec najwyzej 250000 bajtow UTF-8. Skroc kod.");return NULL;}return s;
}
static void set_status(const wchar_t *s){SetWindowTextW(status,s);}
static int asset_root(wchar_t out[32768]){return ti_assets_root(current_path[0]?current_path:self_path,out);}
static LRESULT CALLBACK command_proc(HWND h,UINT m,WPARAM w,LPARAM l){
    HWND text=GetDlgItem(h,1);
    if(m==WM_CREATE){
        text=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",(const wchar_t*)((CREATESTRUCTW*)l)->lpCreateParams,
            WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|ES_AUTOHSCROLL,0,0,0,0,h,(HMENU)1,GetModuleHandleW(NULL),NULL);
        SendMessageW(text,WM_SETFONT,(WPARAM)mono,TRUE);SendMessageW(text,EM_LIMITTEXT,50000,0);return 0;
    }
    if(m==WM_SIZE){MoveWindow(text,0,0,LOWORD(l),HIWORD(l),TRUE);return 0;}
    if(m==WM_DESTROY){commands_window=NULL;return 0;}
    return DefWindowProcW(h,m,w,l);
}
static void show_commands(void){
    if(commands_window){ShowWindow(commands_window,SW_RESTORE);SetForegroundWindow(commands_window);return;}
    char *text=ti_commands_text();wchar_t *w=text?wide(text,-1):NULL;free(text);if(!w)return;
    wchar_t *normal=ti_crlf(w);free(w);if(!normal)return;
    WNDCLASSW wc={0};wc.lpfnWndProc=command_proc;wc.hInstance=GetModuleHandleW(NULL);wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.lpszClassName=L"TitaniumCommands04";RegisterClassW(&wc);
    commands_window=CreateWindowExW(0,wc.lpszClassName,L"Titanium - wszystkie komendy",WS_OVERLAPPEDWINDOW|WS_VISIBLE,
        CW_USEDEFAULT,CW_USEDEFAULT,830,730,window,NULL,wc.hInstance,normal);free(normal);
}
static void dark_title(HWND h){BOOL enabled=TRUE;DwmSetWindowAttribute(h,20,&enabled,sizeof enabled);DwmSetWindowAttribute(h,19,&enabled,sizeof enabled);}
static void title(void){
    wchar_t s[33000];const wchar_t *name=current_path[0]?wcsrchr(current_path,L'\\'):NULL;
    name=name?name+1:(current_path[0]?current_path:L"Nowy program.ti");
    swprintf(s,sizeof s/sizeof *s,L"%ls%ls — Titanium Native " TI_VERSION_W,dirty?L"* ":L"",name);SetWindowTextW(window,s);
}
static void append_console(const wchar_t *text) {
    /* Classic EDIT expects CRLF. Keep the total display bounded. */
    wchar_t *normal=ti_crlf(text);if(!normal)return;size_t j=wcslen(normal);
    int old=GetWindowTextLengthW(console);if(old+(int)j>1100000){free(normal);return;}
    SendMessageW(console,EM_SETSEL,(WPARAM)-1,(LPARAM)-1);SendMessageW(console,EM_REPLACESEL,FALSE,(LPARAM)normal);SendMessageW(console,EM_SCROLLCARET,0,0);free(normal);
}
static void show_ti_error(TiError *e) {
    wchar_t *w=wide(e->text,-1);wchar_t msg[700];swprintf(msg,700,L"Blad — wiersz %d: %ls\r\n",e->line,w?w:L"Nie mozna odczytac komunikatu.");free(w);
    SetWindowTextW(console,L"");append_console(msg);set_status(L"Popraw wskazany wiersz i sprobuj ponownie.");
    LRESULT start=SendMessageW(editor,EM_LINEINDEX,(WPARAM)(e->line-1),0);
    if(start>=0){SendMessageW(editor,EM_SETSEL,start,start);SendMessageW(editor,EM_SCROLLCARET,0,0);SetFocus(editor);}
}
static int classic_mode(const char*s,size_t n){
 if(engine_mode)return engine_mode;TiError e;TiProgram*p=ti_compile(s,n,&e);if(p){ti_free(p);return 0;}return ti_legacy_detect(s)?2:0;
}
static int compile_source(const char *s,size_t n) {
    TiError e;TiProgram *p=ti_compile(s,n,&e);if(!p){show_ti_error(&e);return 0;}ti_free(p);return 1;
}
static int choose_path(wchar_t *path,int save,int exe) {
    OPENFILENAMEW of={0};of.lStructSize=sizeof of;of.hwndOwner=window;of.lpstrFile=path;of.nMaxFile=32768;
    of.lpstrFilter=exe?L"Program Windows (*.exe)\0*.exe\0":L"Kod Titanium (*.ti)\0*.ti\0Pliki tekstowe (*.txt)\0*.txt\0Wszystkie pliki\0*.*\0";
    of.lpstrDefExt=exe?L"exe":L"ti";of.Flags=OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_PATHMUSTEXIST|(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST);
    return save?GetSaveFileNameW(&of):GetOpenFileNameW(&of);
}
static int atomic_write(const wchar_t *path,const char *data,size_t length,int export_exe) {
    if(!_wcsicmp(path,self_path)){error_box(L"Wybierz inna nazwe niz uruchomiony plik Titanium.exe.");return 0;}
    wchar_t temp[32768];if(wcslen(path)>32600){error_box(L"Sciezka jest za dluga.");return 0;}
    swprintf(temp,32768,L"%ls.titanium-%lu.tmp",path,GetCurrentProcessId());
    HANDLE handle=CreateFileW(temp,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(handle==INVALID_HANDLE_VALUE){error_box(L"Nie mozna utworzyc pliku tymczasowego w wybranym folderze.");return 0;}
    CloseHandle(handle);FILE *out=_wfopen(temp,L"w+b"),*base=NULL;int ok=0;
    if(out){if(export_exe){base=_wfopen(self_path,L"rb");if(base)ok=ti_package_write(base,out,data,length)&&(export_exe==2||ti_package_console(out));}
        else ok=fwrite(data,1,length,out)==length;if(fclose(out))ok=0;}
    if(base)fclose(base);
    if(ok)ok=MoveFileExW(temp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
    if(!ok){DeleteFileW(temp);error_box(L"Zapis nie powiodl sie. Sprawdz folder i czy plik nie jest uruchomiony.");}return ok;
}
static int save_code(int as) {
    wchar_t *path=calloc(32768,sizeof *path);if(!path)return 0;
    if(current_path[0])wcscpy(path,current_path);else wcscpy(path,L"Moj-program.ti");
    if((as||!current_path[0])&&!choose_path(path,1,0)){free(path);return 0;}
    size_t n;char *s=source(&n);if(!s){free(path);return 0;}
    int ok=atomic_write(path,s,n,0);free(s);
    if(ok){wcscpy(current_path,path);dirty=0;title();set_status(L"Zapisano kod Titanium.");}free(path);return ok;
}
static int may_discard(void) {
    if(!dirty)return 1;int r=MessageBoxW(window,L"Zapisac zmiany w kodzie przed kontynuowaniem?",L"Titanium",MB_YESNOCANCEL|MB_ICONQUESTION);
    if(r==IDCANCEL)return 0;return r==IDYES?save_code(0):1;
}
static void load_editor(const wchar_t *w,const wchar_t *path,int changed) {
    wchar_t *normal=ti_crlf(w);
    if(!normal){error_box(L"Brak pamięci — zachowano poprzedni kod.");return;}
    wchar_t *previous=ti_editor_get_text();loading=1;ti_editor_set_text(normal);wchar_t *loaded=ti_editor_get_text();
    if(!loaded||wcscmp(loaded,normal)){if(previous)ti_editor_set_text(previous);free(previous);free(loaded);free(normal);loading=0;error_box(L"Nie udało się wczytać pełnego kodu. Przywrócono poprzedni tekst.");return;}
    free(previous);free(loaded);free(normal);loading=0;
    if(path)wcscpy(current_path,path);else current_path[0]=0;dirty=changed;title();SetFocus(editor);
}
static void open_code(const wchar_t *given) {
    wchar_t *path=calloc(32768,sizeof *path);if(!path)return;
    if(given)wcsncpy(path,given,32767);else if(!choose_path(path,0,0)){free(path);return;}
    /* Saving may change the chosen file, so take the snapshot after this prompt.
       may_discard never clears the editor; failed reads preserve its contents. */
    if(!may_discard()){free(path);return;}
    FILE *f=_wfopen(path,L"rb");char *s=malloc(250002);if(!f||!s){if(f)fclose(f);free(s);free(path);error_box(L"Nie mozna odczytac tego pliku.");return;}
    size_t n=fread(s,1,250001,f);int bad=ferror(f);fclose(f);s[n]=0;
    wchar_t *w=(!bad&&n<=250000&&!memchr(s,0,n))?wide(s,(int)n):NULL;free(s);
    if(!w){free(path);error_box(L"Otworz plik UTF-8 o rozmiarze do 250000 bajtow. Poprzedni kod pozostal w edytorze.");return;}
    load_editor(w[0]==0xfeff?w+1:w,path,0);set_status(L"Otworzono kod. Nacisnij F5, aby uruchomic.");free(w);free(path);
}
static void state(void) {
    int running=process!=NULL;
    for(int i=0;i<8;i++){
        int enabled=1;if(button_ids[i]==ID_RUN||button_ids[i]==ID_CHECK||button_ids[i]==ID_EXPORT)enabled=!running;
        if(button_ids[i]==ID_STOP)enabled=running&&!stopping;EnableWindow(buttons[i],enabled);
    }
    EnableWindow(input,running&&!stopping&&!sending);EnableWindow(send_button,running&&!stopping&&!sending);
}
static DWORD WINAPI read_output(void *arg) {
    Reader *r=arg;char buf[8192];size_t pending=0;DWORD got;
    while(ReadFile(r->output,buf+pending,4096,&got,NULL)&&got){
        size_t total=pending+got,safe=total;
        /* Only decode complete UTF-8 sequences, even across pipe reads. */
        size_t start=total;while(start&&((unsigned char)buf[start-1]&0xc0)==0x80)start--;
        if(start){unsigned char lead=(unsigned char)buf[start-1];size_t need=lead<128?1:lead<0xe0?2:lead<0xf0?3:4;
            if(total-(start-1)<need)safe=start-1;}
        wchar_t *w=wide(buf,(int)safe);if(w&&!PostMessageW(r->window,MSG_OUTPUT,0,(LPARAM)w))free(w);
        pending=total-safe;if(pending)memmove(buf,buf+safe,pending);
    }
    CloseHandle(r->output);WaitForSingleObject(r->process,INFINITE);DWORD exit=1;GetExitCodeProcess(r->process,&exit);CloseHandle(r->process);
    DeleteFileW(r->temp);PostMessageW(r->window,MSG_DONE,exit,0);free(r);return 0;
}
static void start_run(void) {
    if(process)return;size_t n;char *s=source(&n);if(!s)return;
    int classic=classic_mode(s,n);if(classic){char e[256];if(!ti_legacy_run(window,self_path,s,n,classic,e)){wchar_t*w=wide(e,-1);error_box(w?w:L"Nie można uruchomić trybu zgodności.");free(w);}else set_status(L"Program otwarto w oryginalnym silniku klasycznym. Kod pozostał bez zmian.");free(s);return;}
    if(!compile_source(s,n)){free(s);return;}
    preview_open=1;
    wchar_t *assetdir=calloc(32768,sizeof *assetdir);if(!assetdir||!asset_root(assetdir)){free(s);free(assetdir);return;}
    if(view){ti_view_destroy(view);view=NULL;}preview_active=0;view=ti_view_create(window,assetdir);
    if(!view){free(s);free(assetdir);error_box(L"Nie mozna utworzyc natywnego podgladu 2D.");return;}
    RECT client;GetClientRect(window,&client);PostMessageW(window,WM_SIZE,0,MAKELPARAM(client.right,client.bottom));
    Reader *r=calloc(1,sizeof *r);if(!r){free(s);free(assetdir);return;}
    wchar_t tmpdir[MAX_PATH];if(!GetTempPathW(MAX_PATH,tmpdir)||!GetTempFileNameW(tmpdir,L"tin",0,r->temp)){free(s);free(r);free(assetdir);error_box(L"Nie mozna utworzyc pliku do uruchomienia.");return;}
    FILE *f=_wfopen(r->temp,L"wb");int ok=f&&fwrite(s,1,n,f)==n;if(f&&fclose(f))ok=0;free(s);
    if(!ok){DeleteFileW(r->temp);free(r);free(assetdir);error_box(L"Nie mozna zapisac kodu do uruchomienia.");return;}
    SECURITY_ATTRIBUTES sa={sizeof sa,NULL,TRUE};HANDLE out_r=NULL,out_w=NULL,in_r=NULL,in_w=NULL;
    PROCESS_INFORMATION pi={0};STARTUPINFOW si={0};si.cb=sizeof si;
    if(!CreatePipe(&out_r,&out_w,&sa,0)||!SetHandleInformation(out_r,HANDLE_FLAG_INHERIT,0)||
       !CreatePipe(&in_r,&in_w,&sa,0)||!SetHandleInformation(in_w,HANDLE_FLAG_INHERIT,0))goto failed;
    si.dwFlags=STARTF_USESTDHANDLES;si.hStdInput=in_r;si.hStdOutput=out_w;si.hStdError=out_w;
    wchar_t *cmd=calloc(66000,sizeof *cmd);if(!cmd)goto failed;
    uintptr_t mapping,mutex;ti_view_handles(view,&mapping,&mutex);
    swprintf(cmd,66000,L"\"%ls\" --run \"%ls\" --map %llu --mutex %llu --assets \"%ls\"",self_path,r->temp,(unsigned long long)mapping,(unsigned long long)mutex,assetdir);
    ok=CreateProcessW(self_path,cmd,NULL,NULL,TRUE,CREATE_NO_WINDOW|CREATE_SUSPENDED,NULL,NULL,&si,&pi);free(cmd);
    if(!ok)goto failed;
    if(job&&!AssignProcessToJobObject(job,pi.hProcess)){
        /* A parent job may prohibit nested jobs. Explicit Stop remains available. */
    }
    if(!DuplicateHandle(GetCurrentProcess(),pi.hProcess,GetCurrentProcess(),&r->process,0,FALSE,DUPLICATE_SAME_ACCESS))goto failed;
    r->window=window;r->output=out_r;
    HANDLE thread=CreateThread(NULL,0,read_output,r,0,NULL);if(!thread)goto failed;
    CloseHandle(thread);CloseHandle(out_w);CloseHandle(in_r);out_w=in_r=NULL;
    process=pi.hProcess;input_pipe=in_w;stopping=0;sending=0;generation++;free(assetdir);
    SetWindowTextW(console,L"");SetWindowTextW(input,L"");preview_open=1;RECT run_area;GetClientRect(window,&run_area);layout(run_area.right,run_area.bottom);set_status(L"Program dziala. Odpowiedzi wpisuj pod konsola. Stop przerywa program.");state();
    ResumeThread(pi.hThread);CloseHandle(pi.hThread);SetFocus(input);return;
failed:
    if(pi.hProcess){TerminateProcess(pi.hProcess,1);CloseHandle(pi.hProcess);}if(pi.hThread)CloseHandle(pi.hThread);
    if(r->process)CloseHandle(r->process);if(out_r)CloseHandle(out_r);if(out_w)CloseHandle(out_w);if(in_r)CloseHandle(in_r);if(in_w)CloseHandle(in_w);
    DeleteFileW(r->temp);free(r);free(assetdir);error_box(L"Nie udalo sie uruchomic programu Titanium.");
}
static DWORD WINAPI write_input(void *arg) {
    Sender *s=arg;DWORD written=0,total=0;int ok=1;
    while(total<s->length){if(!WriteFile(s->pipe,s->text+total,s->length-total,&written,NULL)||!written){ok=0;break;}total+=written;}
    CloseHandle(s->pipe);free(s->text);PostMessageW(s->window,MSG_INPUT_DONE,ok,(LPARAM)s->generation);free(s);return 0;
}
static void send_input(void) {
    if(!process||!input_pipe||sending||stopping)return;
    wchar_t *w=control_text(input);if(!w)return;
    size_t n;char *s=utf8(w,&n);if(!s){free(w);return;}
    if(n>8192){free(w);free(s);error_box(L"Odpowiedz moze miec najwyzej 8192 bajty UTF-8.");return;}
    Sender *a=calloc(1,sizeof *a);if(!a){free(s);free(w);return;}
    a->text=malloc(n+2);if(!a->text){free(a);free(s);free(w);return;}
    memcpy(a->text,s,n);a->text[n]='\n';a->length=(DWORD)n+1;a->window=window;a->generation=generation;free(s);
    if(!DuplicateHandle(GetCurrentProcess(),input_pipe,GetCurrentProcess(),&a->pipe,0,FALSE,DUPLICATE_SAME_ACCESS)){free(a->text);free(a);free(w);return;}
    HANDLE t=CreateThread(NULL,0,write_input,a,0,NULL);
    if(!t){CloseHandle(a->pipe);free(a->text);free(a);free(w);return;}CloseHandle(t);
    sending=1;state();append_console(w);append_console(L"\r\n");free(w);SetWindowTextW(input,L"");
}
static void stop_run(void) {
    if(!process||stopping)return;stopping=1;TerminateProcess(process,130);
    if(view)ti_view_stop(view);
    if(input_pipe){CloseHandle(input_pipe);input_pipe=NULL;}state();set_status(L"Zatrzymywanie programu…");
}
static void export_exe(void) {
    if(process)return;size_t n;char *s=source(&n);if(!s)return;
    int classic=classic_mode(s,n);if(classic){
        wchar_t output[32768]=L"Moj-program.html";OPENFILENAMEW of={0};of.lStructSize=sizeof of;of.hwndOwner=window;of.lpstrFile=output;of.nMaxFile=32768;of.lpstrFilter=L"Samodzielny program klasyczny (*.html)\0*.html\0";of.lpstrDefExt=L"html";of.Flags=OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST;
        if(GetSaveFileNameW(&of)){char e[256];if(!ti_legacy_export(self_path,output,s,n,classic,e)){wchar_t*w=wide(e,-1);error_box(w?w:L"Nie można zapisać programu klasycznego.");free(w);}else set_status(L"Zapisano samodzielny program HTML z oryginalnym silnikiem klasycznym.");}free(s);return;
    }
    if(!compile_source(s,n)){free(s);return;}
    wchar_t *path=calloc(32768,sizeof *path);if(!path){free(s);return;}wcscpy(path,L"Moj-program.exe");
    if(choose_path(path,1,1)){
        wchar_t *root=calloc(32768,sizeof *root),error[512]={0};
        if(root&&asset_root(root)&&ti_assets_copy(root,path,error)){
            TiError pe;TiProgram*program=ti_compile(s,n,&pe);int app_kind=ti_program_is_app(program);ti_free(program);
            if(atomic_write(path,s,n,app_kind?2:1)){set_status(L"Zbudowano EXE i skopiowano assety.");MessageBoxW(window,L"Gotowe. Otworz zapisany EXE dwuklikiem.\nDla gry 2D zachowaj folder assety obok EXE.",L"Titanium",MB_OK|MB_ICONINFORMATION);}
        }else error_box(error[0]?error:L"Nie mozna przygotowac assetow.");free(root);
    }free(path);free(s);
}
static void help(void) {
    MessageBoxW(window,
        L"TITANIUM NATIVE " TI_VERSION_W L" - JEDNA ZASADA\n\n"
        L"Jedno polecenie na wiersz. Argumenty oddzielaj spacjami.\n"
        L"Bez wymaganych nawiasow, przecinkow i srednikow.\n\n"
        L"pisz \"Czesc!\"\n"
        L"ustaw punkty 0\n"
        L"dodaj punkty 1\n"
        L"pisz \"Punkty:\" punkty\n\n"
        L"F5 uruchamia, Shift+F5 zatrzymuje. Odpowiedz wpisz pod konsola.\n"
        L"Przycisk Komendy pokazuje wszystkie istniejace polecenia.\n"
        L"Menu Przyklady: 14 lekcji, gry, aplikacje i pamiec.\n\n"
        L"wywolaj 2D\n"
        L"prostokat gracz 40 40 32 32 niebieski\n"
        L"steruj gracz 220\n"
        L"zawsze\nkoniec\n\n"
        L"Ctrl+Spacja: podpowiedzi. Tab: wstaw. Autokorekta po Enter.\n"
        L"Program > Autokorekta polecen wlacza lub wylacza korekte.\n"
        L"Kliknij podglad, aby sterowac WASD lub strzalkami.\n"
        L"Obrazy PNG/JPG/BMP umiesc w folderze assety obok pliku .ti.\n"
        L"Dla niezapisanego kodu: assety obok " TI_EXE_NAME_W L".\n"
        L"Plik > Otworz folder assety pokazuje wlasciwy folder.\n"
        L"Zapisz zachowuje kod .ti; Zbuduj EXE tworzy program i kopiuje assety.",
        L"Titanium - jak zaczac",MB_OK|MB_ICONINFORMATION);
}

static void filter_commands(void){
 int category=(int)SendMessageW(category_box,CB_GETCURSEL,0,0);
 wchar_t query[80];GetWindowTextW(searchbox,query,80);char q[240]={0};WideCharToMultiByte(CP_UTF8,0,query,-1,q,240,NULL,NULL);
 for(char*p=q;*p;p++)if(*p>='A'&&*p<='Z')*p+=32;
 SendMessageW(commandlist,LB_RESETCONTENT,0,0);
 for(size_t i=0;;i++){const char*name=ti_assist_word(i);if(!name)break;const TiCommand*c=ti_command(name);
  if(category>0){int group=c?c->game:0;int want=category==1?0:category==2?1:category==3?2:3;if(group!=want)continue;}
  if(*q&&!strstr(name,q)&&!(c&&strstr(c->description,q)))continue;
  wchar_t w[64];MultiByteToWideChar(CP_UTF8,0,name,-1,w,64);LRESULT n=SendMessageW(commandlist,LB_ADDSTRING,0,(LPARAM)w);SendMessageW(commandlist,LB_SETITEMDATA,n,(LPARAM)i);
 }
 SendMessageW(commandlist,LB_SETCURSEL,0,0);
}
static const char*selected_command(void){LRESULT n=SendMessageW(commandlist,LB_GETCURSEL,0,0);if(n==LB_ERR)return NULL;return ti_assist_word((size_t)SendMessageW(commandlist,LB_GETITEMDATA,n,0));}
static void command_description(void){
 const char*n=selected_command();const TiCommand*c=n?ti_command(n):NULL;wchar_t w[1500];
 if(c){wchar_t*a=wide(c->syntax,-1),*b=wide(c->description,-1);swprintf(w,1500,L"%ls\r\n\r\n%ls",a?a:L"",b?b:L"");free(a);free(b);}
 else swprintf(w,1500,L"%hs\r\n\r\nElement składni Titanium.\r\nPodpowiedzi: Ctrl+Spacja.\r\nWstawienie podpowiedzi: Tab.",n?n:"");
 SetWindowTextW(commanddetail,w);
}
static void command(int id) {
    if(id>=ID_SAMPLE&&id<ID_SAMPLE+TI_EXAMPLE_COUNT){if(may_discard()){load_editor(ti_examples[id-ID_SAMPLE],NULL,1);set_status(L"Przyklad gotowy. Nacisnij F5. Zmien kod i uruchom ponownie.");}return;}
    switch(id){
    case ID_MENU:{POINT p;RECT r;GetWindowRect(menu_button,&r);p=(POINT){r.left,r.bottom};TrackPopupMenu(main_menu,TPM_LEFTALIGN|TPM_TOPALIGN,p.x,p.y,0,window,NULL);break;}
    case ID_SHOWCASE:command(ID_SAMPLE+14);break;
    case ID_CLASSIC01:engine_mode=1;set_status(L"Tryb zgodności 0.1. Uruchom otworzy oryginalny silnik klasyczny.");break;
    case ID_CLASSIC02:engine_mode=2;set_status(L"Tryb zgodności 0.2. Uruchom otworzy oryginalny silnik klasyczny.");break;
    case ID_ENGINE_AUTO:engine_mode=0;set_status(L"Automatyczny wybór silnika. Stare komendy 0.3–0.7 obsługuje silnik natywny.");break;
    case ID_DRAWER:preview_open=!preview_open;goto relayout;
    case ID_NEW_APP:if(may_discard())load_editor(L"aplikacja \"Moja aplikacja\" 640 420\r\netykieta tytul \"Witaj w Titanium\" 24 20 580 30\r\npole imie \"\" 24 70 350 32\r\nprzycisk witaj \"Przywitaj\" 390 70 180 32\r\netykieta wynik \"Wpisz imie i nacisnij przycisk.\" 24 130 580 50\r\nzawsze\r\njesli kliknieto witaj\r\nustaw_tekst wynik \"Czesc, \" + wartosc imie\r\nkoniec\r\nkoniec\r\n",NULL,1);break;
    case ID_NEW_GAME:if(may_discard())load_editor(ti_examples[8],NULL,1);break;
    case ID_FIND:find_open=!find_open;{RECT r;GetClientRect(window,&r);layout(r.right,r.bottom);}if(find_open)SetFocus(find_box);break;
    case ID_FIND_NEXT:{wchar_t q[256];GetWindowTextW(find_box,q,256);if(!ti_editor_find(q))set_status(L"Nie znaleziono tekstu.");break;}
    case ID_FOCUS:focus_mode=!focus_mode;goto relayout;
    case ID_SIDEBAR:sidebar_open=!sidebar_open;goto relayout;
    case ID_PREVIEW:preview_open=!preview_open;goto relayout;
    case ID_ZOOMIN:ti_editor_zoom(1);break;case ID_ZOOMOUT:ti_editor_zoom(-1);break;case ID_ZOOMRESET:ti_editor_zoom(0);break;
    case ID_SYNTAX:set_status(L"Stabilny edytor tekstowy: kolorowanie nie zmienia i nie zasłania kodu.");break;
    relayout:{RECT r;GetClientRect(window,&r);layout(r.right,r.bottom);CheckMenuItem(main_menu,ID_FOCUS,MF_BYCOMMAND|(focus_mode?MF_CHECKED:MF_UNCHECKED));CheckMenuItem(main_menu,ID_SIDEBAR,MF_BYCOMMAND|(sidebar_open?MF_CHECKED:MF_UNCHECKED));CheckMenuItem(main_menu,ID_PREVIEW,MF_BYCOMMAND|(preview_open?MF_CHECKED:MF_UNCHECKED));break;}
    case ID_CORRECT:ti_editor_autocorrect(!ti_editor_autocorrect_enabled());CheckMenuItem(main_menu,ID_CORRECT,MF_BYCOMMAND|(ti_editor_autocorrect_enabled()?MF_CHECKED:MF_UNCHECKED));set_status(ti_editor_autocorrect_enabled()?L"Autokorekta włączona. Ctrl+Z cofa poprawkę.":L"Autokorekta wyłączona. Podpowiedzi: Ctrl+Spacja.");break;
    case ID_COMPLETE:ti_editor_complete();break;
    case ID_INSERT:{const char*n=selected_command();if(n)ti_editor_insert(n);break;}
    case ID_NEW:if(may_discard())load_editor(L"pisz \"Czesc!\"\r\n",NULL,0);break;
    case ID_OPEN:open_code(NULL);break;case ID_SAVE:save_code(0);break;case ID_SAVEAS:save_code(1);break;
    case ID_CHECK:{if(process)break;size_t n;char *s=source(&n);if(s){if(classic_mode(s,n)){set_status(L"Kod klasyczny 0.1–0.2. Uruchom korzysta z oryginalnego parsera i silnika.");free(s);break;}if(compile_source(s,n)){SetWindowTextW(console,L"Kod poprawny. Nacisnij F5, aby uruchomic.\r\n");set_status(L"Sprawdzono skladnie kodu.");}free(s);}break;}
    case ID_RUN:start_run();break;case ID_STOP:stop_run();break;case ID_SEND:send_input();break;case ID_EXPORT:export_exe();break;
    case ID_HELP:help();break;
    case ID_COMMANDS:show_commands();break;
    case ID_ASSETS:{wchar_t *root=calloc(32768,sizeof *root);if(root&&asset_root(root)){
        if(CreateDirectoryW(root,NULL)||GetLastError()==ERROR_ALREADY_EXISTS)ShellExecuteW(window,L"open",root,NULL,NULL,SW_SHOWNORMAL);
        else error_box(L"Nie mozna utworzyc folderu assety. Zapisz program w swoim folderze.");}free(root);break;}
    case ID_ABOUT:MessageBoxW(window,L"Titanium Native " TI_VERSION_W L"\nPolski jezyk programowania do nauki.\n\nNatywny kompilator do kodu posredniego i maszyna wirtualna w C. Interfejs Win32.\nBez przegladarki i WebView2.\n\nEksport EXE zawiera natywny silnik oraz Twoj kod Titanium.",L"O Titanium",MB_OK);break;
    case ID_EXIT:SendMessageW(window,WM_CLOSE,0,0);break;
    }
}
static LRESULT CALLBACK input_subclass(HWND h,UINT m,WPARAM w,LPARAM l) {
    if(m==WM_CHAR&&w=='\r'){send_input();return 0;}
    return CallWindowProcW(input_proc,h,m,w,l);
}
static HWND control(const wchar_t *cls,const wchar_t *text,DWORD style,int id) {
    HWND h=CreateWindowExW(!wcscmp(cls,L"EDIT")?WS_EX_CLIENTEDGE:0,cls,text,WS_CHILD|WS_VISIBLE|style,0,0,0,0,window,(HMENU)(INT_PTR)id,GetModuleHandleW(NULL),NULL);
    SendMessageW(h,WM_SETFONT,(WPARAM)ui,TRUE);SetWindowTheme(h,L"DarkMode_Explorer",NULL);return h;
}
static void place(HWND h,TiRect r){MoveWindow(h,r.x,r.y,r.w,r.h,TRUE);}
static void layout(int w,int h){
 ti_layout(w,h,sidebar_open,preview_open,focus_mode,&studio_layout);TiRect code=studio_layout.code,lib=studio_layout.library,nav=studio_layout.navigation;
 MoveWindow(brand,20,15,225,31,TRUE);MoveWindow(subtitle,250,24,w-616,20,TRUE);
 MoveWindow(menu_button,w-148,17,124,35,TRUE);int x=20,bw[]={58,76,76,88,126,62,112,100};
 for(int i=0;i<8;i++){MoveWindow(buttons[i],x,62,bw[i],34,TRUE);x+=bw[i]+8;}
 MoveWindow(drawer_button,w-354,17,194,35,TRUE);
 ShowWindow(nav_label,nav.w?SW_SHOW:SW_HIDE);MoveWindow(nav_label,nav.x,nav.y,nav.w,24,TRUE);
 for(int i=0;i<5;i++){ShowWindow(nav_buttons[i],nav.w?SW_SHOW:SW_HIDE);MoveWindow(nav_buttons[i],nav.x,nav.y+42+i*58,nav.w,46,TRUE);}
 HWND sides[]={sidebar_label,category_box,searchbox,commandlist,commanddetail,insert_button};for(unsigned i=0;i<sizeof sides/sizeof*sides;i++)ShowWindow(sides[i],lib.w?SW_SHOW:SW_HIDE);
 MoveWindow(sidebar_label,lib.x,lib.y,lib.w,24,TRUE);MoveWindow(category_box,lib.x,lib.y+34,lib.w,180,TRUE);MoveWindow(searchbox,lib.x,lib.y+74,lib.w,32,TRUE);
 int list_h=lib.h-332;if(list_h<60)list_h=60;MoveWindow(commandlist,lib.x,lib.y+122,lib.w,list_h,TRUE);MoveWindow(commanddetail,lib.x,lib.y+list_h+256-122,lib.w,148,TRUE);MoveWindow(insert_button,lib.x,lib.y+lib.h-38,lib.w,34,TRUE);
 MoveWindow(code_label,code.x,code.y,code.w,24,TRUE);int edit_y=code.y+34;
 ShowWindow(find_box,find_open?SW_SHOW:SW_HIDE);ShowWindow(find_button,find_open?SW_SHOW:SW_HIDE);if(find_open){MoveWindow(find_box,code.x,edit_y,code.w-100,30,TRUE);MoveWindow(find_button,code.x+code.w-92,edit_y,92,30,TRUE);edit_y+=40;}
 gutter=(RECT){code.x,edit_y,code.x+44,code.y+code.h};MoveWindow(editor,code.x+44,edit_y,code.w-44,code.y+code.h-edit_y,TRUE);
 int drawer=studio_layout.preview.w>0;HWND lower[]={view_label,console_label,console,answer_label,input,send_button};for(unsigned i=0;i<sizeof lower/sizeof*lower;i++)ShowWindow(lower[i],drawer?SW_SHOW:SW_HIDE);
 TiRect v=studio_layout.preview,c=studio_layout.console;MoveWindow(view_label,v.x,v.y-24,v.w,20,TRUE);MoveWindow(console_label,c.x,c.y-24,c.w,20,TRUE);
 if(view){place(ti_view_hwnd(view),v);ShowWindow(ti_view_hwnd(view),drawer&&preview_active?SW_SHOW:SW_HIDE);}
 MoveWindow(console,c.x,c.y,c.w,c.h-66,TRUE);MoveWindow(answer_label,c.x,c.y+c.h-58,c.w,18,TRUE);MoveWindow(input,c.x,c.y+c.h-32,c.w-84,30,TRUE);MoveWindow(send_button,c.x+c.w-76,c.y+c.h-32,76,30,TRUE);
 place(status,studio_layout.status);splitter_rect=(RECT){0,0,0,0};InvalidateRect(window,NULL,FALSE);
}
static void style_menu(HMENU menu,int top){
 int count=GetMenuItemCount(menu);for(int i=0;i<count&&menu_label_count<256;i++){
  MENUITEMINFOW info={0};info.cbSize=sizeof info;info.fMask=MIIM_STRING|MIIM_SUBMENU|MIIM_FTYPE;wchar_t text[128]={0};info.dwTypeData=text;info.cch=128;if(!GetMenuItemInfoW(menu,i,TRUE,&info))continue;
  TiMenuLabel*label=&menu_labels[menu_label_count++];wcsncpy(label->text,text,127);label->top=top;label->separator=(info.fType&MFT_SEPARATOR)!=0;
  MENUITEMINFOW change={0};change.cbSize=sizeof change;change.fMask=MIIM_FTYPE|MIIM_DATA;change.fType=info.fType|MFT_OWNERDRAW;change.dwItemData=(ULONG_PTR)label;SetMenuItemInfoW(menu,i,TRUE,&change);if(info.hSubMenu)style_menu(info.hSubMenu,0);
 }
}
static HMENU menu(void) {
    HMENU root=CreatePopupMenu(),file=CreatePopupMenu(),examples=CreatePopupMenu(),program=CreatePopupMenu(),info=CreatePopupMenu(),viewmenu=CreatePopupMenu();
    AppendMenuW(file,MF_STRING,ID_NEW,L"&Nowy\tCtrl+N");AppendMenuW(file,MF_STRING,ID_NEW_APP,L"Nowa aplikacja okienkowa");AppendMenuW(file,MF_STRING,ID_NEW_GAME,L"Nowa gra 2D");AppendMenuW(file,MF_STRING,ID_OPEN,L"&Otworz…\tCtrl+O");
    AppendMenuW(file,MF_STRING,ID_SAVE,L"&Zapisz\tCtrl+S");AppendMenuW(file,MF_STRING,ID_SAVEAS,L"Zapisz jako…");
    AppendMenuW(file,MF_SEPARATOR,0,NULL);AppendMenuW(file,MF_STRING,ID_EXPORT,L"Zbuduj EXE…");AppendMenuW(file,MF_STRING,ID_EXIT,L"Zakoncz");
    AppendMenuW(file,MF_STRING,ID_ASSETS,L"Otworz folder assety");
    AppendMenuW(program,MF_STRING,ID_CORRECT,L"Autokorekta poleceń (opcjonalna)");
    AppendMenuW(program,MF_STRING,ID_COMPLETE,L"Podpowiedz komendę\tCtrl+Spacja");
    AppendMenuW(program,MF_STRING,ID_ENGINE_AUTO,L"Silnik: automatycznie (domyślnie)");AppendMenuW(program,MF_STRING,ID_CLASSIC01,L"Silnik klasyczny 0.1");AppendMenuW(program,MF_STRING,ID_CLASSIC02,L"Silnik klasyczny 0.2");AppendMenuW(program,MF_STRING,ID_CHECK,L"Sprawdz kod");AppendMenuW(program,MF_STRING,ID_RUN,L"Uruchom\tF5");AppendMenuW(program,MF_STRING,ID_STOP,L"Stop\tShift+F5");
    for(int i=0;i<TI_EXAMPLE_COUNT;i++)AppendMenuW(examples,MF_STRING,ID_SAMPLE+i,ti_titles[i]);
    AppendMenuW(info,MF_STRING,ID_HELP,L"Jak zaczac\tF1");AppendMenuW(info,MF_STRING,ID_ABOUT,L"O Titanium");
    AppendMenuW(info,MF_STRING,ID_COMMANDS,L"Wszystkie komendy");
    AppendMenuW(viewmenu,MF_STRING|MF_CHECKED,ID_SIDEBAR,L"Biblioteka komend");AppendMenuW(viewmenu,MF_STRING|MF_CHECKED,ID_PREVIEW,L"Podgląd i konsola");AppendMenuW(viewmenu,MF_STRING,ID_FOCUS,L"Tryb skupienia\tF11");AppendMenuW(viewmenu,MF_STRING,ID_FIND,L"Znajdź w kodzie\tCtrl+F");AppendMenuW(viewmenu,MF_STRING,ID_ZOOMIN,L"Powiększ kod\tCtrl++");AppendMenuW(viewmenu,MF_STRING,ID_ZOOMOUT,L"Pomniejsz kod\tCtrl+-");AppendMenuW(viewmenu,MF_STRING,ID_ZOOMRESET,L"Rozmiar domyślny\tCtrl+0");
    AppendMenuW(root,MF_POPUP,(UINT_PTR)viewmenu,L"&Widok");AppendMenuW(root,MF_POPUP,(UINT_PTR)file,L"&Plik");AppendMenuW(root,MF_POPUP,(UINT_PTR)program,L"&Program");AppendMenuW(root,MF_POPUP,(UINT_PTR)examples,L"&Przyklady");AppendMenuW(root,MF_POPUP,(UINT_PTR)info,L"P&omoc");style_menu(root,0);return root;
}
static LRESULT CALLBACK wndproc(HWND h,UINT m,WPARAM w,LPARAM l) {
    switch(m){
    case WM_CREATE:{window=h;HDC dc=GetDC(h);int dpi=GetDeviceCaps(dc,LOGPIXELSY);ReleaseDC(h,dc);
        ui=CreateFontW(-MulDiv(10,dpi,72),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        mono=CreateFontW(-MulDiv(12,dpi,72),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH,L"Consolas");
        page_brush=CreateSolidBrush(RGB(14,19,28));white_brush=CreateSolidBrush(RGB(27,36,50));
        brand_font=CreateFontW(-MulDiv(22,dpi,72),0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        brand=control(L"STATIC",L"TITANIUM  /  08",0,0);SendMessageW(brand,WM_SETFONT,(WPARAM)brand_font,TRUE);
        subtitle=control(L"STATIC",L"STUDIO  " TI_VERSION_W L"    /    GRY · APLIKACJE · KOD",0,0);
        nav_label=control(L"STATIC",L"TWÓJ PROJEKT",0,0);const wchar_t*nav_names[]={L"Nowy kod",L"Gra 2D",L"Aplikacja",L"NEON • pokaz",L"Otwórz plik"};int nav_ids[]={ID_NEW,ID_NEW_GAME,ID_NEW_APP,ID_SHOWCASE,ID_OPEN};for(int i=0;i<5;i++)nav_buttons[i]=control(L"BUTTON",nav_names[i],WS_TABSTOP|BS_OWNERDRAW,nav_ids[i]);
        menu_button=control(L"BUTTON",L"Menu  ▾",WS_TABSTOP|BS_OWNERDRAW,ID_MENU);drawer_button=control(L"BUTTON",L"Podgląd / konsola",WS_TABSTOP|BS_OWNERDRAW,ID_DRAWER);
        sidebar_label=control(L"STATIC",L"PALETA KOMEND",0,0);
        category_box=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,ID_CATEGORY);const wchar_t*groups[]={L"Wszystkie",L"Język i obliczenia",L"Gry 2D",L"Aplikacje",L"Pamięć i bity"};for(int k=0;k<5;k++)SendMessageW(category_box,CB_ADDSTRING,0,(LPARAM)groups[k]);SendMessageW(category_box,CB_SETCURSEL,0,0);
        find_box=control(L"EDIT",L"",WS_TABSTOP|ES_AUTOHSCROLL,ID_FIND_BOX);SendMessageW(find_box,EM_SETCUEBANNER,0,(LPARAM)L"Znajdź w kodzie…");find_button=control(L"BUTTON",L"Następny",WS_TABSTOP|BS_OWNERDRAW,ID_FIND_NEXT);
        searchbox=control(L"EDIT",L"",WS_TABSTOP|ES_AUTOHSCROLL,ID_SEARCH);SendMessageW(searchbox,EM_SETCUEBANNER,0,(LPARAM)L"Szukaj komendy…");
        commandlist=control(L"LISTBOX",L"",WS_TABSTOP|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT,ID_REFERENCE);
        commanddetail=control(L"EDIT",L"",ES_MULTILINE|ES_READONLY|WS_VSCROLL,185);
        insert_button=control(L"BUTTON",L"Wstaw komendę",WS_TABSTOP|BS_OWNERDRAW,ID_INSERT);filter_commands();command_description();
        for(int i=0;i<8;i++)buttons[i]=control(L"BUTTON",button_names[i],WS_TABSTOP|BS_OWNERDRAW,button_ids[i]);
        code_label=control(L"STATIC",L"KOD ŹRÓDŁOWY   •   UTF-8   •   Ctrl+Spacja: podpowiedzi",0,0);
        editor=ti_editor_create(window,ID_EDITOR,mono);if(!editor)return -1;
        console_label=control(L"STATIC",L"Konsola — wynik programu i komunikaty o bledach",0,0);
        view_label=control(L"STATIC",L"SCENA 2D   /   kliknij, aby sterować",0,0);
        console=control(L"EDIT",L"",WS_TABSTOP|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY|WS_VSCROLL,ID_CONSOLE);
        answer_label=control(L"STATIC",L"Odpowiedz:",0,0);input=control(L"EDIT",L"",WS_TABSTOP|ES_AUTOHSCROLL,ID_INPUT);
        send_button=control(L"BUTTON",L"Wyslij ↵",WS_TABSTOP|BS_OWNERDRAW,ID_SEND);
        status=control(L"STATIC",L"Gotowy  ·  F5 uruchom  ·  F11 skupienie  ·  Ctrl+F szukaj  ·  Ctrl+Spacja podpowiedzi",0,190);
        SendMessageW(editor,WM_SETFONT,(WPARAM)mono,TRUE);SendMessageW(console,WM_SETFONT,(WPARAM)mono,TRUE);
        SendMessageW(input,WM_SETFONT,(WPARAM)mono,TRUE);SendMessageW(console,EM_LIMITTEXT,1100000,0);SendMessageW(input,EM_LIMITTEXT,8192,0);
        input_proc=(WNDPROC)SetWindowLongPtrW(input,GWLP_WNDPROC,(LONG_PTR)input_subclass);
        load_editor(ti_examples[0],NULL,0);state();SetTimer(h,1,50,NULL);return 0;
    }
    case WM_COMMAND:
        if(LOWORD(w)==ID_CATEGORY&&HIWORD(w)==CBN_SELCHANGE){filter_commands();command_description();return 0;}
        if(LOWORD(w)==ID_EDITOR&&HIWORD(w)==EN_CHANGE){if(!loading&&!dirty){dirty=1;title();}ti_editor_changed();return 0;}
        if(LOWORD(w)==ID_SEARCH&&HIWORD(w)==EN_CHANGE){filter_commands();command_description();return 0;}
        if(LOWORD(w)==ID_REFERENCE){if(HIWORD(w)==LBN_SELCHANGE)command_description();if(HIWORD(w)==LBN_DBLCLK)command(ID_INSERT);return 0;}
        command(LOWORD(w));return 0;
    case WM_LBUTTONDOWN:{POINT p={GET_X_LPARAM(l),GET_Y_LPARAM(l)};if(PtInRect(&splitter_rect,p)){dragging=1;SetCapture(h);return 0;}break;}
    case WM_MOUSEMOVE:if(dragging){RECT r;GetClientRect(h,&r);int start=16+((sidebar_open&&!focus_mode)?244:0);split_ratio=(double)(GET_X_LPARAM(l)-start)/(r.right-start-16);if(split_ratio<.35)split_ratio=.35;if(split_ratio>.78)split_ratio=.78;layout(r.right,r.bottom);return 0;}break;
    case WM_LBUTTONUP:if(dragging){dragging=0;ReleaseCapture();return 0;}break;
    case WM_SETCURSOR:{POINT p;GetCursorPos(&p);ScreenToClient(h,&p);if(PtInRect(&splitter_rect,p)){SetCursor(LoadCursorW(NULL,IDC_SIZEWE));return TRUE;}break;}
    case WM_SIZE:layout(LOWORD(l),HIWORD(l));return 0;
    case WM_TIMER:if(w==1){ti_editor_tick();int active=view&&ti_view_alive(view)&&ti_view_active(view);if(active!=preview_active){preview_active=active;RECT r;GetClientRect(h,&r);layout(r.right,r.bottom);}}return 0;
    case WM_GETMINMAXINFO:((MINMAXINFO*)l)->ptMinTrackSize=(POINT){1000,680};return 0;
    case WM_ERASEBKGND:{RECT r;GetClientRect(h,&r);FillRect((HDC)w,&r,page_brush);return 1;}
    case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);ti_editor_gutter(dc,gutter);
        TiRect code=studio_layout.code,nav=studio_layout.navigation,lib=studio_layout.library;SetBkMode(dc,TRANSPARENT);HPEN pen=CreatePen(PS_SOLID,1,RGB(43,57,73));HGDIOBJ old=SelectObject(dc,pen);MoveToEx(dc,16,104,NULL);RECT client;GetClientRect(h,&client);LineTo(dc,client.right-16,104);SelectObject(dc,old);DeleteObject(pen);
        if(nav.w){RECT text={nav.x,nav.y+360,nav.x+nav.w,nav.y+nav.h};SetTextColor(dc,RGB(113,137,158));SelectObject(dc,ui);DrawTextW(dc,L"F5  uruchom\nF11  skupienie\nCtrl+S  zapisz\nCtrl+F  wyszukaj\n\nStare komendy.\nNowe możliwości.",-1,&text,DT_LEFT|DT_WORDBREAK);}
        if(!preview_active&&studio_layout.preview.w){TiRect v=studio_layout.preview;RECT r={v.x,v.y,v.x+v.w,v.y+v.h};HBRUSH b=CreateSolidBrush(RGB(14,24,35));FillRect(dc,&r,b);DeleteObject(b);InflateRect(&r,-22,-22);SetTextColor(dc,RGB(116,159,183));SelectObject(dc,ui);DrawTextW(dc,L"TITANIUM / SCENA\n\nWybierz NEON • pokaz, a potem Uruchom.\nGry 2D i aplikacje korzystają z tej samej prostej składni.",-1,&r,DT_LEFT|DT_WORDBREAK);}
        (void)code;(void)lib;EndPaint(h,&ps);return 0;}
    case WM_MEASUREITEM:{MEASUREITEMSTRUCT*d=(MEASUREITEMSTRUCT*)l;if(d->CtlType==ODT_MENU){TiMenuLabel*t=(TiMenuLabel*)d->itemData;d->itemHeight=t->separator?8:t->top?26:30;d->itemWidth=t->top?(UINT)(wcslen(t->text)*8+20):300;return TRUE;}break;}
    case WM_DRAWITEM:{DRAWITEMSTRUCT*d=(DRAWITEMSTRUCT*)l;
        if(d->CtlType==ODT_MENU){TiMenuLabel*t=(TiMenuLabel*)d->itemData;if(!t)break;HBRUSH b=CreateSolidBrush((d->itemState&ODS_SELECTED)?RGB(39,66,91):RGB(21,29,42));FillRect(d->hDC,&d->rcItem,b);DeleteObject(b);RECT r=d->rcItem;InflateRect(&r,-12,0);SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,(d->itemState&ODS_DISABLED)?RGB(92,109,133):RGB(217,228,242));SelectObject(d->hDC,ui);if(!t->separator){wchar_t text[128];wcscpy(text,t->text);wchar_t*tab=wcschr(text,L'\t');if(tab){*tab++=0;DrawTextW(d->hDC,tab,-1,&r,DT_RIGHT|DT_VCENTER|DT_SINGLELINE);}DrawTextW(d->hDC,text,-1,&r,DT_LEFT|DT_VCENTER|DT_SINGLELINE);}return TRUE;}
        if(d->CtlType!=ODT_BUTTON)break;int disabled=(d->itemState&ODS_DISABLED)!=0;
        COLORREF bg=disabled?RGB(32,40,53):(d->CtlID==ID_RUN||d->CtlID==ID_SHOWCASE)?RGB(20,129,134):d->CtlID==ID_EXPORT?RGB(47,91,165):RGB(27,36,50);if(d->itemState&ODS_SELECTED)bg=RGB(43,64,88);
        HBRUSH b=CreateSolidBrush(bg);HPEN p=CreatePen(PS_SOLID,1,disabled?RGB(38,48,65):RGB(45,61,82));HGDIOBJ oldb=SelectObject(d->hDC,b),oldp=SelectObject(d->hDC,p);RoundRect(d->hDC,d->rcItem.left,d->rcItem.top,d->rcItem.right,d->rcItem.bottom,9,9);SelectObject(d->hDC,oldb);SelectObject(d->hDC,oldp);DeleteObject(b);DeleteObject(p);
        SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,disabled?RGB(92,109,133):(d->CtlID==ID_RUN||d->CtlID==ID_SHOWCASE||d->CtlID==ID_EXPORT)?RGB(244,249,255):RGB(217,228,242));SelectObject(d->hDC,ui);wchar_t t[80];GetWindowTextW(d->hwndItem,t,80);DrawTextW(d->hDC,t,-1,(RECT*)&d->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE);if(d->itemState&ODS_FOCUS){RECT r=d->rcItem;InflateRect(&r,-4,-4);DrawFocusRect(d->hDC,&r);}return TRUE;}
    case WM_CTLCOLOREDIT:case WM_CTLCOLORLISTBOX:case WM_CTLCOLORSTATIC:{
        HWND c=(HWND)l;SetTextColor((HDC)w,RGB(200,215,234));
        if(c==editor){SetTextColor((HDC)w,RGB(224,234,244));SetBkColor((HDC)w,RGB(19,29,42));static HBRUSH editor_brush=NULL;if(!editor_brush)editor_brush=CreateSolidBrush(RGB(19,29,42));return (LRESULT)editor_brush;}
        if(c==console){SetTextColor((HDC)w,RGB(193,210,225));SetBkColor((HDC)w,RGB(23,31,44));static HBRUSH dark=NULL;if(!dark)dark=CreateSolidBrush(RGB(23,31,44));return (LRESULT)dark;}
        if(c==commandlist||c==searchbox||c==commanddetail||c==input){SetBkColor((HDC)w,RGB(27,36,50));return (LRESULT)white_brush;}
        SetBkColor((HDC)w,RGB(14,19,28));return (LRESULT)page_brush;}
    case MSG_OUTPUT:append_console((wchar_t*)l);free((void*)l);return 0;
    case MSG_INPUT_DONE:if((unsigned)l!=generation)return 0;sending=0;state();if(process&&!stopping){if(!w)set_status(L"Nie mozna wyslac odpowiedzi — program zakonczyl odbior.");SetFocus(input);}return 0;
    case MSG_DONE:{
        if(process)CloseHandle(process);process=NULL;if(input_pipe)CloseHandle(input_pipe);input_pipe=NULL;
        if(stopping){append_console(L"\r\n[Program zatrzymany]\r\n");set_status(L"Zatrzymano. Mozesz poprawic kod i nacisnac F5.");}
        else if(w==0){append_console(L"\r\n[Koniec programu]\r\n");set_status(L"Program zakonczyl sie poprawnie. Zmien kod i sprobuj ponownie.");}
        else {append_console(L"\r\n[Program zakonczony z bledem]\r\n");set_status(L"Sprawdz komunikat w konsoli.");}stopping=0;state();return 0;
    }
    case WM_CLOSE:if(may_discard()){if(process)TerminateProcess(process,130);DestroyWindow(h);}return 0;
    case WM_DESTROY:ti_editor_destroy();KillTimer(h,1);if(view){ti_view_destroy(view);view=NULL;}if(job)CloseHandle(job);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(h,m,w,l);
}
static int console_init(void) {
    int own=0;HANDLE out=GetStdHandle(STD_OUTPUT_HANDLE);
    if(!out||out==INVALID_HANDLE_VALUE){if(!AttachConsole(ATTACH_PARENT_PROCESS)){if(AllocConsole())own=1;}
        freopen("CONIN$","rb",stdin);freopen("CONOUT$","wb",stdout);freopen("CONOUT$","wb",stderr);}
    SetConsoleOutputCP(CP_UTF8);SetConsoleCP(CP_UTF8);setvbuf(stdout,NULL,_IONBF,0);setvbuf(stderr,NULL,_IONBF,0);return own;
}
static void wait_view(TiView *v){
    while(v&&ti_view_active(v)&&ti_view_alive(v)){
        MSG m;while(PeekMessageW(&m,NULL,0,0,PM_REMOVE)){if(m.message==WM_QUIT)return;TranslateMessage(&m);DispatchMessageW(&m);}
        MsgWaitForMultipleObjects(0,NULL,FALSE,16,QS_ALLINPUT);
    }
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE prev,PWSTR line,int show) {
    (void)prev;(void)line;GetModuleFileNameW(NULL,self_path,32768);
    int argc=0;wchar_t **argv=CommandLineToArgvW(GetCommandLineW(),&argc);
    if(argv&&argc>2&&(!wcscmp(argv[1],L"--run")||!wcscmp(argv[1],L"--check"))){
        /* Child --run inherits pipes; no console attach or hidden GUI is needed. */
        int check=!wcscmp(argv[1],L"--check");if(check)console_init();
        setvbuf(stdout,NULL,_IONBF,0);setvbuf(stderr,NULL,_IONBF,0);
        FILE *f=_wfopen(argv[2],L"rb");if(!f){fputs("Blad: nie mozna otworzyc kodu.\n",stderr);LocalFree(argv);return 2;}
        TiView *runner=NULL;TiHost host={0};int shared=0;
        if(!check){
            wchar_t *assets=calloc(32768,sizeof *assets);if(!assets){fclose(f);LocalFree(argv);return 2;}
            if(argc==9&&!wcscmp(argv[3],L"--map")&&!wcscmp(argv[5],L"--mutex")&&!wcscmp(argv[7],L"--assets")){
                runner=ti_view_connect((uintptr_t)_wcstoui64(argv[4],NULL,10),(uintptr_t)_wcstoui64(argv[6],NULL,10),argv[8]);shared=1;
            }else if(ti_assets_root(argv[2],assets))runner=ti_view_create(NULL,assets);
            free(assets);if(!runner){fputs("Blad: nie mozna utworzyc podgladu 2D.\n",stderr);fclose(f);LocalFree(argv);return 2;}host=ti_view_host(runner);
        }
        int code=ti_run_file_host(f,check,stdin,stdout,stderr,check?NULL:&host);fclose(f);
        if(!shared&&code==0)wait_view(runner);ti_view_destroy(runner);LocalFree(argv);return code;
    }
    FILE *self=_wfopen(self_path,L"rb");char *bundled=NULL;size_t length=0;uint64_t base=0;
    int package=self?ti_package_read(self,&bundled,&length,&base):-1;if(self)fclose(self);
    if(package<0){MessageBoxW(NULL,L"Plik EXE jest uszkodzony lub nie mozna go odczytac.",L"Titanium",MB_OK|MB_ICONERROR);if(argv)LocalFree(argv);return 1;}
    if(package==1){
        int own=0;DWORD ids[2];
        TiError app_error;TiProgram*classification=ti_compile(bundled,length,&app_error);int app_kind=ti_program_is_app(classification);ti_free(classification);if(!app_kind)own=console_init();
        /* A console-subsystem export gets its own console on double-click.
           Do not pause when launched from an existing terminal or a pipe. */
        if(!app_kind&&GetConsoleWindow()&&GetConsoleProcessList(ids,2)==1)own=1;
        wchar_t *assets=calloc(32768,sizeof *assets);TiView *runner=NULL;TiHost host={0};
        if(assets&&ti_assets_root(self_path,assets))runner=ti_view_create(NULL,assets);free(assets);
        if(!runner){fputs("Blad: nie mozna utworzyc podgladu 2D.\n",stderr);free(bundled);if(argv)LocalFree(argv);return 2;}host=ti_view_host(runner);
        TiError error;TiProgram *p=ti_compile(bundled,length,&error);free(bundled);
        int ok=p&&ti_execute_host(p,stdin,stdout,&error,&host);if(!ok){fprintf(stderr,"Blad - wiersz %d: %s\n",error.line,error.text);if(app_kind){wchar_t*message=wide(error.text,-1);MessageBoxW(NULL,message?message:L"Blad programu.",L"Titanium - blad aplikacji",MB_OK|MB_ICONERROR);free(message);}}ti_free(p);
        if(ok)wait_view(runner);ti_view_destroy(runner);
        if(own){fputs("\nNacisnij Enter, aby zamknac...",stdout);fflush(stdout);char rest[4];fgets(rest,sizeof rest,stdin);}if(argv)LocalFree(argv);return ok?0:1;
    }
    /* Use Windows DPI virtualization for consistent classic control sizing. */
    job=CreateJobObjectW(NULL,NULL);
    if(job){JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits={0};limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limits,sizeof limits);}
    WNDCLASSW wc={0};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);wc.lpszClassName=L"TitaniumNative04";wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(101));
    if(!RegisterClassW(&wc))return 1;
    main_menu=menu();
    HWND h=CreateWindowExW(0,wc.lpszClassName,L"Titanium Native " TI_VERSION_W,WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1440,940,NULL,NULL,instance,NULL);
    if(!h){error_box(L"Nie mozna utworzyc okna Titanium.");return 1;}
    dark_title(h);ShowWindow(h,show);UpdateWindow(h);if(argv&&argc==2)open_code(argv[1]);if(argv)LocalFree(argv);
    ACCEL acc[]={ {FVIRTKEY|FCONTROL,'N',ID_NEW},{FVIRTKEY|FCONTROL,'O',ID_OPEN},{FVIRTKEY|FCONTROL,'S',ID_SAVE},
        {FVIRTKEY,VK_F10,ID_MENU},{FVIRTKEY|FCONTROL,'F',ID_FIND},{FVIRTKEY,VK_F11,ID_FOCUS},{FVIRTKEY|FCONTROL,VK_OEM_PLUS,ID_ZOOMIN},{FVIRTKEY|FCONTROL,VK_OEM_MINUS,ID_ZOOMOUT},{FVIRTKEY|FCONTROL,'0',ID_ZOOMRESET},{FVIRTKEY,VK_F5,ID_RUN},{FVIRTKEY|FSHIFT,VK_F5,ID_STOP},{FVIRTKEY,VK_F1,ID_HELP} };
    HACCEL accelerators=CreateAcceleratorTableW(acc,sizeof acc/sizeof *acc);MSG msg;
    while(GetMessageW(&msg,NULL,0,0)>0){if(!TranslateAcceleratorW(h,accelerators,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
    DestroyAcceleratorTable(accelerators);DeleteObject(mono);DeleteObject(ui);DeleteObject(brand_font);DeleteObject(page_brush);DeleteObject(white_brush);DestroyMenu(main_menu);return (int)msg.wParam;
}
