#define UNICODE
#define _UNICODE
#include "legacy_win.h"
#include "legacy.h"
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

enum {PATH_CAP=32768};
static int failed(char error[256],const char *message){if(error){strncpy(error,message,255);error[255]=0;}return 0;}
static int template_path(const wchar_t *self_path,int version,wchar_t path[PATH_CAP],char error[256]) {
    if(!self_path||(version!=1&&version!=2))return failed(error,"Wybierz historyczna wersje 0.1 lub 0.2.");
    size_t n=wcslen(self_path);if(n>PATH_CAP-64)return failed(error,"Sciezka aplikacji jest za dluga.");
    wcscpy(path,self_path);wchar_t *slash=wcsrchr(path,L'\\'),*other=wcsrchr(path,L'/');if(other&&(!slash||other>slash))slash=other;
    if(!slash)return failed(error,"Nie mozna znalezc folderu aplikacji.");
    slash[1]=0;wcscat(path,version==1?L"compatibility\\Titanium-0.1.html":L"compatibility\\Titanium-0.2.html");return 1;
}
static int write_player(const wchar_t *self_path,const wchar_t *output_path,const char *source,size_t length,int version,char error[256]) {
    wchar_t path[PATH_CAP];if(error)error[0]=0;
    if(!template_path(self_path,version,path,error))return 0;
    FILE *f=_wfopen(path,L"rb");if(!f)return failed(error,"Brak compatibility/Titanium-0.1.html lub Titanium-0.2.html obok aplikacji.");
    if(fseek(f,0,SEEK_END)){fclose(f);return failed(error,"Nie mozna odczytac srodowiska historycznego.");}
    long bytes=ftell(f);if(bytes<=0||bytes>4*1024*1024||fseek(f,0,SEEK_SET)){fclose(f);return failed(error,"Nieprawidlowy plik srodowiska historycznego.");}
    char *html=malloc((size_t)bytes);if(!html){fclose(f);return failed(error,"Brak pamieci.");}
    if(fread(html,1,(size_t)bytes,f)!=(size_t)bytes){free(html);fclose(f);return failed(error,"Nie mozna odczytac srodowiska historycznego.");}fclose(f);
    f=_wfopen(output_path,L"wb");if(!f){free(html);return failed(error,"Nie mozna utworzyc pliku HTML.");}
    int ok=ti_legacy_write_html(f,html,(size_t)bytes,source,length,error);free(html);if(fclose(f)&&ok)ok=failed(error,"Nie mozna zapisac pliku HTML.");return ok;
}
int ti_legacy_export(const wchar_t *self_path,const wchar_t *output_path,const char *source,size_t length,int version,char error[256]) {
    if(!output_path||wcslen(output_path)>PATH_CAP-32)return failed(error,"Nieprawidlowa sciezka pliku HTML.");
    /* Stage next to the destination so a failure preserves an existing file. */
    wchar_t folder[PATH_CAP],temp[PATH_CAP];wcscpy(folder,output_path);
    wchar_t *slash=wcsrchr(folder,L'\\'),*other=wcsrchr(folder,L'/');if(other&&(!slash||other>slash))slash=other;
    if(slash)slash[1]=0;else wcscpy(folder,L".");
    if(!GetTempFileNameW(folder,L"tiH",0,temp))return failed(error,"Nie mozna utworzyc pliku tymczasowego HTML.");
    int ok=write_player(self_path,temp,source,length,version,error);
    if(ok&&!MoveFileExW(temp,output_path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))ok=failed(error,"Nie mozna zapisac docelowego pliku HTML.");
    if(!ok)DeleteFileW(temp);return ok;
}
int ti_legacy_run(HWND owner,const wchar_t *self_path,const char *source,size_t length,int version,char error[256]) {
    wchar_t folder[PATH_CAP],temp[PATH_CAP],html_path[PATH_CAP];
    DWORD n=GetTempPathW(PATH_CAP,folder);if(!n||n>=PATH_CAP||!GetTempFileNameW(folder,L"tiH",0,temp))return failed(error,"Nie mozna utworzyc pliku tymczasowego HTML.");
    if(wcslen(temp)>PATH_CAP-8){DeleteFileW(temp);return failed(error,"Sciezka tymczasowa jest za dluga.");}
    wcscpy(html_path,temp);wcscat(html_path,L".html");
    if(!MoveFileExW(temp,html_path,0)){DeleteFileW(temp);return failed(error,"Nie mozna utworzyc pliku HTML.");}
    if(!write_player(self_path,html_path,source,length,version,error)){DeleteFileW(html_path);return 0;}
    HINSTANCE result=ShellExecuteW(owner,L"open",html_path,NULL,NULL,SW_SHOWNORMAL);
    if((INT_PTR)result<=32){DeleteFileW(html_path);return failed(error,"Nie mozna otworzyc domyslnej przegladarki. Zapisz program jako HTML i otworz go recznie.");}
    /* The browser reads asynchronously. The OS temporary directory owns this
       session file; deleting it now would race browser startup/reload. */
    return 1;
}
