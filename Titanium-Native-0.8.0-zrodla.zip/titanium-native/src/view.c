#include "view.h"
#include "graphics.h"
#include "app_win.h"
#include <windowsx.h>
#include <wtypes.h>
#include <gdiplus.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>

/* This layout is private to the two copies of this executable. It contains no
   process-local pointers. The scene/input are protected by mutex; closed is an
   interlocked flag so stopping never waits for a crashed writer. */
#define TI_VIEW_MAGIC 0x54495638u
#define TI_VIEW_TIMER 0x5449u
#define TI_VIEW_LOCK_MS 4
#define TI_ROOT_LIMIT 32768

typedef struct {
    DWORD magic,size;
    volatile LONG closed;
    TiScene scene;
    TiInput input;
} TiShared;
typedef struct { char name[256]; GpImage *image; } TiCachedImage;
struct TiView {
    HWND hwnd;
    HANDLE mapping,mutex;
    TiShared *shared;
    TiScene snapshot;
    wchar_t *root;
    TiCachedImage images[TI_OBJECTS];
    unsigned image_count;
    uint64_t image_pixels;
    ULONG_PTR gdiplus;
    LARGE_INTEGER frequency,last_frame;
    int owner;
    HDC buffer;HBITMAP bitmap,old_bitmap;int buffer_w,buffer_h;
    GpFontFamily *font_family;TiAppView *application;
};

static LRESULT CALLBACK ti_view_proc(HWND,UINT,WPARAM,LPARAM);
static int ti_lock(TiView *v) {
    DWORD r=WaitForSingleObject(v->mutex,TI_VIEW_LOCK_MS);
    return r==WAIT_OBJECT_0 || r==WAIT_ABANDONED;
}
static int ti_closed(TiView *v) {
    return !v || !v->shared || InterlockedCompareExchange(&v->shared->closed,0,0)!=0;
}
static void ti_error(char error[256],const char *message) {
    if(error) { strncpy(error,message,255);error[255]=0; }
}
static void ti_cache_clear(TiView *v) {
    unsigned i;
    for(i=0;i<v->image_count;i++) if(v->images[i].image) GdipDisposeImage(v->images[i].image);
    memset(v->images,0,sizeof(v->images));v->image_count=0;v->image_pixels=0;
}
void ti_view_set_root(TiView *v,const wchar_t *root) {
    wchar_t *copy;size_t n;
    if(!v) return;
    if(!root) root=L"";
    n=wcslen(root);if(n>=TI_ROOT_LIMIT-258) return;
    copy=(wchar_t *)malloc((n+1)*sizeof(wchar_t));if(!copy) return;
    memcpy(copy,root,(n+1)*sizeof(wchar_t));
    ti_cache_clear(v);free(v->root);v->root=copy;
}
static int ti_asset_path(TiView *v,const char *name,wchar_t path[TI_ROOT_LIMIT]) {
    wchar_t filename[256];const char *ext;size_t n;int len;
    if(!v->root || !*v->root || !name || !ti_game_asset_name(name)) return 0;
    ext=strrchr(name,'.');
    if(!ext || (_stricmp(ext,".png") && _stricmp(ext,".jpg") &&
                _stricmp(ext,".jpeg") && _stricmp(ext,".bmp"))) return 0;
    len=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,name,-1,filename,256);
    if(!len) return 0;
    n=wcslen(v->root);if(n+(size_t)len+1>=TI_ROOT_LIMIT) return 0;
    memcpy(path,v->root,n*sizeof(wchar_t));
    if(n && path[n-1]!=L'\\' && path[n-1]!=L'/') path[n++]=L'\\';
    memcpy(path+n,filename,(size_t)len*sizeof(wchar_t));return 1;
}
static GpImage *ti_image(TiView *v,const char *name,char error[256]) {
    unsigned i;wchar_t path[TI_ROOT_LIMIT];GpImage *image=NULL;UINT w=0,h=0;DWORD attr;GUID format;
    /* These identifiers are from gdiplusimaging.h; local constants avoid an
       additional uuid import library solely for comparing raw image formats. */
    static const GUID formats[3]={
        {0xb96b3cab,0x0728,0x11d3,{0x9d,0x7b,0,0,0xf8,0x1e,0xf3,0x2e}},
        {0xb96b3cae,0x0728,0x11d3,{0x9d,0x7b,0,0,0xf8,0x1e,0xf3,0x2e}},
        {0xb96b3caf,0x0728,0x11d3,{0x9d,0x7b,0,0,0xf8,0x1e,0xf3,0x2e}}
    };
    if(!name) { ti_error(error,"Bledna nazwa pliku w assety.");return NULL; }
    for(i=0;i<v->image_count;i++) if(!strcmp(v->images[i].name,name)) return v->images[i].image;
    if(!ti_asset_path(v,name,path)) { ti_error(error,"Uzyj zwyklej nazwy PNG, JPG lub BMP z folderu assety.");return NULL; }
    attr=GetFileAttributesW(path);
    if(attr==INVALID_FILE_ATTRIBUTES || (attr&FILE_ATTRIBUTE_DIRECTORY)) {
        ti_error(error,"Brak obrazu w folderze assety albo plik jest niedostepny.");return NULL;
    }
    if(GdipLoadImageFromFile(path,&image)!=Ok || !image ||
       GdipGetImageWidth(image,&w)!=Ok || GdipGetImageHeight(image,&h)!=Ok || !w || !h ||
       w>4096 || h>4096 || v->image_pixels+(uint64_t)w*h>16*1024*1024 ||
       GdipGetImageRawFormat(image,&format)!=Ok ||
       (memcmp(&format,&formats[0],sizeof(format)) && memcmp(&format,&formats[1],sizeof(format)) && memcmp(&format,&formats[2],sizeof(format))) ||
       GdipImageForceValidation(image)!=Ok) {
        if(image) GdipDisposeImage(image);
        ti_error(error,"Nie mozna odczytac obrazu PNG/JPG/BMP albo przekroczono limit 4096x4096 / 64 MB obrazow.");return NULL;
    }
    if(v->image_count>=TI_OBJECTS) {
        GdipDisposeImage(image);ti_error(error,"Za duzo roznych obrazow (limit 128).");return NULL;
    }
    i=v->image_count++;strncpy(v->images[i].name,name,255);
    v->images[i].name[255]=0;v->images[i].image=image;v->image_pixels+=(uint64_t)w*h;return image;
}
static int ti_asset(void *context,const char *filename,char error[256]) {
    return ti_image((TiView *)context,filename,error)!=NULL;
}
static void ti_snapshot(TiView *v) {
    if(ti_lock(v)) { memcpy(&v->snapshot,&v->shared->scene,sizeof(v->snapshot));ReleaseMutex(v->mutex); }
}
/* Fit the logical scene into the client area; input uses this same transform. */
static double ti_transform(TiView *v,double *ox,double *oy,int *cw,int *ch) {
    RECT r;double sx,sy,s;unsigned w=v->snapshot.width,h=v->snapshot.height;
    GetClientRect(v->hwnd,&r);*cw=r.right-r.left;*ch=r.bottom-r.top;
    if(!w) w=640;if(!h) h=360;
    sx=(double)*cw/w;sy=(double)*ch/h;s=sx<sy?sx:sy;
    if(s<=0) s=1;
    *ox=(*cw-w*s)/2;*oy=(*ch-h*s)/2;return s;
}
static void ti_input_update(TiView *v) {
    TiInput input;POINT p;int i,cw,ch;double ox,oy,s;
    memset(&input,0,sizeof(input));
    if(GetFocus()==v->hwnd && GetForegroundWindow()==GetAncestor(v->hwnd,GA_ROOT) && !ti_closed(v)) {
        for(i=0;i<256;i++) input.keys[i]=(GetAsyncKeyState(i)&0x8000)!=0;
        input.buttons[0]=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0;
        input.buttons[1]=(GetAsyncKeyState(VK_RBUTTON)&0x8000)!=0;
    }
    s=ti_transform(v,&ox,&oy,&cw,&ch);
    if(GetCursorPos(&p) && ScreenToClient(v->hwnd,&p)) {
        input.mouse_x=(p.x-ox)/s;input.mouse_y=(p.y-oy)/s;
    }
    if(ti_lock(v)) { v->shared->input=input;ReleaseMutex(v->mutex); }
}
static ARGB ti_color(uint32_t rgb) { return (ARGB)(0xff000000u|(rgb&0xffffffu)); }
static ARGB ti_alpha(uint32_t rgb,double opacity){return ((ARGB)(opacity*255/100+.5)<<24)|(rgb&0xffffff);}
static int ti_buffer(TiView*v,HDC dc,int w,int h){
 if(v->buffer&&v->buffer_w==w&&v->buffer_h==h)return 1;
 if(v->buffer){SelectObject(v->buffer,v->old_bitmap);DeleteObject(v->bitmap);DeleteDC(v->buffer);v->buffer=NULL;}
 HDC mem=CreateCompatibleDC(dc);HBITMAP bmp=mem?CreateCompatibleBitmap(dc,w,h):NULL;
 if(!bmp){if(mem)DeleteDC(mem);return 0;}v->buffer=mem;v->bitmap=bmp;v->old_bitmap=SelectObject(mem,bmp);v->buffer_w=w;v->buffer_h=h;return 1;
}
/* Native radial gradient: one ellipse and one path-gradient brush per light.
   No bitmap is retained in the shared scene and no per-radius draw loop occurs. */
static void ti_draw_light(GpGraphics*g,REAL cx,REAL cy,REAL radius,uint32_t color,double opacity){
 GpPath*path=NULL;GpPathGradient*brush=NULL;if(radius<=0||opacity<=0)return;
 if(GdipCreatePath(FillModeAlternate,&path)!=Ok)return;
 GdipAddPathEllipse(path,cx-radius,cy-radius,radius*2,radius*2);
 if(GdipCreatePathGradientFromPath(path,&brush)==Ok){
  GpPointF centre={cx,cy};ARGB edge=color&0xffffff;INT count=1;
  GdipSetPathGradientCenterPoint(brush,&centre);GdipSetPathGradientCenterColor(brush,ti_alpha(color,opacity));
  GdipSetPathGradientSurroundColorsWithCount(brush,&edge,&count);
  GdipFillPath(g,(GpBrush*)brush,path);GdipDeleteBrush((GpBrush*)brush);
 }
 GdipDeletePath(path);
}
static void ti_draw_trails(TiView*v,GpGraphics*g,int pinned,int layer,unsigned char drawn[TI_TRAILS],double ox,double oy,double fit){
 TiScene*s=&v->snapshot;double z=pinned?1:(s->zoom>0?s->zoom:1);
 for(unsigned i=0;i<s->trail_count&&i<TI_TRAILS;i++){
  TiTrail*p=&s->trails[i];if(drawn[i]||p->pinned!=pinned||p->layer>layer)continue;drawn[i]=1;
  if(p->life<=0||p->total<=0)continue;double fade=fmin(1,p->life/p->total);
  REAL x=(REAL)(ox+((p->x-(pinned?0:s->camera_x*p->parallax))*z+(pinned?0:s->shake_x))*fit);
  REAL y=(REAL)(oy+((p->y-(pinned?0:s->camera_y*p->parallax))*z+(pinned?0:s->shake_y))*fit);
  REAL r=(REAL)(p->size*z*fit*(.25+.75*fade));GpSolidFill*b=NULL;
  if(GdipCreateSolidFill(ti_alpha(p->color,fade*55),&b)==Ok){GdipFillEllipse(g,(GpBrush*)b,x-r/2,y-r/2,r,r);GdipDeleteBrush((GpBrush*)b);}
 }
}
static void ti_draw_object(TiView*v,GpGraphics*g,TiObject*o,double ox,double oy,double fit){
 if(!o->visible||o->opacity<=0||!isfinite(o->x)||!isfinite(o->y))return;
 double px,py,scale;ti_graphics_position(&v->snapshot,o,&px,&py,&scale);
 double z=o->pinned?1:v->snapshot.zoom;
 REAL w=(REAL)(o->w*scale*fit),h=(REAL)(o->h*scale*fit);
 /* Scale around the original centre; x/y still describe the physical body. */
 REAL cx=(REAL)(ox+(px+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->w*z/2))*fit);
 REAL cy=(REAL)(oy+(py+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->h*z/2))*fit);
 double radius=fmax(hypot(w,h)/2+(o->outline+o->glow_radius)*fit*scale,o->light_radius*z*fit);
 if(o->kind!=TI_LABEL&&(cx+radius<ox||cy+radius<oy||cx-radius>ox+v->snapshot.width*fit||cy-radius>oy+v->snapshot.height*fit))return;
 if(o->light_radius>0&&o->light_strength>0)ti_draw_light(g,cx,cy,(REAL)(o->light_radius*z*fit),o->light_color,o->light_strength*o->opacity/100*.6);
 GraphicsState state;GpMatrix *matrix=NULL;GdipSaveGraphics(g,&state);
 if(GdipCreateMatrix(&matrix)==Ok){GdipTranslateMatrix(matrix,cx,cy,MatrixOrderAppend);GdipSetWorldTransform(g,matrix);GdipDeleteMatrix(matrix);}
 GdipRotateWorldTransform(g,(REAL)o->angle,MatrixOrderPrepend);
 if(o->mirror)GdipScaleWorldTransform(g,-1,1,MatrixOrderPrepend);
 if(o->glow_radius>0&&o->glow_intensity>0){
  /* Four bounded translucent halos preserve the original unlit default. */
  for(int ring=4;ring>=1;ring--){GpSolidFill*b=NULL;REAL spread=(REAL)(o->glow_radius*scale*fit*ring/4);
   if(GdipCreateSolidFill(ti_alpha(o->glow_color,o->glow_intensity*o->opacity/100*.065),&b)==Ok){
    if(o->kind==TI_CIRCLE||o->kind==TI_LABEL)GdipFillEllipse(g,(GpBrush*)b,-w/2-spread,-h/2-spread,w+spread*2,h+spread*2);
    else GdipFillRectangle(g,(GpBrush*)b,-w/2-spread,-h/2-spread,w+spread*2,h+spread*2);
    GdipDeleteBrush((GpBrush*)b);
   }
  }
 }
 if(o->kind==TI_IMAGE){
  o->asset[sizeof(o->asset)-1]=0;GpImage*img=ti_image(v,o->asset,NULL);
  if(img){UINT iw=0,ih=0;GdipGetImageWidth(img,&iw);GdipGetImageHeight(img,&ih);
   int frames=o->anim_frames>0&&o->anim_frames<=64?o->anim_frames:1;REAL fw=(REAL)iw/frames;
   GpImageAttributes*attr=NULL;GdipCreateImageAttributes(&attr);
   if(attr){ColorMatrix cm={{{1,0,0,0,0},{0,1,0,0,0},{0,0,1,0,0},{0,0,0,(REAL)(o->opacity/100),0},{0,0,0,0,1}}};GdipSetImageAttributesColorMatrix(attr,ColorAdjustTypeBitmap,TRUE,&cm,NULL,ColorMatrixFlagsDefault);}
   GdipDrawImageRectRect(g,img,-w/2,-h/2,w,h,fw*(o->anim_frame%frames),0,fw,(REAL)ih,UnitPixel,attr,NULL,NULL);
   if(attr)GdipDisposeImageAttributes(attr);
  }
 }else if(o->kind==TI_LABEL){
  wchar_t text[512];GpFont*font=NULL;GpSolidFill*brush=NULL;o->text[511]=0;
  if(v->font_family&&MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,o->text,-1,text,512)&&GdipCreateFont(v->font_family,h>1?h:1,FontStyleRegular,UnitPixel,&font)==Ok){
   RectF rect={0,0,10000,10000};if(GdipCreateSolidFill(ti_alpha(o->color,o->opacity),&brush)==Ok){GdipDrawString(g,text,-1,font,&rect,NULL,(GpBrush*)brush);GdipDeleteBrush((GpBrush*)brush);}GdipDeleteFont(font);
  }
 }else{
  GpSolidFill*brush=NULL;if(GdipCreateSolidFill(ti_alpha(o->color,o->opacity),&brush)==Ok){
   if(o->kind==TI_CIRCLE)GdipFillEllipse(g,(GpBrush*)brush,-w/2,-h/2,w,h);else GdipFillRectangle(g,(GpBrush*)brush,-w/2,-h/2,w,h);GdipDeleteBrush((GpBrush*)brush);
  }
  if(o->outline>0){GpPen*pen=NULL;if(GdipCreatePen1(ti_alpha(o->outline_color,o->opacity),(REAL)(o->outline*scale*fit),UnitPixel,&pen)==Ok){if(o->kind==TI_CIRCLE)GdipDrawEllipse(g,pen,-w/2,-h/2,w,h);else GdipDrawRectangle(g,pen,-w/2,-h/2,w,h);GdipDeletePen(pen);}}
 }
 GdipRestoreGraphics(g,state);
}
static void ti_paint(TiView *v,HDC dc){
 int cw,ch;double ox,oy,fit=ti_transform(v,&ox,&oy,&cw,&ch);if(cw<=0||ch<=0||!ti_buffer(v,dc,cw,ch))return;
 GpGraphics*g=NULL;if(GdipCreateFromHDC(v->buffer,&g)==Ok){
  GdipGraphicsClear(g,0xff131a24);REAL w=(REAL)(v->snapshot.width*fit),h=(REAL)(v->snapshot.height*fit);
  GdipSetClipRect(g,(REAL)ox,(REAL)oy,w,h,CombineModeReplace);
  GpBrush*background=NULL;
  if(v->snapshot.gradient){GpPointF a={(REAL)ox,(REAL)oy},b={(REAL)ox,(REAL)(oy+h)};GdipCreateLineBrush(&a,&b,ti_color(v->snapshot.background),ti_color(v->snapshot.background2),WrapModeTile,(GpLineGradient**)&background);}
  else GdipCreateSolidFill(ti_color(v->snapshot.background),(GpSolidFill**)&background);
  if(background){GdipFillRectangle(g,background,(REAL)ox,(REAL)oy,w,h);GdipDeleteBrush(background);}
  GdipSetSmoothingMode(g,SmoothingModeAntiAlias);GdipSetPixelOffsetMode(g,PixelOffsetModeHighQuality);GdipSetInterpolationMode(g,InterpolationModeHighQualityBicubic);
  unsigned order[TI_OBJECTS];ti_graphics_order(&v->snapshot,order);unsigned count=v->snapshot.count<TI_OBJECTS?v->snapshot.count:TI_OBJECTS;
  /* World effects sit above world objects; HUD remains on top of particles. */
  unsigned char trails_drawn[TI_TRAILS]={0};
  for(unsigned i=0;i<count;i++)if(!v->snapshot.objects[order[i]].pinned){
   ti_draw_trails(v,g,0,v->snapshot.objects[order[i]].layer,trails_drawn,ox,oy,fit);
   ti_draw_object(v,g,&v->snapshot.objects[order[i]],ox,oy,fit);
  }
  ti_draw_trails(v,g,0,1001,trails_drawn,ox,oy,fit);
  double z=v->snapshot.zoom>0?v->snapshot.zoom:1;
  for(unsigned i=0;i<v->snapshot.particle_count&&i<TI_PARTICLES;i++){
   TiParticle*p=&v->snapshot.particles[i];GpSolidFill*b=NULL;REAL x=(REAL)(ox+((p->x-v->snapshot.camera_x)*z+v->snapshot.shake_x)*fit),y=(REAL)(oy+((p->y-v->snapshot.camera_y)*z+v->snapshot.shake_y)*fit),r=(REAL)(p->size*z*fit);
   if(GdipCreateSolidFill(ti_alpha(p->color,p->life/p->total*100),&b)==Ok){GdipFillEllipse(g,(GpBrush*)b,x-r/2,y-r/2,r,r);GdipDeleteBrush((GpBrush*)b);}
  }
  for(unsigned i=0;i<count;i++)if(v->snapshot.objects[order[i]].pinned){
   ti_draw_trails(v,g,1,v->snapshot.objects[order[i]].layer,trails_drawn,ox,oy,fit);
   ti_draw_object(v,g,&v->snapshot.objects[order[i]],ox,oy,fit);
  }
  ti_draw_trails(v,g,1,1001,trails_drawn,ox,oy,fit);
  GdipDeleteGraphics(g);
 }
 BitBlt(dc,0,0,cw,ch,v->buffer,0,0,SRCCOPY);
}
static void ti_messages(void) {
    MSG msg;
    while(PeekMessageW(&msg,NULL,0,0,PM_REMOVE)) {
        if(msg.message==WM_QUIT) { PostQuitMessage((int)msg.wParam);break; }
        TranslateMessage(&msg);DispatchMessageW(&msg);
    }
}
static int ti_frame(void *context,const TiScene *scene,TiInput *input,double *dt,char error[256]) {
    TiView *v=(TiView *)context;LARGE_INTEGER now;double elapsed;DWORD delay;
    if(!v || !v->shared || !scene) { ti_error(error,"Natywny podglad 2D jest niedostepny.");return -1; }
    if(ti_closed(v)) return 0;
    ti_messages();QueryPerformanceCounter(&now);
    if(v->last_frame.QuadPart) {
        elapsed=(double)(now.QuadPart-v->last_frame.QuadPart)/v->frequency.QuadPart;
        if(elapsed<1.0/60.0) {
            /* Wake for input, then resume the remainder of the frame budget. */
            do {
                delay=(DWORD)ceil((1.0/60.0-elapsed)*1000.0);
                MsgWaitForMultipleObjects(0,NULL,FALSE,delay,QS_ALLINPUT);ti_messages();
                QueryPerformanceCounter(&now);
                elapsed=(double)(now.QuadPart-v->last_frame.QuadPart)/v->frequency.QuadPart;
            } while(elapsed<1.0/60.0 && !ti_closed(v));
        }
        elapsed=(double)(now.QuadPart-v->last_frame.QuadPart)/v->frequency.QuadPart;
    } else elapsed=1.0/60.0;
    v->last_frame=now;
    if(elapsed<0) elapsed=0;if(elapsed>0.1) elapsed=0.1;if(dt) *dt=elapsed;
    if(ti_closed(v)) return 0;
    DWORD lock=WaitForSingleObject(v->mutex,1000);
    if(lock!=WAIT_OBJECT_0&&lock!=WAIT_ABANDONED) { ti_error(error,"Podglad 2D nie odpowiada.");return -1; }
    memcpy(&v->shared->scene,scene,sizeof(*scene));
    if(input) memcpy(input,&v->shared->input,sizeof(*input));
    ReleaseMutex(v->mutex);
    if(v->hwnd) {
        memcpy(&v->snapshot,scene,sizeof(*scene));ti_input_update(v);
        if(input && ti_lock(v)) { *input=v->shared->input;ReleaseMutex(v->mutex); }
        if(scene->active) { if(!GetParent(v->hwnd)) ShowWindow(v->hwnd,SW_SHOW);InvalidateRect(v->hwnd,NULL,FALSE);UpdateWindow(v->hwnd); }
    }
    return !ti_closed(v);
}
static int ti_application(void*context,TiAppScene*scene,TiAppInput*input,char error[256]){
 TiView*v=context;if(!v)return -1;
 if(!v->application)v->application=ti_app_view_create();
 if(!v->application){ti_error(error,"Nie mozna utworzyc aplikacji.");return -1;}
 return ti_app_view_frame(v->application,scene,input,error);
}
TiHost ti_view_host(TiView *v) {TiHost host={0};host.context=v;host.frame=ti_frame;host.asset=ti_asset;host.app=ti_application;return host;}
static TiView *ti_view_alloc(const wchar_t *root) {
    TiView *v=(TiView *)calloc(1,sizeof(*v));GdiplusStartupInput startup;
    if(!v) return NULL;
    memset(&startup,0,sizeof(startup));startup.GdiplusVersion=1;startup.SuppressExternalCodecs=TRUE;
    if(GdiplusStartup(&v->gdiplus,&startup,NULL)!=Ok) { free(v);return NULL; }
    GdipCreateFontFamilyFromName(L"Segoe UI",NULL,&v->font_family);
    QueryPerformanceFrequency(&v->frequency);
    if(!v->frequency.QuadPart) { ti_view_destroy(v);return NULL; }
    ti_view_set_root(v,root);if(!v->root) { ti_view_destroy(v);return NULL; }
    return v;
}
TiView *ti_view_create(HWND parent,const wchar_t *root) {
    TiView *v=ti_view_alloc(root);SECURITY_ATTRIBUTES sa;WNDCLASSEXW wc;DWORD style;RECT rect;
    if(!v) return NULL;v->owner=1;
    memset(&sa,0,sizeof(sa));sa.nLength=sizeof(sa);sa.bInheritHandle=TRUE;
    v->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,&sa,PAGE_READWRITE,0,sizeof(TiShared),NULL);
    v->mutex=CreateMutexW(&sa,FALSE,NULL);
    if(!v->mapping || !v->mutex) { ti_view_destroy(v);return NULL; }
    v->shared=(TiShared *)MapViewOfFile(v->mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(TiShared));
    if(!v->shared) { ti_view_destroy(v);return NULL; }
    memset(v->shared,0,sizeof(*v->shared));v->shared->magic=TI_VIEW_MAGIC;v->shared->size=sizeof(TiShared);
    v->shared->scene.zoom=1;v->shared->scene.width=640;v->shared->scene.height=360;v->shared->scene.background=0x202020;
    v->snapshot=v->shared->scene;
    memset(&wc,0,sizeof(wc));wc.cbSize=sizeof(wc);wc.hInstance=GetModuleHandleW(NULL);
    wc.lpfnWndProc=ti_view_proc;wc.hCursor=LoadCursorW(NULL,MAKEINTRESOURCEW(32512));wc.lpszClassName=L"TitaniumNative2D05";
    if(!RegisterClassExW(&wc) && GetLastError()!=ERROR_CLASS_ALREADY_EXISTS) { ti_view_destroy(v);return NULL; }
    style=parent?(WS_CHILD|WS_CLIPSIBLINGS|WS_TABSTOP):(WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN);
    rect.left=0;rect.top=0;rect.right=640;rect.bottom=360;
    if(!parent) AdjustWindowRect(&rect,style,FALSE);
    v->hwnd=CreateWindowExW(0,wc.lpszClassName,L"Titanium 2D",style,CW_USEDEFAULT,CW_USEDEFAULT,
        rect.right-rect.left,rect.bottom-rect.top,parent,NULL,wc.hInstance,v);
    if(!v->hwnd) { ti_view_destroy(v);return NULL; }
    if(!SetTimer(v->hwnd,TI_VIEW_TIMER,16,NULL)) { ti_view_destroy(v);return NULL; }
    return v;
}
TiView *ti_view_connect(uintptr_t mapping,uintptr_t mutex,const wchar_t *root) {
    TiView *v=ti_view_alloc(root);if(!v) return NULL;
    v->mapping=(HANDLE)mapping;v->mutex=(HANDLE)mutex;
    if(!v->mapping || !v->mutex) { ti_view_destroy(v);return NULL; }
    v->shared=(TiShared *)MapViewOfFile(v->mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(TiShared));
    if(!v->shared || v->shared->magic!=TI_VIEW_MAGIC || v->shared->size!=sizeof(TiShared)) { ti_view_destroy(v);return NULL; }
    return v;
}
HWND ti_view_hwnd(TiView *v) { return v?v->hwnd:NULL; }
void ti_view_handles(TiView *v,uintptr_t *mapping,uintptr_t *mutex) {
    if(mapping) *mapping=v?(uintptr_t)v->mapping:0;if(mutex) *mutex=v?(uintptr_t)v->mutex:0;
}
int ti_view_active(TiView *v) { if(!v || !v->shared) return 0;ti_snapshot(v);return v->snapshot.active!=0; }
int ti_view_alive(TiView *v) { return !ti_closed(v); }
void ti_view_stop(TiView *v) {
    if(!v || !v->shared) return;
    InterlockedExchange(&v->shared->closed,1);
    if(v->hwnd) { ti_input_update(v);ShowWindow(v->hwnd,SW_HIDE); }
}
void ti_view_destroy(TiView *v) {
    if(!v) return;
    if(v->owner && v->shared) InterlockedExchange(&v->shared->closed,1);
    if(v->hwnd) { KillTimer(v->hwnd,TI_VIEW_TIMER);DestroyWindow(v->hwnd);v->hwnd=NULL; }
    ti_cache_clear(v);free(v->root);
    if(v->shared) UnmapViewOfFile(v->shared);
    if(v->mapping) CloseHandle(v->mapping);if(v->mutex) CloseHandle(v->mutex);
    if(v->application)ti_app_view_destroy(v->application);
    if(v->font_family)GdipDeleteFontFamily(v->font_family);
    if(v->buffer){SelectObject(v->buffer,v->old_bitmap);DeleteObject(v->bitmap);DeleteDC(v->buffer);}
    if(v->gdiplus) GdiplusShutdown(v->gdiplus);free(v);
}
static LRESULT CALLBACK ti_view_proc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
    TiView *v=(TiView *)GetWindowLongPtrW(hwnd,GWLP_USERDATA);
    if(msg==WM_NCCREATE) { CREATESTRUCTW *cs=(CREATESTRUCTW *)lp;v=(TiView *)cs->lpCreateParams;SetWindowLongPtrW(hwnd,GWLP_USERDATA,(LONG_PTR)v);v->hwnd=hwnd; }
    if(!v) return DefWindowProcW(hwnd,msg,wp,lp);
    switch(msg) {
        case WM_TIMER:
            if(wp==TI_VIEW_TIMER) {
                wchar_t title[128];ti_snapshot(v);ti_input_update(v);
                if(!GetParent(hwnd) && v->snapshot.active && !ti_closed(v)) {
                    v->snapshot.title[127]=0;
                    if(*v->snapshot.title && MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,v->snapshot.title,-1,title,128)) SetWindowTextW(hwnd,title);
                    if(!IsWindowVisible(hwnd)) ShowWindow(hwnd,SW_SHOW);
                }
                InvalidateRect(hwnd,NULL,FALSE);return 0;
            } break;
        case WM_LBUTTONDOWN:case WM_RBUTTONDOWN:SetFocus(hwnd);ti_input_update(v);return 0;
        case WM_LBUTTONUP:case WM_RBUTTONUP:case WM_MOUSEMOVE:case WM_KEYDOWN:case WM_KEYUP:
            ti_input_update(v);return 0;
        case WM_SYSKEYDOWN:case WM_SYSKEYUP:ti_input_update(v);break;
        case WM_SETFOCUS:case WM_KILLFOCUS:ti_input_update(v);return 0;
        case WM_GETDLGCODE:return DLGC_WANTARROWS|DLGC_WANTCHARS|DLGC_WANTALLKEYS;
        case WM_ERASEBKGND:return 1;
        case WM_SIZE:InvalidateRect(hwnd,NULL,FALSE);return 0;
        case WM_PAINT: { PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);ti_paint(v,dc);EndPaint(hwnd,&ps);return 0; }
        case WM_CLOSE:ti_view_stop(v);return 0;
        case WM_NCDESTROY:SetWindowLongPtrW(hwnd,GWLP_USERDATA,0);v->hwnd=NULL;break;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
