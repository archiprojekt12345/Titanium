#ifndef TI_EDITOR_WIN_H
#define TI_EDITOR_WIN_H
#include <windows.h>
HWND ti_editor_create(HWND parent,int id,HFONT font);
/* Caller owns the returned full plain-text buffer and must free it. */
wchar_t *ti_editor_get_text(void);
/* Loads Unicode text and resets selection, modified state and native undo. */
void ti_editor_set_text(const wchar_t *text);
void ti_editor_changed(void);
void ti_editor_tick(void);
void ti_editor_gutter(HDC dc,RECT rect);
void ti_editor_autocorrect(int enabled);
int ti_editor_autocorrect_enabled(void);
void ti_editor_complete(void);
void ti_editor_insert(const char *command);
void ti_editor_zoom(int delta);
int ti_editor_find(const wchar_t *query);
void ti_editor_syntax(int enabled);
void ti_editor_destroy(void);
#endif
