#ifndef TI_GRAPHICS_H
#define TI_GRAPHICS_H
#include "game.h"
void ti_graphics_order(const TiScene *,unsigned order[TI_OBJECTS]);
void ti_graphics_position(const TiScene *,const TiObject *,double *x,double *y,double *scale);
void ti_graphics_update(TiGame *);
void ti_graphics_particles(TiScene *,double x,double y,unsigned count,uint32_t color);
#endif
