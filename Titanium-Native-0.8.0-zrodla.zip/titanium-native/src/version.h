#ifndef TI_VERSION_H
#define TI_VERSION_H
#define TI_VERSION "0.8.0"
#define TI_VERSION_W L"0.8.0"
#define TI_EXE_NAME "Titanium-Native-0.8.0.exe"
#define TI_EXE_NAME_W L"Titanium-Native-0.8.0.exe"
#endif
