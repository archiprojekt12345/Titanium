#include "internal.h"
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <ctype.h>
#include "commands.h"
#include "assist.h"

void ti_fail(TiProgram *p,const char *format,...) {
    p->error.line=p->line;
    va_list args; va_start(args,format);
    vsnprintf(p->error.text,sizeof p->error.text,format,args); va_end(args);
    longjmp(p->jump,1);
}
void *ti_alloc(TiProgram *p,size_t size) {
    if(size>32*1024*1024 || p->bytes+size>32*1024*1024) ti_fail(p,"Przekroczono limit pamieci (32 MB).");
    Mem *m=calloc(1,sizeof *m+size); if(!m) ti_fail(p,"Brak pamieci.");
    m->size=size;m->permanent=!p->runtime; m->next=p->mem; p->mem=m; p->bytes+=size; return m+1;
}
char *ti_string(TiProgram *p,const char *s,size_t n) {
    char *r=ti_alloc(p,n+1); memcpy(r,s,n); return r;
}
Value ti_number(double n){Value v={0,n,NULL};return v;}
Value ti_bool(int n){Value v={2,!!n,NULL};return v;}
Value ti_text(const char *s){Value v={1,0,s};return v;}
void ti_free(TiProgram *p) {
    if(!p)return;
    Mem *m=p->mem;while(m){Mem *next=m->next;free(m);m=next;}free(p);
}
static unsigned utf8(TiProgram *p,const char **s) {
    const unsigned char *q=(const unsigned char*)*s; unsigned c=*q++,n,min;
    if(c<128){*s=(const char*)q;return c;}
    if(c>=0xc2&&c<=0xdf){n=1;min=128;c&=31;}
    else if(c>=0xe0&&c<=0xef){n=2;min=2048;c&=15;}
    else if(c>=0xf0&&c<=0xf4){n=3;min=65536;c&=7;}
    else {ti_fail(p,"Nieprawidlowe kodowanie. Zapisz plik jako UTF-8.");return 0;}
    while(n--){if((*q&0xc0)!=0x80)ti_fail(p,"Nieprawidlowy tekst UTF-8.");c=(c<<6)|(*q++&63);}
    if(c<min||c>0x10ffff||(c>=0xd800&&c<=0xdfff))ti_fail(p,"Nieprawidlowy tekst UTF-8.");
    *s=(const char*)q;return c;
}
static unsigned fold(unsigned c) {
    switch(c){
    case 0x104:case 0x105:return 'a';case 0x106:case 0x107:return 'c';
    case 0x118:case 0x119:return 'e';case 0x141:case 0x142:return 'l';
    case 0x143:case 0x144:return 'n';case 0xd3:case 0xf3:return 'o';
    case 0x15a:case 0x15b:return 's';case 0x179:case 0x17a:case 0x17b:case 0x17c:return 'z';
    default:return c<128?(unsigned)tolower((int)c):c;}
}
static int intern(TiProgram *p,const char *s) {
    for(int i=0;i<p->nn;i++)if(!strcmp(p->names[i],s))return i;
    if(p->nn==TI_NAMES)ti_fail(p,"Zbyt wiele nazw (limit 1024).");
    p->names[p->nn]=ti_string(p,s,strlen(s));return p->nn++;
}
static void lex(TiProgram *p,const char *src) {
    const char *s=src; int line=1;
    if(!strncmp(s,"\xef\xbb\xbf",3))s+=3;
    while(*s){
        p->line=line;
        if(*s==' '||*s=='\t'||*s=='\r'){s++;continue;}
        if(*s=='#'||(*s=='/'&&s[1]=='/')){while(*s&&*s!='\n')s++;continue;}
        if(p->nt>=TI_TOKENS-1)ti_fail(p,"Za dlugi program (limit tokenow).");
        Token t={0};t.line=line;t.begin=(int)(s-src);
        if(*s=='\n'||*s==';'){t.kind=T_NL;if(*s=='\n')line++;s++;}
        else if(s[0]=='2'&&(s[1]=='D'||s[1]=='d')&&!isalnum((unsigned char)s[2])&&s[2]!='_'){
            t.kind=T_ID;t.id=intern(p,"2d");s+=2;
        }else if(s[0]=='0'&&(s[1]=='x'||s[1]=='X')){
            /* Preserve strtod hexadecimal forms accepted by original native versions. */
            char*end;double value=strtod(s,&end);if(end<=s+2||!isfinite(value))ti_fail(p,"Nieprawidlowa liczba szesnastkowa.");
            t.kind=T_NUM;t.value=ti_number(value);s=end;
        }else if(s[0]=='0'&&(s[1]=='b'||s[1]=='B')){
            unsigned base=(s[1]=='x'||s[1]=='X')?16:2;s+=2;uint64_t value=0;int digits=0;
            while(isalnum((unsigned char)*s)||*s=='_'){
                unsigned c=(unsigned char)*s,d=(c>='0'&&c<='9')?c-'0':(c>='a'&&c<='f')?c-'a'+10:(c>='A'&&c<='F')?c-'A'+10:99;
                if(d>=base)ti_fail(p,"Niepoprawna cyfra liczby 0x/0b.");
                value=value*base+d;if(value>UINT32_MAX)ti_fail(p,"Liczba 0x/0b przekracza 32 bity.");s++;digits++;
            }
            if(!digits)ti_fail(p,"Po 0x/0b podaj cyfry.");t.kind=T_NUM;t.value=ti_number((double)value);
        }else if(isdigit((unsigned char)*s)||(*s=='.'&&isdigit((unsigned char)s[1]))){
            char *end;double n=strtod(s,&end);if(!isfinite(n))ti_fail(p,"Nieprawidlowa liczba.");
            t.kind=T_NUM;t.value=ti_number(n);s=end;
        }else if(*s=='"'){
            s++;const char *start=s;size_t max=0;
            while(start[max]&&start[max]!='\n')max++;
            char *text=ti_alloc(p,max+1);size_t n=0;
            while(*s&&*s!='"'){
                if(*s=='\n'||*s=='\r')ti_fail(p,"Zamknij tekst cudzyslowem w tym samym wierszu.");
                if(*s=='\\'){
                    s++;char c=*s++;if(c=='n')c='\n';else if(c=='t')c='\t';else if(c=='r')c='\r';
                    else if(c!='"'&&c!='\\')ti_fail(p,"Nieznany znak po ukosniku w tekscie.");text[n++]=c;
                }else{
                    const char *begin=s;utf8(p,&s);size_t k=(size_t)(s-begin);memcpy(text+n,begin,k);n+=k;
                }
            }if(*s!='"')ti_fail(p,"Brakuje koncowego cudzyslowu.");s++;t.kind=T_STR;t.value=ti_text(text);
        }else if(isalpha((unsigned char)*s)||*s=='_'||(unsigned char)*s>=128){
            char name[128];size_t n=0;
            while(isalnum((unsigned char)*s)||*s=='_'||(unsigned char)*s>=128){
                unsigned c=fold(utf8(p,&s));if(c>=128)ti_fail(p,"W nazwach uzywaj liter polskich, cyfr i podkreslenia.");
                if(n>=sizeof name-1)ti_fail(p,"Nazwa jest za dluga.");name[n++]=(char)c;
            }name[n]=0;t.kind=T_ID;t.id=intern(p,name);
        }else{
            char c=*s++;t.kind=(unsigned char)c;
            if(c=='='&&*s=='='){s++;t.kind=T_EQ;}
            else if(c=='!'&&*s=='='){s++;t.kind=T_NE;}
            else if(c=='<'&&*s=='='){s++;t.kind=T_LE;}
            else if(c=='>'&&*s=='='){s++;t.kind=T_GE;}
            else if(!strchr("+-*/%()=,<>",c))ti_fail(p,"Nieznany znak w programie.");
        }t.finish=(int)(s-src);p->tokens[p->nt++]=t;
    }p->tokens[p->nt++]=(Token){.kind=T_EOF,.line=line};
}
static Token *cur(TiProgram *p){p->line=p->tokens[p->pos].line;return &p->tokens[p->pos];}
static int key(TiProgram *p,const char *s){Token *t=cur(p);return t->kind==T_ID&&!strcmp(p->names[t->id],s);}
static int take(TiProgram *p,int k){if(cur(p)->kind!=k)return 0;p->pos++;return 1;}
static void need(TiProgram *p,int k,const char *msg){if(!take(p,k))ti_fail(p,"%s",msg);}
static int emit(TiProgram *p,int op,int a,int b) {
    if(p->nc==TI_CODE)ti_fail(p,"Za dlugi program (limit instrukcji).");
    int i=p->nc++;p->code[i]=(Ins){.op=op,.a=a,.b=b,.line=p->line};return i;
}
static void constant(TiProgram *p,Value v){int i=emit(p,O_CONST,0,0);p->code[i].value=v;}
static void newline(TiProgram *p){if(cur(p)->kind!=T_EOF)need(p,T_NL,"Kazde polecenie zapisz w osobnym wierszu.");while(take(p,T_NL)){} }
static Function *user_function(TiProgram*p,int id){for(int i=0;i<p->nf;i++)if(p->funcs[i].name==id)return &p->funcs[i];return NULL;}
static const TiCommand *command_for(TiProgram*p,int id){return user_function(p,id)?NULL:ti_command(p->names[id]);}
static void expr(TiProgram *p,int min);
static void argument(TiProgram *p,const TiCommand *c,int index,int min) {
    if(c&&(c->names&(1u<<index))&&cur(p)->kind==T_ID){
        constant(p,ti_text(p->names[cur(p)->id]));p->pos++;
    }else expr(p,min);
}
static int arguments(TiProgram *p,int parens,const TiCommand *c) {
    int n=0;if(parens&&take(p,')'))return 0;
    if(!parens&&(cur(p)->kind==T_NL||cur(p)->kind==T_EOF))return 0;
    int old=p->arg_mode;p->arg_mode=!parens;
    for(;;){
        if(n>=TI_PARAMS)ti_fail(p,"Za duzo argumentow (limit 16).");argument(p,c,n,1);n++;
        if(take(p,','))continue;
        int k=cur(p)->kind;if(k==T_NL||k==T_EOF||(parens&&k==')'))break;
        if(k==T_NUM||k==T_STR||k==T_ID||k=='('||k=='-'||k=='+')continue;
        break;
    }
    p->arg_mode=old;
    if(parens)need(p,')',"Brakuje zamykajacego nawiasu ).");return n;
}
static int precedence(TiProgram *p) {
    int k=cur(p)->kind;if(key(p,"lub"))return 1;
    if(key(p,"i"))return p->arg_mode&&(p->globals[cur(p)->id]||(p->in_function&&p->locals[cur(p)->id]))?0:2;
    if(k=='='||k==T_EQ||k==T_NE||key(p,"rowne")||key(p,"rozne"))return 3;
    if(k=='<'||k=='>'||k==T_LE||k==T_GE||key(p,"wieksze")||key(p,"mniejsze")||key(p,"conajmniej")||key(p,"najwyzej"))return 4;
    if(k=='+'||k=='-')return 5;if(k=='*'||k=='/'||k=='%')return 6;return 0;
}
static void expr(TiProgram *p,int min) {
    if(++p->depth>128)ti_fail(p,"Za duze zagniezdzenie wyrazen (limit 128).");
    Token t=*cur(p);p->pos++;
    if(t.kind==T_NUM||t.kind==T_STR)constant(p,t.value);
    else if(t.kind=='('){int old=p->arg_mode;p->arg_mode=0;expr(p,1);need(p,')',"Brakuje zamykajacego nawiasu ).");p->arg_mode=old;}
    else if(t.kind=='-'||t.kind=='+'||(t.kind==T_ID&&!strcmp(p->names[t.id],"nie"))){
        expr(p,t.kind==T_ID?3:7);if(t.kind!='+')emit(p,t.kind=='-'?O_NEG:O_NOT,0,0);
    }else if(t.kind==T_ID){
        const char *name=p->names[t.id];
        if(!strcmp(name,"prawda")||!strcmp(name,"falsz"))constant(p,ti_bool(!strcmp(name,"prawda")));
        else if(take(p,'(')){int n=arguments(p,1,command_for(p,t.id));emit(p,O_CALL,t.id,n);}
        else {
            const TiCommand *c=command_for(p,t.id);int count=c?c->prefix:-1;
            for(int i=0;i<p->nf;i++)if(p->funcs[i].name==t.id)count=p->funcs[i].argc;
            int k=cur(p)->kind;
            if(count>0&&(k==T_NL||k==T_EOF||k==')'||k==','||k=='*'||k=='/'||k=='%'))count=-1;
            if(c&&c->min==0&&(k==T_NL||k==T_EOF||k==')'||k==','))count=0;
            if(count>0&&c&&(c->names&1)&&k!=T_ID&&k!=T_STR&&k!='(')count=-1;
            if(p->globals[t.id]||(p->in_function&&p->locals[t.id]))count=-1;
            if(count>=0){for(int i=0;i<count;i++){take(p,',');argument(p,c,i,7);}emit(p,O_CALL,t.id,count);}
            else emit(p,O_LOAD,t.id,0);
        }
    }else ti_fail(p,"Oczekuje liczby, tekstu, nazwy lub nawiasu.");
    int prec;
    while((prec=precedence(p))>=min){
        int k=cur(p)->kind,logic=prec<=2;
        if(p->arg_mode&&(k=='-'||k=='+')&&p->pos>0&&cur(p)->begin>p->tokens[p->pos-1].finish&&p->tokens[p->pos+1].begin==cur(p)->finish)break;
        if(key(p,"rowne"))k=T_EQ;else if(key(p,"rozne"))k=T_NE;
        else if(key(p,"wieksze"))k='>';else if(key(p,"mniejsze"))k='<';
        else if(key(p,"conajmniej"))k=T_GE;else if(key(p,"najwyzej"))k=T_LE;
        p->pos++;
        if(logic){emit(p,O_DUP,0,0);int j=emit(p,prec==2?O_JZ:O_JNZ,0,0);emit(p,O_POP,0,0);expr(p,prec+1);p->code[j].a=p->nc;}
        else {
            expr(p,prec+1);int op=k=='+'?O_ADD:k=='-'?O_SUB:k=='*'?O_MUL:k=='/'?O_DIV:k=='%'?O_MOD:
                (k=='='||k==T_EQ)?O_EQ:k==T_NE?O_NE:k=='<'?O_LT:k=='>'?O_GT:k==T_LE?O_LE:O_GE;
            emit(p,op,0,0);
        }
    }p->depth--;
}
static void block(TiProgram *p);
static int temp_name(TiProgram *p){char s[32];snprintf(s,sizeof s,"$%d",p->temp++);return intern(p,s);}
static void end(TiProgram *p){if(!key(p,"koniec"))ti_fail(p,"Brakuje slowa koniec zamykajacego blok.");p->pos++;newline(p);}
static void declare(TiProgram *p,int name){if(p->in_function)p->locals[name]=1;else p->globals[name]=1;}
static int grouped_command(TiProgram *p){
    if(p->tokens[p->pos+1].kind!='(')return 1;
    int depth=0;
    for(int i=p->pos+1;i<p->nt;i++){
        int k=p->tokens[i].kind;if(k=='(')depth++;else if(k==')'&&!--depth){
            int next=p->tokens[i+1].kind;return next==T_NUM||next==T_STR||next==T_ID||next=='(';
        }if(k==T_NL||k==T_EOF)break;
    }return 0;
}
static void statement(TiProgram *p) {
    int line=cur(p)->line;
    if(key(p,"ustaw")||key(p,"dodaj")||key(p,"odejmij")){
        int op=key(p,"dodaj")?O_ADD:key(p,"odejmij")?O_SUB:0;p->pos++;
        Token name=*cur(p);need(p,T_ID,"Podaj nazwe zmiennej.");if(op)emit(p,O_LOAD,name.id,0);
        expr(p,1);if(op)emit(p,op,0,0);emit(p,O_STORE,name.id,0);declare(p,name.id);newline(p);
    }else if(key(p,"zawsze")){
        if(p->in_function||p->block>1)ti_fail(p,"zawsze umiesc w glownym programie, poza innymi blokami.");
        p->pos++;newline(p);int start=p->nc;emit(p,O_FRAME,0,0);int j=emit(p,O_JZ,0,0);
        block(p);end(p);emit(p,O_JMP,start,0);p->code[j].a=p->nc;
    }else if(key(p,"jesli")){
        p->pos++;expr(p,1);int j=emit(p,O_JZ,0,0);newline(p);block(p);
        if(key(p,"inaczej")){p->pos++;int after=emit(p,O_JMP,0,0);p->code[j].a=p->nc;newline(p);block(p);end(p);p->code[after].a=p->nc;}
        else {end(p);p->code[j].a=p->nc;}
    }else if(key(p,"dopoki")){
        p->pos++;int start=p->nc;expr(p,1);int j=emit(p,O_JZ,0,0);newline(p);block(p);end(p);emit(p,O_JMP,start,0);p->code[j].a=p->nc;
    }else if(key(p,"powtorz")){
        p->pos++;int count=temp_name(p);expr(p,1);emit(p,O_COUNT,0,0);emit(p,O_STORE,count,0);newline(p);
        int start=p->nc;emit(p,O_LOAD,count,0);constant(p,ti_number(0));emit(p,O_GT,0,0);int j=emit(p,O_JZ,0,0);
        block(p);end(p);emit(p,O_LOAD,count,0);constant(p,ti_number(1));emit(p,O_SUB,0,0);emit(p,O_STORE,count,0);emit(p,O_JMP,start,0);p->code[j].a=p->nc;
    }else if(key(p,"dla")){
        p->pos++;Token name=*cur(p);need(p,T_ID,"Po dla podaj nazwe licznika.");
        declare(p,name.id);
        if(!key(p,"od"))ti_fail(p,"Uzyj: dla i od 1 do 10.");p->pos++;expr(p,1);emit(p,O_STORE,name.id,0);
        if(!key(p,"do"))ti_fail(p,"W petli dla brakuje slowa do.");p->pos++;int limit=temp_name(p);expr(p,1);emit(p,O_STORE,limit,0);newline(p);
        int start=p->nc;emit(p,O_LOAD,name.id,0);emit(p,O_LOAD,limit,0);emit(p,O_LE,0,0);int j=emit(p,O_JZ,0,0);
        block(p);end(p);emit(p,O_LOAD,name.id,0);constant(p,ti_number(1));emit(p,O_ADD,0,0);emit(p,O_STORE,name.id,0);emit(p,O_JMP,start,0);p->code[j].a=p->nc;
    }else if(key(p,"funkcja")){
        if(p->in_function||p->block>1)ti_fail(p,"Funkcje zdefiniuj poza innymi blokami.");
        p->pos++;Token t=*cur(p);need(p,T_ID,"Podaj nazwe funkcji.");
        /* Explicit user functions retain their names when later versions add builtins. */
        Function *f=NULL;for(int i=0;i<p->nf;i++)if(p->funcs[i].name==t.id)f=&p->funcs[i];
        if(!f||f->entry>=0)ti_fail(p,"Ta funkcja juz istnieje.");
        int skip=emit(p,O_JMP,0,0);f->entry=p->nc;int argc=0,parens=take(p,'(');
        if(!(parens&&take(p,')'))){while(cur(p)->kind==T_ID){
            Token a=*cur(p);p->pos++;if(argc>=f->argc||f->params[argc]!=a.id)ti_fail(p,"Bledne parametry funkcji.");argc++;take(p,',');
        }if(parens)need(p,')',"Brakuje nawiasu ).");}
        if(argc!=f->argc)ti_fail(p,"Bledne parametry funkcji.");
        newline(p);p->in_function=1;memset(p->locals,0,sizeof p->locals);for(int i=0;i<f->argc;i++)p->locals[f->params[i]]=1;
        block(p);end(p);constant(p,ti_number(0));emit(p,O_RET,0,0);p->in_function=0;p->code[skip].a=p->nc;
    }else if(key(p,"zwroc")){
        if(!p->in_function)ti_fail(p,"zwroc dziala tylko w funkcji.");p->pos++;
        if(cur(p)->kind==T_NL||cur(p)->kind==T_EOF)constant(p,ti_number(0));else expr(p,1);
        emit(p,O_RET,0,0);newline(p);
    }else if(cur(p)->kind==T_ID&&p->tokens[p->pos+1].kind=='='){
        int name=cur(p)->id;p->pos+=2;expr(p,1);emit(p,O_STORE,name,0);declare(p,name);newline(p);
    }else if(cur(p)->kind==T_ID&&grouped_command(p)){
        int name=cur(p)->id;p->pos++;int n=arguments(p,0,command_for(p,name));emit(p,O_CALL,name,n);emit(p,O_POP,0,0);newline(p);
    }else {expr(p,1);emit(p,O_POP,0,0);newline(p);}
    (void)line;
}
static void block(TiProgram *p) {
    if(++p->block>128)ti_fail(p,"Za duze zagniezdzenie blokow (limit 128).");
    while(take(p,T_NL)){}
    while(cur(p)->kind!=T_EOF&&!key(p,"koniec")&&!key(p,"inaczej"))statement(p);
    p->block--;
}
TiProgram *ti_compile(const char *src,size_t length,TiError *error) {
    TiProgram *volatile p=calloc(1,sizeof *p);if(!p){if(error)*error=(TiError){.line=1,.text="Brak pamieci."};return NULL;}
    p->line=1;
    if(setjmp(p->jump)){if(error)*error=p->error;ti_free(p);return NULL;}
    if(length>250000)ti_fail(p,"Przekroczono limit kodu (250000 bajtow).");
    if(memchr(src,0,length))ti_fail(p,"Plik zawiera znak NUL. Uzyj kodowania UTF-8.");
    char *source=ti_string(p,src,length);const char *q=source;
    while(*q)utf8(p,&q);lex(p,source);
    /* Collect global declarations without mistaking locals for global names. */
    int function_depth=0;
    for(int i=0;i<p->nt-1;i++)if((i==0||p->tokens[i-1].kind==T_NL)&&p->tokens[i].kind==T_ID){
        const char *word=p->names[p->tokens[i].id];
        if(!strcmp(word,"funkcja")){function_depth=1;continue;}
        if(function_depth){
            if(!strcmp(word,"koniec"))function_depth--;
            else if(!strcmp(word,"jesli")||!strcmp(word,"dopoki")||!strcmp(word,"powtorz")||!strcmp(word,"dla")||!strcmp(word,"zawsze"))function_depth++;
            continue;
        }
        if(p->tokens[i+1].kind=='=')p->globals[p->tokens[i].id]=1;
        if((!strcmp(word,"ustaw")||!strcmp(word,"dodaj")||!strcmp(word,"odejmij")||!strcmp(word,"dla"))&&p->tokens[i+1].kind==T_ID)p->globals[p->tokens[i+1].id]=1;
    }
    /* Forward declarations give bare function calls an unambiguous arity. */
    for(int i=0;i<p->nt-1;i++)if((i==0||p->tokens[i-1].kind==T_NL)&&p->tokens[i].kind==T_ID&&!strcmp(p->names[p->tokens[i].id],"funkcja")){
        p->line=p->tokens[i].line;int at=i+1;if(p->tokens[at].kind!=T_ID)ti_fail(p,"Podaj nazwe funkcji.");
        int name=p->tokens[at++].id;for(int j=0;j<p->nf;j++)if(p->funcs[j].name==name)ti_fail(p,"Ta funkcja juz istnieje.");
        if(p->nf==TI_FUNS)ti_fail(p,"Za duzo funkcji.");Function *f=&p->funcs[p->nf++];f->name=name;f->entry=-1;
        if(p->tokens[at].kind=='(')at++;
        while(at<p->nt&&p->tokens[at].kind!=T_NL&&p->tokens[at].kind!=T_EOF&&p->tokens[at].kind!=')'){
            if(p->tokens[at].kind==','){at++;continue;}
            if(p->tokens[at].kind!=T_ID||f->argc==TI_PARAMS)ti_fail(p,"Bledna lista parametrow funkcji.");
            int id=p->tokens[at++].id;for(int j=0;j<f->argc;j++)if(f->params[j]==id)ti_fail(p,"Parametry musza miec rozne nazwy.");f->params[f->argc++]=id;
        }
    }
    p->pos=0;block(p);
    if(cur(p)->kind!=T_EOF)ti_fail(p,"Nieoczekiwane koniec lub inaczej.");emit(p,O_HALT,0,0);
    for(int i=0;i<p->nc;i++)if(p->code[i].op==O_CALL){
        Ins in=p->code[i];const TiCommand *c=command_for(p,in.a);int found=c!=NULL;
        if(c&&(in.b<c->min||in.b>c->max)){p->line=in.line;ti_fail(p,"Nieprawidlowa liczba argumentow polecenia %s (od %d do %d).",c->name,c->min,c->max);}
        for(int j=0;j<p->nf;j++)if(p->funcs[j].name==in.a){found=1;if(p->funcs[j].argc!=in.b){p->line=in.line;ti_fail(p,"Nieprawidlowa liczba argumentow funkcji %s.",p->names[in.a]);}}
        if(!found){p->line=in.line;const char*suggestion=ti_assist_suggest(p->names[in.a]);if(suggestion)ti_fail(p,"Nieznane polecenie: %s. Czy chodzi o %s?",p->names[in.a],suggestion);ti_fail(p,"Nieznane polecenie: %s.",p->names[in.a]);}
    }return p;
}

int ti_program_is_app(const TiProgram*p){if(!p)return 0;for(int i=0;i<p->nc;i++)if(p->code[i].op==O_CALL){const TiCommand*c=command_for((TiProgram*)p,p->code[i].a);if(c&&c->game==2)return 1;}return 0;}
