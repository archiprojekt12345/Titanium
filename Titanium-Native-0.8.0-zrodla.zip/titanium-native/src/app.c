#include "app.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

static int fail(char error[256],const char *message){if(error)snprintf(error,256,"%s",message);return -1;}
static void boolean(TiValue *r,int value){if(r){r->kind=2;r->n=value!=0;r->s=NULL;}}
/* Strict UTF-8 also rejects surrogate code points and overlong encodings. */
static int utf8(const char *s){
 const unsigned char *p=(const unsigned char *)s;
 while(*p){unsigned c=*p++;if(c<128)continue;unsigned n,min;
  if(c>=0xc2&&c<=0xdf){n=1;min=0x80;c&=31;}
  else if(c>=0xe0&&c<=0xef){n=2;min=0x800;c&=15;}
  else if(c>=0xf0&&c<=0xf4){n=3;min=0x10000;c&=7;}else return 0;
  while(n--){if((*p&0xc0)!=0x80)return 0;c=(c<<6)|(*p++&63);}
  if(c<min||c>0x10ffff||(c>=0xd800&&c<=0xdfff))return 0;
 }return 1;
}
static int text(const TiValue *v,size_t cap,int empty){return v&&v->kind==1&&v->s&&(empty||v->s[0])&&strlen(v->s)<cap&&utf8(v->s);}
static int namearg(const TiValue *v){if(!text(v,64,0))return 0;for(const unsigned char *p=(const unsigned char *)v->s;*p;p++)if(*p<32||*p==127)return 0;return 1;}
static int integer(const TiValue *v,int lo,int hi){return v&&v->kind!=1&&isfinite(v->n)&&v->n>=lo&&v->n<=hi&&floor(v->n)==v->n;}
static TiControl *find(TiApp *app,const char *name){for(unsigned i=0;i<app->scene.count;i++)if(!strcmp(app->scene.controls[i].name,name))return &app->scene.controls[i];return NULL;}
void ti_app_init(TiApp *app,const TiHost *host){memset(app,0,sizeof *app);if(host)app->host=*host;}
int ti_app_call(TiApp *app,const char *name,int argc,const TiValue *args,TiValue *result,char error[256]){
 static const struct {const char *name;int argc;} commands[]={
  {"aplikacja",3},{"przycisk",6},{"pole",6},{"notatnik",6},{"etykieta",6},{"wybor",6},
  {"ustaw_tekst",2},{"wartosc",1},{"kliknieto",1},{"zaznaczone",1},{"ustaw_wybor",2},{"wlacz",2},{"widoczny",2},{"zamknij_aplikacje",0},{"klatka",0}};
 int cmd=-1;if(error)error[0]=0;if(result){result->kind=0;result->n=0;result->s=NULL;}
 if(!name)return 0;for(unsigned i=0;i<sizeof commands/sizeof commands[0];i++)if(!strcmp(name,commands[i].name)){cmd=(int)i;break;}
 if(cmd<0)return 0;if(!app)return fail(error,"Brak stanu aplikacji");
 if(cmd==14&&!app->started)return 0;
 if(argc!=commands[cmd].argc||(argc&&!args))return fail(error,"Nieprawidlowa liczba argumentow aplikacji");
 if(cmd==0){
  if(!text(args,256,1)||!integer(args+1,240,3840)||!integer(args+2,160,2160))return fail(error,"Aplikacja wymaga tytulu UTF-8 do 255 bajtow i wymiarow 240..3840 x 160..2160");
  if(!app->host.app)return fail(error,"Aplikacje sa niedostepne w tym trybie; uruchom program w natywnym oknie");
  if(app->scene.active){for(unsigned i=0;i<app->scene.count;i++){const TiControl *c=&app->scene.controls[i];if(c->x+c->w>args[1].n||c->y+c->h>args[2].n)return fail(error,"Nowy rozmiar aplikacji nie miesci istniejacych kontrolek");}}
  else{memset(&app->scene,0,sizeof app->scene);memset(&app->input,0,sizeof app->input);}
  snprintf(app->scene.title,sizeof app->scene.title,"%s",args[0].s);app->scene.width=(unsigned)args[1].n;app->scene.height=(unsigned)args[2].n;app->scene.active=app->started=1;return 1;
 }
 if(!app->started)return fail(error,"Najpierw uzyj aplikacja");
 if(cmd==14){
  memset(&app->input,0,sizeof app->input);if(!app->scene.active){boolean(result,0);return 1;}
  int status=app->host.app(app->host.context,&app->scene,&app->input,error);
  if(status<0){memset(&app->input,0,sizeof app->input);if(error&&!error[0])fail(error,"Blad natywnej aplikacji");return -1;}
  if(!status){app->scene.active=0;memset(&app->input,0,sizeof app->input);}boolean(result,status>0&&app->scene.active);return 1;
 }
 if(cmd==13){app->scene.active=0;memset(&app->input,0,sizeof app->input);int status=app->host.app(app->host.context,&app->scene,&app->input,error);memset(&app->input,0,sizeof app->input);if(status<0){if(error&&!error[0])fail(error,"Nie mozna zamknac aplikacji");return -1;}return 1;}
 if(!app->scene.active)return fail(error,"Aplikacja jest zamknieta; uzyj aplikacja, aby otworzyc nowa");
 if(!namearg(args))return fail(error,"Nazwa kontrolki wymaga 1..63 bajtow poprawnego UTF-8 bez znakow sterujacych");
 TiControl *c=find(app,args[0].s);
 if(cmd>=1&&cmd<=5){
  if(!text(args+1,TI_APP_TEXT,1))return fail(error,"Tekst kontrolki wymaga poprawnego UTF-8 do 4095 bajtow");
  if(!integer(args+2,0,(int)app->scene.width)||!integer(args+3,0,(int)app->scene.height)||!integer(args+4,1,(int)app->scene.width)||!integer(args+5,1,(int)app->scene.height)||args[2].n+args[4].n>app->scene.width||args[3].n+args[5].n>app->scene.height)return fail(error,"Kontrolka wymaga calkowitych wspolrzednych i dodatniego rozmiaru w granicach aplikacji");
  if(c&&c->kind!=cmd)return fail(error,"Nazwa jest juz uzywana przez inny rodzaj kontrolki");
  if(!c){if(app->scene.count>=TI_APP_CONTROLS)return fail(error,"Osiagnieto limit 64 kontrolek");c=&app->scene.controls[app->scene.count++];memset(c,0,sizeof *c);snprintf(c->name,sizeof c->name,"%s",args[0].s);c->kind=cmd;c->enabled=c->visible=1;}
  snprintf(c->text,sizeof c->text,"%s",args[1].s);c->x=(int)args[2].n;c->y=(int)args[3].n;c->w=(int)args[4].n;c->h=(int)args[5].n;return 1;
 }
 if(!c)return fail(error,"Nie znaleziono kontrolki o tej nazwie");
 if(cmd==6){if(!text(args+1,TI_APP_TEXT,1))return fail(error,"Tekst kontrolki wymaga poprawnego UTF-8 do 4095 bajtow");snprintf(c->text,sizeof c->text,"%s",args[1].s);return 1;}
 if(cmd==7){if(result){result->kind=1;result->n=0;result->s=c->text;}return 1;}
 if(cmd==8){boolean(result,!strcmp(app->input.click,c->name));return 1;}
 if(cmd==9||cmd==10){if(c->kind!=TI_APP_CHECK)return fail(error,"Ta komenda wymaga kontrolki wybor");if(cmd==9){boolean(result,c->checked);return 1;}}
 if(!integer(args+1,0,1))return fail(error,"Stan kontrolki musi byc wartoscia logiczna lub liczba 0 albo 1");
 if(cmd==10)c->checked=(int)args[1].n;else if(cmd==11)c->enabled=(int)args[1].n;else c->visible=(int)args[1].n;return 1;
}
