#ifndef TI_LAYOUT_H
#define TI_LAYOUT_H
typedef struct {int x,y,w,h;} TiRect;
typedef struct {TiRect navigation,code,library,preview,console,status;int drawer_top;} TiLayout;
void ti_layout(int width,int height,int library,int drawer,int focus,TiLayout*);
#endif
