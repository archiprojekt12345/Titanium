#ifndef TITANIUM_H
#define TITANIUM_H
#include <stdio.h>
#include <stddef.h>
typedef struct TiProgram TiProgram;
typedef struct { int kind; double n; const char *s; } TiValue;
struct TiHost;
typedef struct { int line; char text[512]; } TiError;
TiProgram *ti_compile(const char *source, size_t length, TiError *error);
int ti_execute(TiProgram *program, FILE *input, FILE *output, TiError *error);
int ti_execute_host(TiProgram *program, FILE *input, FILE *output, TiError *error, const struct TiHost *host);
int ti_program_is_app(const TiProgram *program);
void ti_free(TiProgram *program);
int ti_run_file(FILE *file, int check, FILE *input, FILE *output, FILE *errors);
int ti_run_file_host(FILE *file, int check, FILE *input, FILE *output, FILE *errors, const struct TiHost *host);
#endif
