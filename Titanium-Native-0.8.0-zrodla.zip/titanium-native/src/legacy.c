#include "legacy.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {const char *s;size_t n;int kind,start;} LegacyToken;
enum {IDENT=256,NUMBER,STRING};
static unsigned read_cp(const char **p,const char *end) {
    const unsigned char *s=(const unsigned char*)*p;unsigned c=*s++;int n=0;
    if(c>=0xc2&&c<=0xdf){c&=31;n=1;}else if(c>=0xe0&&c<=0xef){c&=15;n=2;}else if(c>=0xf0&&c<=0xf4){c&=7;n=3;}
    while(n--&&s<(const unsigned char*)end&&(*s&192)==128)c=(c<<6)|(*s++&63);
    *p=(const char*)s;
    switch(c){case 0x105:return 'a';case 0x107:return 'c';case 0x119:return 'e';case 0x142:return 'l';case 0x144:return 'n';case 0xf3:return 'o';case 0x15b:return 's';case 0x17a:case 0x17c:return 'z';default:return c;}
}
static int word(LegacyToken t,const char *name) {
    if(t.kind!=IDENT)return 0;const char *s=t.s,*end=s+t.n;
    while(s<end&&*name)if(read_cp(&s,end)!=(unsigned char)*name++)return 0;
    return s==end&&!*name;
}
static const char *markers[]={"gra","sterowanie","monety","postac","obiekty","zniszcz","kolizja","trafienie","odleglosc","celuj","strzel","os","mysz","wybuch","drganie","dzwiek","calkowita","minimum","maksimum","ogranicz"};
static int marker(LegacyToken t){for(size_t i=0;i<sizeof markers/sizeof *markers;i++)if(word(t,markers[i]))return (int)i;return -1;}
static int ident(unsigned char c){return c>=128||isalpha(c)||c=='_';}
int ti_legacy_detect(const char *source) {
    if(!source)return 0;size_t len=strlen(source);
    if(len>250000)return 0;
    LegacyToken *ts=calloc(len+2,sizeof *ts);if(!ts)return 0;
    size_t n=0;const char *p=source;int start=1;
    if(len>=3&&!memcmp(p,"\xef\xbb\xbf",3))p+=3;
    while(*p){
        if(*p==' '||*p=='\t'||*p=='\r'){p++;continue;}
        if(*p=='#'||(p[0]=='/'&&p[1]=='/')){while(*p&&*p!='\n')p++;continue;}
        if(p[0]=='/'&&p[1]=='*'){p+=2;while(*p&&!(p[0]=='*'&&p[1]=='/')){if(*p=='\n')start=1;p++;}if(*p)p+=2;continue;}
        LegacyToken t={p,1,(unsigned char)*p,start};start=0;
        if(*p=='\n'||*p==';'){p++;t.kind='\n';start=1;}
        else if(*p=='\''||*p=='"'){char quote=*p++;t.kind=STRING;while(*p&&*p!=quote){if(*p=='\\'&&p[1])p++;p++;}if(*p)p++;}
        else if(isdigit((unsigned char)*p)||(*p=='.'&&isdigit((unsigned char)p[1]))){t.kind=NUMBER;while(isdigit((unsigned char)*p))p++;if(*p=='.'){p++;while(isdigit((unsigned char)*p))p++;}}
        else if(ident((unsigned char)*p)){t.kind=IDENT;p++;while(ident((unsigned char)*p)||isdigit((unsigned char)*p))p++;}
        else p++;
        t.n=(size_t)(p-t.s);ts[n++]=t;
    }
    int shadow[sizeof markers/sizeof *markers]={0},function_header=0;
    for(size_t i=0;i<n;i++){
        if(ts[i].kind=='\n')function_header=0;
        if(ts[i].start&&word(ts[i],"funkcja"))function_header=1;
        int m=marker(ts[i]);if(m<0)continue;
        /* A function, parameter or assigned variable with this spelling is a
           user name. Prefer an explicit mode over guessing its meaning. */
        if(function_header||(i+1<n&&ts[i+1].kind=='='))shadow[m]=1;
    }
    int found=0;
    for(size_t i=0;i<n&&!found;i++){
        if(ts[i].kind=='['||(ts[i].kind=='.'&&i&&ts[i-1].kind==IDENT&&i+1<n&&ts[i+1].kind==IDENT)){found=1;break;}
        if(ts[i].start&&word(ts[i],"co")&&i+1<n&&ts[i+1].kind!='='){
            if(word(ts[i+1],"klatke")){found=1;break;}
            for(size_t j=i+1;j<n&&ts[j].kind!='\n';j++)if(word(ts[j],"sekund")||word(ts[j],"sekundy")||word(ts[j],"sekunde")){found=1;break;}
            if(found)break;
        }
        if(ts[i].start&&word(ts[i],"dla")&&i+2<n&&word(ts[i+2],"w")){found=1;break;}
        int m=marker(ts[i]);
        if(m>=0&&!shadow[m]&&i+1<n&&ts[i+1].kind!='='&&(ts[i].start||ts[i+1].kind=='(')){found=1;break;}
        /* Some historical names are shared with native commands. Only route
           parenthesized arities which cannot be native commands. */
        if(i+1<n&&ts[i+1].kind=='('&&(word(ts[i],"tekst")||word(ts[i],"kolo")||word(ts[i],"usun")||word(ts[i],"napis"))){
            int depth=0,args=0,has=0;
            for(size_t j=i+1;j<n&&j<i+2048;j++){int k=ts[j].kind;if(k=='('){depth++;continue;}if(k==')'){if(!--depth)break;}if(depth==1){if(k==',')args++;else if(k!='\n')has=1;}}
            args+=has;
            if((word(ts[i],"tekst")&&args>=3)||(word(ts[i],"kolo")&&args==4)||(word(ts[i],"usun")&&args==2)||(word(ts[i],"napis")&&args==1))found=1;
        }
    }
    free(ts);return found;
}
static int fail(char error[256],const char *text){if(error){strncpy(error,text,255);error[255]=0;}return 0;}
int ti_legacy_write_html(FILE *out,const char *html,size_t html_len,const char *source,size_t length,char error[256]) {
    if(error)error[0]=0;
    if(!out||!html||(!source&&length)||length>250000)return fail(error,"Nieprawidlowe dane lub kod przekracza 250000 bajtow.");
    if(length&&memchr(source,0,length))return fail(error,"Kod nie moze zawierac znakow NUL.");
    size_t at=html_len;for(size_t i=0;i+7<=html_len;i++)if(!memcmp(html+i,"</body>",7))at=i;
    if(at==html_len)return fail(error,"Brak znacznika body w historycznym srodowisku.");
    static const char begin[]="\n<!-- Titanium compatibility: source is data, original runtime is unchanged. -->\n<script>\n(()=>{'use strict';const bytes=Uint8Array.from(atob('";
    static const char end[]="'),c=>c.charCodeAt(0));const source=new TextDecoder('utf-8',{fatal:true}).decode(bytes);const editor=document.querySelector('#code');editor.value=source;editor.dispatchEvent(new Event('input',{bubbles:true}));document.querySelector('#run').click();})();\n</script>\n";
    static const char b64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    if(fwrite(html,1,at,out)!=at||fwrite(begin,1,sizeof begin-1,out)!=sizeof begin-1)return fail(error,"Nie mozna zapisac pliku HTML.");
    for(size_t i=0;i<length;i+=3){unsigned a=(unsigned char)source[i],b=i+1<length?(unsigned char)source[i+1]:0,c=i+2<length?(unsigned char)source[i+2]:0;char buf[4]={b64[a>>2],b64[((a&3)<<4)|(b>>4)],i+1<length?b64[((b&15)<<2)|(c>>6)]:'=',i+2<length?b64[c&63]:'='};if(fwrite(buf,1,4,out)!=4)return fail(error,"Nie mozna zapisac pliku HTML.");}
    if(fwrite(end,1,sizeof end-1,out)!=sizeof end-1||fwrite(html+at,1,html_len-at,out)!=html_len-at||fflush(out))return fail(error,"Nie mozna zapisac pliku HTML.");
    return 1;
}
