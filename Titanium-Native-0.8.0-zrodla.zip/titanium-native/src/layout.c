#include "layout.h"
static int min(int a,int b){return a<b?a:b;}
void ti_layout(int w,int h,int library,int drawer,int focus,TiLayout*l){
 *l=(TiLayout){0};int gap=12,margin=16,top=112,bottom=h-36;
 int nav=focus?0:156,lib=library&&!focus?(w>=1400?280:228):0;
 int left=margin+(nav?nav+gap:0),right=w-margin-(lib?lib+gap:0),workw=right-left;
 int panel=drawer&&!focus?min(300,(bottom-top)*42/100):0;
 int codebottom=bottom-(panel?panel+32:0);
 l->navigation=(TiRect){margin,top,nav,nav?bottom-top:0};l->library=(TiRect){w-margin-lib,top,lib,lib?bottom-top:0};
 l->code=(TiRect){left,top,workw,codebottom-top};
 if(panel){int previeww=(workw-gap)*65/100;l->drawer_top=codebottom+32;l->preview=(TiRect){left,l->drawer_top,previeww,panel};l->console=(TiRect){left+previeww+gap,l->drawer_top,workw-previeww-gap,panel};}
 l->status=(TiRect){margin,h-26,w-margin*2,22};
}
