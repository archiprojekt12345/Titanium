#include "files.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
static int fail(char e[256],const char*s){snprintf(e,256,"%s",s);return 0;}
static FILE*open_file(const char*path,const char*mode){
 if(!path||!*path||strlen(path)>16000)return NULL;
#ifdef _WIN32
 int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,NULL,0);if(n<=0)return NULL;
 wchar_t*w=malloc((size_t)n*sizeof*w);if(!w)return NULL;MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,w,n);FILE*f=_wfopen(w,!strcmp(mode,"rb")?L"rb":L"wb");free(w);return f;
#else
 return fopen(path,mode);
#endif
}
static int valid_utf8(const char*s,size_t n){
 size_t i=0;while(i<n){unsigned c=(unsigned char)s[i++],more,min;if(!c)return 0;if(c<128)continue;
 if(c>=0xc2&&c<=0xdf){more=1;min=128;c&=31;}else if(c>=0xe0&&c<=0xef){more=2;min=2048;c&=15;}else if(c>=0xf0&&c<=0xf4){more=3;min=65536;c&=7;}else return 0;
 if(n-i<more)return 0;while(more--){unsigned next=(unsigned char)s[i++];if((next&0xc0)!=0x80)return 0;c=(c<<6)|(next&63);}if(c<min||c>0x10ffff||(c>=0xd800&&c<=0xdfff))return 0;
 }return 1;
}
int ti_file_read(const char*path,char**out,char e[256]){
 *out=NULL;FILE*f=open_file(path,"rb");if(!f)return fail(e,"Nie mozna odczytac pliku. Sprawdz nazwe i folder roboczy.");
 char*s=malloc(1048578);if(!s){fclose(f);return fail(e,"Brak pamieci podczas odczytu pliku.");}size_t n=fread(s,1,1048577,f);int bad=ferror(f);fclose(f);
 if(bad||n>1048576||!valid_utf8(s,n)){free(s);return fail(e,"Plik musi byc tekstem UTF-8 bez NUL, do 1 MB.");}s[n]=0;*out=s;return 1;
}
int ti_file_write(const char*path,const char*text,char e[256]){
 size_t n=text?strlen(text):0;if(!text||n>1048576||!valid_utf8(text,n))return fail(e,"Zapis wymaga tekstu UTF-8 do 1 MB.");
 FILE*f=open_file(path,"wb");if(!f)return fail(e,"Nie mozna zapisac pliku. Sprawdz folder i uprawnienia.");int ok=fwrite(text,1,n,f)==n;if(fclose(f))ok=0;return ok?1:fail(e,"Blad zapisu pliku.");
}
