#include "titanium.h"
#include <stdlib.h>
#include <string.h>
#include "commands.h"
int ti_run_file_host(FILE *file,int check,FILE *input,FILE *output,FILE *errors,const struct TiHost *host) {
    char *src=malloc(250002);if(!src){fputs("Blad: brak pamieci.\n",errors);return 1;}
    size_t len=fread(src,1,250001,file);src[len]=0;TiError e;
    if(ferror(file)){free(src);fputs("Blad odczytu pliku.\n",errors);return 1;}
    TiProgram *p=ti_compile(src,len,&e);free(src);
    if(!p){fprintf(errors,"Blad — wiersz %d: %s\n",e.line,e.text);return 1;}
    int ok=check||ti_execute_host(p,input,output,&e,host);
    if(!ok)fprintf(errors,"Blad — wiersz %d: %s\n",e.line,e.text);
    else if(check)fputs("Kod poprawny.\n",output);
    ti_free(p);return ok?0:1;
}
int ti_run_file(FILE *file,int check,FILE *input,FILE *output,FILE *errors){return ti_run_file_host(file,check,input,output,errors,NULL);}
#ifndef _WIN32
int main(int argc,char **argv) {
    if(argc>1&&!strcmp(argv[1],"--komendy")){ti_write_commands(stdout);return 0;}
    int check=argc>1&&!strcmp(argv[1],"--check"),i=check?2:1;
    if(argc<=i){fputs("Titanium Native: titanium [--check] program.ti\n",stderr);return 2;}
    FILE *f=fopen(argv[i],"rb");if(!f){perror("Plik");return 2;}
    int r=ti_run_file(f,check,stdin,stdout,stderr);fclose(f);return r;
}
#endif
