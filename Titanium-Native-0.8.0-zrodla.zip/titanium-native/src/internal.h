#ifndef TI_INTERNAL_H
#define TI_INTERNAL_H
#include "titanium.h"
#include <setjmp.h>
#include <stdint.h>
#define TI_CODE 65536
#define TI_NAMES 1024
#define TI_TOKENS 65536
#define TI_FUNS 128
#define TI_PARAMS 16
#define TI_STACK 4096
#define TI_FRAMES 64
#define TI_LOCALS 128
typedef TiValue Value;
typedef struct Mem {struct Mem *next; size_t size; unsigned permanent,mark; } Mem;
typedef struct {int kind, line, id,begin,finish; Value value;} Token;
enum {T_EOF=256,T_NL,T_ID,T_NUM,T_STR,T_EQ,T_NE,T_LE,T_GE};
enum {O_CONST,O_LOAD,O_STORE,O_POP,O_DUP,O_ADD,O_SUB,O_MUL,O_DIV,O_MOD,
      O_EQ,O_NE,O_LT,O_LE,O_GT,O_GE,O_NEG,O_NOT,O_JMP,O_JZ,O_JNZ,O_CALL,
      O_RET,O_COUNT,O_HALT,O_FRAME};
typedef struct {int op,a,b,line; Value value;} Ins;
typedef struct {int name,entry,argc,params[TI_PARAMS];} Function;
struct TiProgram {
    jmp_buf jump; TiError error; Mem *mem; size_t bytes;int runtime;
    Token tokens[TI_TOKENS]; int nt,pos,line,depth,block,in_function,temp,arg_mode;
    Ins code[TI_CODE]; int nc;
    char *names[TI_NAMES]; int nn;
    unsigned char globals[TI_NAMES],locals[TI_NAMES];
    Function funcs[TI_FUNS]; int nf;
};
void ti_fail(TiProgram *p, const char *format, ...);
void *ti_alloc(TiProgram *p, size_t size);
char *ti_string(TiProgram *p,const char *text,size_t length);
int ti_builtin(const char *name);
Value ti_number(double n);
Value ti_bool(int n);
Value ti_text(const char *s);
#endif
