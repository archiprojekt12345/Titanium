#include "commands.h"
#include "version.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define C(n,lo,hi,pre,g,mask,syntax,desc) {n,lo,hi,pre,g,mask,syntax,desc}
static const TiCommand commands[]={
C("pisz",0,16,1,0,0,"pisz \"Wynik:\" punkty","Wypisuje wartosci oddzielone spacjami i konczy wiersz."),
C("pytaj",0,1,1,0,0,"imie = pytaj \"Imie? \"","Zwraca odpowiedz jako tekst; wpisz ja w dolnym polu konsoli."),
C("wczytaj",0,0,0,0,0,"imie = wczytaj","Odczytuje tekst bez wypisywania pytania."),
C("liczba",1,1,1,0,0,"wiek = liczba pytaj \"Wiek? \"","Zamienia tekst na liczbe; bledny tekst zglasza blad."),
C("tekst",1,1,1,0,0,"napis = tekst 123","Zamienia wartosc na tekst."),
C("losuj",2,2,2,0,0,"sekret = losuj 1 20","Losuje liczbe calkowita wlacznie z obiema granicami."),
C("dlugosc",1,1,1,0,0,"n = dlugosc \"kot\"","Zwraca dlugosc tekstu w znakach."),
C("zaokraglij",1,1,1,0,0,"n = zaokraglij 2.7","Zaokragla do najblizszej liczby calkowitej."),
C("pierwiastek",1,1,1,0,0,"n = pierwiastek 9","Zwraca pierwiastek kwadratowy liczby nieujemnej."),
C("abs",1,1,1,0,0,"n = abs -4","Zwraca wartosc bezwzgledna."),
C("wywolaj",1,1,1,1,1,"wywolaj 2D","Wlacza natywny podglad 2D; umiesc na poczatku programu."),
C("okno",3,3,3,1,0,"okno \"Moja gra\" 640 360","Ustawia tytul i logiczny rozmiar sceny (160..3840 x 90..2160)."),
C("tlo",1,1,1,1,1,"tlo granatowy","Ustawia kolor tla."),
C("prostokat",6,6,6,1,33,"prostokat gracz 40 40 32 32 niebieski","Tworzy/aktualizuje prostokat: nazwa x y szerokosc wysokosc kolor."),
C("kolo",5,5,5,1,17,"kolo moneta 300 150 12 zloty","Tworzy/aktualizuje kolo: nazwa srodek_x srodek_y promien kolor."),
C("obraz",6,6,6,1,1,"obraz gracz \"bohater.png\" 40 40 32 32","Wczytuje PNG/JPG/JPEG/BMP z folderu assety; x/y to lewy gorny rog."),
C("napis",5,5,5,1,17,"napis wynik \"Punkty: 0\" 12 12 bialy","Tworzy/aktualizuje napis: nazwa tekst x y kolor."),
C("pozycja",3,3,3,1,1,"pozycja gracz 100 100","Ustawia wspolrzedne obiektu. Dla kola sa to wspolrzedne srodka."),
C("przesun",3,3,3,1,1,"przesun gracz 2 0","Przesuwa obiekt o podane dx i dy."),
C("rozmiar",3,3,3,1,1,"rozmiar gracz 48 48","Zmienia szerokosc i wysokosc; dla kola podaj rowne srednice."),
C("kolor",2,2,2,1,3,"kolor gracz czerwony","Zmienia kolor figury lub napisu."),
C("ukryj",1,1,1,1,1,"ukryj moneta","Ukrywa obiekt i wylacza jego kolizje."),
C("pokaz",1,1,1,1,1,"pokaz moneta","Pokazuje istniejacy obiekt."),
C("usun",1,1,1,1,1,"usun moneta","Usuwa obiekt i zwalnia jego miejsce (limit 128)."),
C("steruj",2,2,2,1,1,"steruj gracz 220","Wlacza ruch WASD/strzalkami w pikselach na sekunde i ograniczenie do sceny."),
C("dotyka",2,2,2,1,3,"jesli dotyka gracz moneta","Sprawdza kolizje prostokatow/kol/obrazow; napisy nie koliduja."),
C("x",1,1,1,1,1,"poziom = x gracz","Zwraca wspolrzedna x obiektu."),
C("y",1,1,1,1,1,"pion = y gracz","Zwraca wspolrzedna y obiektu."),
C("klawisz",1,1,1,1,1,"jesli klawisz spacja","Sprawdza, czy klawisz jest trzymany. Kliknij podglad, aby nim sterowac."),
C("wcisnieto",1,1,1,1,1,"jesli wcisnieto spacja","Prawda tylko w klatce nowego nacisniecia klawisza."),
C("klik",1,1,1,1,1,"jesli klik lewy","Prawda w klatce nowego klikniecia mysza (lewy/prawy)."),
C("mysz_x",0,0,0,1,0,"poziom = mysz_x","Zwraca x myszy w logicznych wspolrzednych sceny."),
C("mysz_y",0,0,0,1,0,"pion = mysz_y","Zwraca y myszy w logicznych wspolrzednych sceny."),
C("czas",0,0,0,1,0,"sekundy = czas","Czas gry w sekundach."),
C("delta",0,0,0,1,0,"przesun gracz 100 * delta 0","Czas ostatniej klatki w sekundach."),
C("klatka",0,0,0,1,0,"dopoki klatka","Publikuje scene i rozpoczyna nastepna klatke; zwykle uzywaj zawsze."),
C("koncz",0,0,0,1,0,"koncz","Konczy petle gry i zamyka aktywny tryb 2D."),
C("platformowka",1,1,1,1,1,"platformowka gracz","Wlacza strzalki/A/D, skok spacja, grawitacje i kolizje. Domyslnie bieg 220, skok 430, grawitacja 900. Prostokat lub obraz."),
C("sciana",1,1,1,1,1,"sciana ziemia","Prostokat/obraz staje sie nieruchoma przeszkoda ze wszystkich stron. Nie ustawiaj postaci wewnatrz sciany."),
C("platforma",1,1,1,1,1,"platforma polka","Prostokat/obraz zatrzymuje spadajace ciala, przepuszcza od dolu i bokow."),
C("fizyka",1,1,1,1,1,"fizyka skrzynka","Wlacza grawitacje i kolizje ze scianami/platformami bez sterowania. Ciala nie popychaja sie wzajemnie."),
C("chodzenie",2,2,2,1,1,"chodzenie gracz 300","Ustawia szybkosc biegu sterownika platformowki: 0..2000 pikseli/s."),
C("skakanie",2,2,2,1,1,"skakanie gracz 500","Ustawia sile skoku sterownika platformowki: 0..2000 pikseli/s."),
C("grawitacja",2,2,2,1,1,"grawitacja gracz 900","Ustawia przyspieszenie 0..5000 pikseli/s2; wlacza fizyke jesli byla wylaczona."),
C("predkosc",3,3,3,1,1,"predkosc pocisk 300 0","Utrzymuje ruch vx vy w pikselach/s bez delta, -2000..2000. Wylacza sterownik i patrol. Nowe cialo nie ma grawitacji."),
C("na_ziemi",1,1,1,1,1,"jesli na_ziemi gracz","Prawda, gdy cialo stoi na widocznej scianie/platformie."),
C("spada",1,1,1,1,1,"jesli spada gracz","Prawda, gdy cialo ma dodatnia predkosc pionowa."),
C("odbij",2,2,2,1,1,"odbij gracz 300","Wybija cialo do gory nawet w powietrzu; sila 0..2000. Przydatne po nadepnieciu przeciwnika."),
C("patrol",4,4,4,1,1,"patrol wrog 400 700 80","Wlacza fizyke i patrol od lewej do prawej granicy X lewego boku, z szybkoscia 1..2000. Zawraca na scianach; nie wykrywa przepasci."),
C("swiat",2,2,2,1,0,"swiat 2400 480","Ustawia rozmiar swiata 160..100000 x 90..100000. Okno to tylko widoczny fragment."),
C("kamera",1,1,1,1,1,"kamera gracz","Kamera sledzi srodek obiektu w granicach swiata. x/y nadal zwracaja pozycje w swiecie."),
C("widok",2,2,2,1,0,"widok 500 0","Ustawia lewy gorny rog kamery w swiecie; wylacza sledzenie, ogranicza do granic swiata."),
C("przypnij",1,1,1,1,1,"przypnij wynik","Przypina obiekt do ekranu (HUD), wylacza jego fizyke i kolizje. Kolejne aktualizacje napisu zachowuja przypiecie."),
C("odrodzenie",3,3,3,1,1,"odrodzenie gracz 40 240","Ustawia punkt odrodzenia; samo nie przenosi postaci. Poczatkowo jest nim miejsce wlaczenia fizyki."),
C("odrodz",1,1,1,1,1,"odrodz gracz","Przenosi do punktu odrodzenia, pokazuje obiekt, zeruje predkosci i bufor skoku."),
C("animuj",3,3,3,1,1,"animuj gracz 4 8","Animuje obraz z poziomego paska 1..64 rownych klatek, 0..60 klatek/s. 0 zatrzymuje na pierwszej. Rozmiar obiektu jest rozmiarem jednej klatki.") ,
C("warstwa",2,2,2,1,1,"warstwa gracz 10","Kolejnosc rysowania -1000..1000. Wieksza warstwa jest na wierzchu."),
C("obrot",2,2,2,1,1,"obrot gracz 30","Wizualny obrot w stopniach wokol srodka. Nie zmienia kolizji."),
C("skala",2,2,2,1,1,"skala gracz 1.5","Wizualne powiekszenie 0.1..10. Nie zmienia kolizji."),
C("przezroczystosc",2,2,2,1,1,"przezroczystosc duch 50","0 = nieprzezroczysty, 100 = niewidoczny. Kolizje pozostaja aktywne."),
C("paralaksa",2,2,2,1,1,"paralaksa gory 0.4","Predkosc przesuwania tla wzgledem kamery 0..2; domyslnie 1."),
C("lustro",2,2,2,1,1,"lustro gracz 1","Odbicie poziome 0/1. Nie zmienia fizyki."),
C("obrys",3,3,3,1,5,"obrys gracz 2 bialy","Obrys figury: grubosc 0..32 i kolor. 0 wylacza."),
C("zoom",1,1,1,1,0,"zoom 1.5","Powiekszenie kamery 0.25..4. HUD pozostaje staly."),
C("gradient",2,2,2,1,3,"gradient granatowy niebieski","Pionowy gradient tla; tlo wylacza gradient."),
C("czasteczki",4,4,4,1,8,"czasteczki 100 100 30 zloty","Jednorazowy wybuch 1..100 czasteczek w swiecie. Bufor 512; nadmiar jest pomijany. Wygasaja automatycznie."),
C("bufor",2,2,2,3,1,"bufor dane 256","Tworzy lub zeruje bufor 0..65536 bajtow; maksymalnie 16 buforow."),
C("wpisz_bajt",3,3,3,3,1,"wpisz_bajt dane 0 255","Zapisuje bajt 0..255 pod indeksem liczonym od zera."),
C("bajt",2,2,2,3,1,"wynik = bajt dane 0","Zwraca bajt pod indeksem liczonym od zera."),
C("rozmiar_bufora",1,1,1,3,1,"n = rozmiar_bufora dane","Zwraca rozmiar bufora w bajtach."),
C("zwolnij_bufor",1,1,1,3,1,"zwolnij_bufor dane","Usuwa bufor i zwalnia jego miejsce."),
C("bity_i",2,2,2,3,0,"wynik = bity_i 255 15","Bitowe AND liczb calkowitych 0..4294967295."),
C("bity_lub",2,2,2,3,0,"wynik = bity_lub 16 1","Bitowe OR liczb calkowitych 0..4294967295."),
C("bity_xor",2,2,2,3,0,"wynik = bity_xor 255 15","Bitowe XOR liczb calkowitych 0..4294967295."),
C("bity_nie",1,1,1,3,0,"wynik = bity_nie 0","Odwraca wszystkie 32 bity liczby."),
C("bity_lewo",2,2,2,3,0,"wynik = bity_lewo 1 8","Przesuwa liczbe 32-bitowa w lewo o 0..31 bitow."),
C("bity_prawo",2,2,2,3,0,"wynik = bity_prawo 256 8","Przesuwa liczbe 32-bitowa w prawo o 0..31 bitow.")
,
C("aplikacja",3,3,3,2,0,"aplikacja \"Moja aplikacja\" 640 420","Otwiera aplikacje okienkowa. Dodaj kontrolki i petle zawsze."),
C("przycisk",6,6,6,2,1,"przycisk ok \"Oblicz\" 20 100 160 32","Przycisk: nazwa tekst x y szerokosc wysokosc."),
C("pole",6,6,6,2,1,"pole imie \"\" 20 50 300 32","Jednowierszowe pole tekstowe. Odczyt przez wartosc."),
C("notatnik",6,6,6,2,1,"notatnik tresc \"\" 20 50 580 280","Wielowierszowe pole tekstowe."),
C("etykieta",6,6,6,2,1,"etykieta wynik \"Wynik\" 20 150 300 40","Tekst w oknie aplikacji."),
C("wybor",6,6,6,2,1,"wybor zgoda \"Aktywne\" 20 200 200 30","Pole wyboru. Sprawdz przez zaznaczone."),
C("ustaw_tekst",2,2,2,2,1,"ustaw_tekst wynik \"Gotowe\"","Zmienia tekst kontrolki."),
C("wartosc",1,1,1,2,1,"imie = wartosc pole_imie","Zwraca aktualny tekst kontrolki."),
C("kliknieto",1,1,1,2,1,"jesli kliknieto ok","Prawda dla klikniecia obslugiwanego w tej klatce."),
C("zaznaczone",1,1,1,2,1,"jesli zaznaczone zgoda","Sprawdza stan pola wyboru."),
C("ustaw_wybor",2,2,2,2,1,"ustaw_wybor zgoda prawda","Ustawia pole wyboru: prawda/falsz lub 1/0."),
C("wlacz",2,2,2,2,1,"wlacz ok falsz","Wlacza/wylacza mozliwosc uzywania kontrolki."),
C("widoczny",2,2,2,2,1,"widoczny wynik prawda","Pokazuje lub ukrywa kontrolke aplikacji."),
C("zamknij_aplikacje",0,0,0,2,0,"zamknij_aplikacje","Zamyka okno aplikacji i konczy petle zawsze.")
,
C("czytaj_plik",1,1,1,0,0,"tresc = czytaj_plik \"notatka.txt\"","Odczytuje tekst UTF-8 do 1 MB z folderu roboczego albo pelnej sciezki."),
C("zapisz_plik",2,2,2,0,0,"zapisz_plik \"notatka.txt\" tresc","Zapisuje tekst UTF-8 do 1 MB. Nadpisuje istniejacy plik.")
,
C("sin",1,1,1,0,0,"fala = sin czas","Sinus kata w radianach."),
C("cos",1,1,1,0,0,"fala = cos czas","Cosinus kata w radianach."),
C("poswiata",4,4,4,1,9,"poswiata gracz 20 80 niebieski","Poswiata obiektu: promien 0..64, sila 0..100, kolor."),
C("swiatlo",4,4,4,1,9,"swiatlo gracz 160 60 niebieski","Swiatlo sledzace obiekt: promien 10..1000, sila 0..100, kolor."),
C("smuga",3,3,3,1,5,"smuga gracz 16 niebieski","Smuga obiektu: dlugosc 0..24, kolor. 0 wylacza."),
C("wstrzas",2,2,2,1,0,"wstrzas 8 0.5","Drganie kamery: sila 0..30 i czas 0..5 sekund; HUD pozostaje staly.")

};
size_t ti_command_count(void){return sizeof commands/sizeof *commands;}
const TiCommand *ti_command_at(size_t i){return i<sizeof commands/sizeof *commands?&commands[i]:NULL;}
const TiCommand *ti_command(const char *name) {
    for(size_t i=0;i<sizeof commands/sizeof *commands;i++)if(!strcmp(commands[i].name,name))return &commands[i];return NULL;
}
char *ti_commands_text(void) {
    char *s=calloc(1,40000);if(!s)return NULL;size_t n=0;
#define ADD(...) do {int k=snprintf(s+n,40000-n,__VA_ARGS__);if(k<0||(size_t)k>=40000-n){free(s);return NULL;}n+=(size_t)k;}while(0)
    ADD("TITANIUM NATIVE " TI_VERSION " - WSZYSTKIE ISTNIEJACE KOMENDY\n================================================\n\nTen plik jest generowany z rejestru kompilatora. Nie zawiera planowanych funkcji.\n\nZASADA\nJedno polecenie na wiersz, od lewej krawedzi. Bez tabow i wciec.\nArgumenty oddzielaj zwyklymi spacjami.\nNawiasy, przecinki i sredniki nie sa wymagane. Tekst zapisuj w cudzyslowach.\nNazwy komend sa bez polskich znakow. Tekst moze miec polskie znaki.\nNazwy obiektow, kolorow i klawiszy zapisujesz bez cudzyslowow.\nLiczby dziesietne: 2.5. Ujemne argumenty: -2 (znak przy liczbie).\nZlozone argumenty mozna grupowac, np. (2 + 3). Przy funkcjach bez\nnawiasow argumenty liczbowe sa pojedynczymi wartosciami lub wywolaniami.\nZapis z nawiasami i przecinkami z wersji 0.3 nadal dziala.\n\nSKLADNIA I BLOKI\n");
    ADD("nazwa = wartosc     - przypisuje wartosc, np. punkty = 0\nustaw nazwa wartosc - to samo, bez znaku =\ndodaj nazwa wartosc - zwieksza zmienna\nodejmij nazwa wartosc - zmniejsza zmienna\njesli warunek / inaczej / koniec - warunek; inaczej jest opcjonalne\npowtorz liczba / koniec - powtarza blok\ndopoki warunek / koniec - powtarza, poki warunek jest prawdziwy\ndla licznik od poczatek do koniec_zakresu / koniec - liczy rosnaco wlacznie\nfunkcja nazwa parametr1 parametr2 / koniec - wlasna funkcja, do 16 parametrow\nzwroc wartosc - zwraca wynik funkcji; bez zwroc funkcja zwraca 0\nzawsze / koniec - petla gry 2D lub aplikacji okienkowej\nprawda / falsz - wartosci logiczne\ni / lub / nie - operatory logiczne z krotkim spieciem\n# komentarz lub // komentarz - komentarz do konca wiersza\n\nPOROWNANIA\n= lub rowne         - rowne (== dziala dla zgodnosci)\nrozne               - rozne (!= tez dziala)\n> lub wieksze       - wieksze\n< lub mniejsze      - mniejsze\nconajmniej          - wieksze lub rowne (>= tez dziala)\nnajwyzej            - mniejsze lub rowne (<= tez dziala)\nDzialania: + - * / %% i opcjonalne nawiasy grupujace.\nW przypisaniu = zapisuje wartosc; po jesli/dopoki = porownuje.\n\nKOMENDY KONSOLI I LICZENIA\n");
    int previous_game=-1;
    for(size_t i=0;i<sizeof commands/sizeof *commands;i++){
        const TiCommand *c=&commands[i];if(c->game!=previous_game){if(c->game==1)ADD("\nKOMENDY GIER 2D\n");else if(c->game==2)ADD("\nKOMENDY APLIKACJI\n");else if(c->game==3)ADD("\nPAMIEC I OPERACJE BITOWE\n");}previous_game=c->game;
        ADD("\n%s\n  %s\n  %s\n",c->name,c->syntax,c->description);
    }
    ADD("\nKOLORY\nczarny bialy czerwony zielony niebieski zolty zloty pomaranczowy\nfioletowy rozowy szary granatowy lub tekst \"#RRGGBB\".\n\nKLAWISZE\nlewo prawo gora dol spacja enter escape oraz a..z i 0..9.\nMysz: lewy prawy. Kliknij podglad, aby otrzymywal sterowanie.\n\nASSETY\nZapisany program: folder assety obok pliku .ti.\nNiezapisany program: folder assety obok " TI_EXE_NAME ".\nEksport: folder assety obok wlasnego EXE.\nPliki PNG JPG JPEG BMP; zwykla nazwa bez podfolderow i bez .. .\nPrzyklad: obraz gracz \"bohater.png\" 40 40 32 32\nWspolrzedne figur/obrazow: lewy gorny rog. Kolo: srodek.\n\nLIMITY\n128 obiektow; 250000 bajtow kodu UTF-8; 1 MB wypisanego wyniku;\n32 MB pamieci roboczej; 16 argumentow; 63 zagniezdzone wywolania.\n5000000 instrukcji przed petla lub pomiedzy klatkami.\nScena 160..3840 x 90..2160; domyslnie 640x360.\n\nPRZYKLAD BEZ NAWIASOW I PRZECINKOW\nwywolaj 2D\ntlo granatowy\nprostokat gracz 40 40 32 32 niebieski\nkolo moneta 300 150 12 zloty\nsteruj gracz 220\npunkty = 0\nzawsze\n    jesli dotyka gracz moneta\n        dodaj punkty 1\n        pozycja moneta losuj 20 620 losuj 20 340\n    koniec\n    napis wynik \"Punkty: \" + punkty 12 12 bialy\nkoniec\n");
#undef ADD
    /* Keep the complete reference and its code examples flush left. */
    size_t write=0;int start=1;
    for(size_t read=0;s[read];read++){
        char c=s[read];if(start&&(c==' '||c=='\t'))continue;
        s[write++]=c;start=c=='\n'||c=='\r';
    }s[write]=0;
    return s;
}
void ti_write_commands(FILE *f){char *s=ti_commands_text();if(s){fputs(s,f);free(s);}}
