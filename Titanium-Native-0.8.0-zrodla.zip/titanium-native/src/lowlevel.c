#include "lowlevel.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

enum { BUFFER, WRITE_BYTE, READ_BYTE, BUFFER_SIZE, FREE_BUFFER,
       BIT_AND, BIT_OR, BIT_XOR, BIT_NOT, BIT_LEFT, BIT_RIGHT };
static const struct { const char *name; int argc; } commands[] = {
    {"bufor",2}, {"wpisz_bajt",3}, {"bajt",2}, {"rozmiar_bufora",1},
    {"zwolnij_bufor",1}, {"bity_i",2}, {"bity_lub",2}, {"bity_xor",2},
    {"bity_nie",1}, {"bity_lewo",2}, {"bity_prawo",2}
};
static int invalid(char error[256],const char *message) {
    if(error)snprintf(error,256,"%s",message);
    return -1;
}
static int integer(TiValue value,uint32_t maximum,uint32_t *out) {
    if(value.kind!=0 || !isfinite(value.n) || value.n<0 ||
       value.n>(double)maximum || floor(value.n)!=value.n)return 0;
    *out=(uint32_t)value.n;
    return 1;
}
static int buffer_name(TiValue value,char out[TI_MEMORY_NAME+1]) {
    if(value.kind!=1 || !value.s || !value.s[0])return 0;
    size_t n=0;
    while(value.s[n]) {
        unsigned char c=(unsigned char)value.s[n];
        if(n==TI_MEMORY_NAME || c<32 || c>126)return 0;
        out[n++]=(char)c;
    }
    out[n]=0;
    return 1;
}
void ti_memory_init(TiMemory *memory) {
    if(memory)memset(memory,0,sizeof *memory);
}
int ti_memory_call(TiMemory *memory,const char *name,int argc,
                   const TiValue *args,TiValue *result,char error[256]) {
    if(error)error[0]=0;
    int command=-1;
    if(name)for(size_t i=0;i<sizeof commands/sizeof *commands;i++)
        if(strcmp(name,commands[i].name)==0){command=(int)i;break;}
    if(command<0)return 0;
    if(argc!=commands[command].argc || !args)
        return invalid(error,"Niepoprawna liczba argumentow polecenia pamieci.");
    if(!memory || !result)return invalid(error,"Brak stanu lub wyniku polecenia pamieci.");
    uint32_t a=0,b=0;
    if(command>=BIT_AND) {
        if(!integer(args[0],UINT32_MAX,&a))
            return invalid(error,"Operacja bitowa wymaga liczby calkowitej od 0 do 4294967295.");
        if(command!=BIT_NOT && !integer(args[1],command>=BIT_LEFT?31:UINT32_MAX,&b))
            return invalid(error,"Niepoprawny argument lub przesuniecie bitowe (0..31).");
        switch(command) {
            case BIT_AND:a&=b;break;
            case BIT_OR:a|=b;break;
            case BIT_XOR:a^=b;break;
            case BIT_NOT:a^=UINT32_MAX;break;
            case BIT_LEFT:a=(uint32_t)((uint64_t)a<<b);break;
            case BIT_RIGHT:a>>=b;break;
        }
        *result=(TiValue){0,(double)a,NULL};
        return 1;
    }
    char copied_name[TI_MEMORY_NAME+1];
    if(!buffer_name(args[0],copied_name))
        return invalid(error,"Nazwa bufora musi miec od 1 do 63 drukowalnych znakow ASCII.");
    int slot=-1,free_slot=-1;
    for(int i=0;i<TI_MEMORY_BUFFERS;i++) {
        TiMemoryBuffer *buffer=&memory->buffers[i];
        if(buffer->used) {
            if(strcmp(buffer->name,copied_name)==0)slot=i;
        } else if(free_slot<0)free_slot=i;
    }
    if(command==BUFFER) {
        if(!integer(args[1],TI_MEMORY_BYTES,&a))
            return invalid(error,"Rozmiar bufora musi byc liczba calkowita od 0 do 65536.");
        if(slot<0)slot=free_slot;
        if(slot<0)return invalid(error,"Osiagnieto limit 16 buforow.");
        TiMemoryBuffer *buffer=&memory->buffers[slot];
        memset(buffer,0,sizeof *buffer);
        memcpy(buffer->name,copied_name,strlen(copied_name)+1);
        buffer->size=(size_t)a;
        buffer->used=1;
    } else {
        if(slot<0)return invalid(error,"Nie znaleziono bufora o tej nazwie.");
        TiMemoryBuffer *buffer=&memory->buffers[slot];
        if(command==BUFFER_SIZE) {
            *result=(TiValue){0,(double)buffer->size,NULL};
            return 1;
        }
        if(command==FREE_BUFFER)memset(buffer,0,sizeof *buffer);
        else {
            if(!integer(args[1],TI_MEMORY_BYTES-1,&a) || (size_t)a>=buffer->size)
                return invalid(error,"Indeks bajtu jest poza zakresem bufora.");
            if(command==WRITE_BYTE) {
                if(!integer(args[2],255,&b))
                    return invalid(error,"Bajt musi byc liczba calkowita od 0 do 255.");
                buffer->bytes[a]=(unsigned char)b;
            } else {
                *result=(TiValue){0,(double)buffer->bytes[a],NULL};
                return 1;
            }
        }
    }
    *result=(TiValue){0,0,NULL};
    return 1;
}
