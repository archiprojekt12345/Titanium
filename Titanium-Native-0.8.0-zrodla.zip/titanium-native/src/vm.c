#include "internal.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include "commands.h"
#include "game.h"
#include "lowlevel.h"
#include "app.h"
#include "files.h"

typedef struct {int id;Value value;} Local;
typedef struct {int ret,base,n;Local locals[TI_LOCALS];} Frame;
typedef struct {
    Value stack[TI_STACK],globals[TI_NAMES];unsigned char defined[TI_NAMES];
    Frame frames[TI_FRAMES];int sp,fp,pc;unsigned long steps;size_t written;
    FILE *in,*out;
    TiGame game;TiMemory memory;TiApp app;
} VM;
int ti_builtin(const char *n) {
    return ti_command(n)!=NULL;
}
static void push(TiProgram *p,VM *v,Value x){if(v->sp==TI_STACK)ti_fail(p,"Przekroczono limit stosu wartosci.");v->stack[v->sp++]=x;}
static Value pop(TiProgram *p,VM *v){if(!v->sp)ti_fail(p,"Pusty stos wartosci.");return v->stack[--v->sp];}
static double num(TiProgram *p,Value x){if(x.kind==1)ti_fail(p,"To dzialanie wymaga liczby.");return x.n;}
static int truth(Value x){return x.kind==1?x.s[0]!=0:x.n!=0;}
static const char *text(TiProgram *p,Value x) {
    if(x.kind==1)return x.s;if(x.kind==2)return x.n?"prawda":"falsz";
    char s[64];snprintf(s,sizeof s,"%.15g",x.n==0?0:x.n);return ti_string(p,s,strlen(s));
}
static void write_out(TiProgram *p,VM *v,const char *s) {
    size_t n=strlen(s);if(v->written+n>1024*1024)ti_fail(p,"Przekroczono limit wyniku (1 MB). Skroc wypisywanie.");
    if(fwrite(s,1,n,v->out)!=n)ti_fail(p,"Nie mozna zapisac wyniku.");v->written+=n;
}
static void argc_need(TiProgram *p,int n,int expected){if(n!=expected)ti_fail(p,"Nieprawidlowa liczba argumentow: oczekuje %d.",expected);}
static void mark_value(TiProgram *p,Value x){
    if(x.kind!=1)return;for(Mem *m=p->mem;m;m=m->next)if((const void*)(m+1)==(const void*)x.s){m->mark=1;break;}
}
static void collect(TiProgram *p,VM *v) {
    for(Mem *m=p->mem;m;m=m->next)m->mark=m->permanent;
    for(int i=0;i<TI_NAMES;i++)if(v->defined[i])mark_value(p,v->globals[i]);
    for(int i=0;i<v->sp;i++)mark_value(p,v->stack[i]);
    for(int i=1;i<=v->fp;i++)for(int j=0;j<v->frames[i].n;j++)mark_value(p,v->frames[i].locals[j].value);
    Mem **at=&p->mem;while(*at){Mem *m=*at;if(!m->mark){*at=m->next;p->bytes-=m->size;free(m);}else at=&m->next;}
}
static Value builtin(TiProgram *p,VM *v,const char *name,int n,Value *a) {
    const TiCommand *cmd=ti_command(name);
    if(cmd&&(cmd->game==2||(!strcmp(name,"klatka")&&v->app.started))){
        if(!strcmp(name,"aplikacja")&&v->game.scene.active)ti_fail(p,"Najpierw zakoncz tryb gry przez koncz.");
        char message[256];Value result;int status=ti_app_call(&v->app,name,n,a,&result,message);if(status!=1)ti_fail(p,"%s",status<0?message:"Nieznana komenda aplikacji.");
        if(!strcmp(name,"klatka")){v->steps=0;if(p->bytes>2*1024*1024)collect(p,v);}
        if(result.kind==1)result.s=ti_string(p,result.s,strlen(result.s));return result;
    }
    if(cmd&&cmd->game==3){char message[256];Value result;int status=ti_memory_call(&v->memory,name,n,a,&result,message);if(status!=1)ti_fail(p,"%s",status<0?message:"Nieznana komenda pamieci.");return result;}
    if(cmd&&cmd->game){
        if(!strcmp(name,"wywolaj")){if(v->app.scene.active)ti_fail(p,"Najpierw zamknij aplikacje.");v->app.started=0;}
        char error[256];Value result;int r=ti_game_call(&v->game,name,n,a,&result,error);
        if(r!=1)ti_fail(p,"%s",r<0?error:"Nieznana komenda gry.");
        if(!strcmp(name,"klatka")){v->steps=0;if(p->bytes>2*1024*1024)collect(p,v);}
        return result;
    }
    if(!strcmp(name,"czytaj_plik")||!strcmp(name,"zapisz_plik")){
        if(a[0].kind!=1||!a[0].s||!*a[0].s)ti_fail(p,"Podaj nazwe pliku jako tekst.");char message[256];
        if(!strcmp(name,"czytaj_plik")){char*s=NULL;if(!ti_file_read(a[0].s,&s,message))ti_fail(p,"%s",message);size_t length=strlen(s);if(p->bytes+length+1>32*1024*1024){free(s);ti_fail(p,"Przekroczono limit pamieci.");}char*copy=ti_string(p,s,length);free(s);return ti_text(copy);}
        if(a[1].kind!=1)ti_fail(p,"Do pliku zapisujesz tekst. Uzyj tekst, aby przeliczyc liczbe.");if(!ti_file_write(a[0].s,a[1].s,message))ti_fail(p,"%s",message);return ti_number(0);
    }
    if(!strcmp(name,"pisz")){
        for(int i=0;i<n;i++){if(i)write_out(p,v," ");write_out(p,v,text(p,a[i]));}write_out(p,v,"\n");fflush(v->out);return ti_number(0);
    }
    if(!strcmp(name,"pytaj")||!strcmp(name,"wczytaj")){
        if(n>1)ti_fail(p,"pytaj przyjmuje najwyzej jeden argument.");if(n)write_out(p,v,text(p,a[0]));fflush(v->out);
        char buf[8194];if(!fgets(buf,sizeof buf,v->in))ti_fail(p,"Brak odpowiedzi z konsoli (koniec wejscia).");
        size_t len=strlen(buf);if(len==sizeof buf-1&&buf[len-1]!='\n')ti_fail(p,"Odpowiedz jest za dluga (limit 8192 bajty).");
        while(len&&(buf[len-1]=='\n'||buf[len-1]=='\r'))buf[--len]=0;
        return ti_text(ti_string(p,buf,len));
    }
    if(!strcmp(name,"losuj")){
        argc_need(p,n,2);double lo=num(p,a[0]),hi=num(p,a[1]);
        if(lo!=floor(lo)||hi!=floor(hi)||hi<lo||fabs(lo)>1e9||fabs(hi)>1e9)ti_fail(p,"losuj wymaga calkowitych granic od -1000000000 do 1000000000.");
        double r=(double)rand()/((double)RAND_MAX+1);return ti_number(lo+floor(r*(hi-lo+1)));
    }
    argc_need(p,n,1);
    if(!strcmp(name,"tekst"))return ti_text(text(p,a[0]));
    if(!strcmp(name,"dlugosc")){
        if(a[0].kind!=1)ti_fail(p,"dlugosc wymaga tekstu.");
        int len=0;for(const unsigned char *s=(const unsigned char*)a[0].s;*s;s++)if((*s&0xc0)!=0x80)len++;return ti_number(len);
    }
    if(!strcmp(name,"liczba")){
        if(a[0].kind!=1)return ti_number(a[0].n);
        const char *s=a[0].s;while(isspace((unsigned char)*s))s++;
        char *end;errno=0;double d=strtod(s,&end);while(isspace((unsigned char)*end))end++;
        if(s==end||*end||errno||!isfinite(d))ti_fail(p,"Nie mozna zamienic tego tekstu na liczbe.");return ti_number(d);
    }
    double d=num(p,a[0]);
    if(!strcmp(name,"sin"))return ti_number(sin(d));
    if(!strcmp(name,"cos"))return ti_number(cos(d));
    if(!strcmp(name,"abs"))return ti_number(fabs(d));
    if(!strcmp(name,"zaokraglij"))return ti_number(round(d));
    if(d<0)ti_fail(p,"Pierwiastek wymaga liczby nieujemnej.");return ti_number(sqrt(d));
}
static void store(TiProgram *p,VM *v,int id,Value x) {
    if(!v->fp){v->globals[id]=x;v->defined[id]=1;return;}
    Frame *f=&v->frames[v->fp];
    for(int i=0;i<f->n;i++)if(f->locals[i].id==id){f->locals[i].value=x;return;}
    if(f->n==TI_LOCALS)ti_fail(p,"Przekroczono limit zmiennych lokalnych (128).");
    f->locals[f->n++]=(Local){id,x};
}
static Value load(TiProgram *p,VM *v,int id) {
    if(v->fp){Frame *f=&v->frames[v->fp];for(int i=0;i<f->n;i++)if(f->locals[i].id==id)return f->locals[i].value;}
    if(!v->defined[id])ti_fail(p,"Nieznana zmienna: %s.",p->names[id]);return v->globals[id];
}
int ti_execute_host(TiProgram *p,FILE *input,FILE *output,TiError *error,const TiHost *host) {
    if(setjmp(p->jump)){p->runtime=0;if(error)*error=p->error;return 0;}
    p->runtime=0;VM *v=ti_alloc(p,sizeof *v);p->runtime=1;v->in=input;v->out=output;ti_game_init(&v->game,host);ti_app_init(&v->app,host);ti_memory_init(&v->memory);srand((unsigned)time(NULL));
    while(v->pc<p->nc){
        Ins in=p->code[v->pc++];p->line=in.line;
        if(++v->steps>5000000)ti_fail(p,"Przekroczono limit 5000000 instrukcji. Sprawdz warunek petli.");
        switch(in.op){
        case O_CONST:push(p,v,in.value);break;
        case O_LOAD:push(p,v,load(p,v,in.a));break;
        case O_STORE:store(p,v,in.a,pop(p,v));break;
        case O_POP:pop(p,v);break;
        case O_DUP:if(!v->sp)ti_fail(p,"Pusty stos.");push(p,v,v->stack[v->sp-1]);break;
        case O_JMP:v->pc=in.a;break;
        case O_JZ:if(!truth(pop(p,v)))v->pc=in.a;break;
        case O_JNZ:if(truth(pop(p,v)))v->pc=in.a;break;
        case O_NOT:push(p,v,ti_bool(!truth(pop(p,v))));break;
        case O_NEG:{double x=num(p,pop(p,v));push(p,v,ti_number(-x));break;}
        case O_COUNT:{Value a=pop(p,v);double d=num(p,a);if(d<0||floor(d)!=d||d>1000000)ti_fail(p,"powtorz wymaga calkowitej liczby od 0 do 1000000.");push(p,v,a);break;}
        case O_FRAME:push(p,v,builtin(p,v,"klatka",0,NULL));break;
        case O_CALL:{
            if(v->sp<in.b)ti_fail(p,"Za malo wartosci na stosie.");int base=v->sp-in.b;Value *a=&v->stack[base];
            Function *f=NULL;for(int i=0;i<p->nf;i++)if(p->funcs[i].name==in.a)f=&p->funcs[i];
            if(!f&&ti_builtin(p->names[in.a])){Value r=builtin(p,v,p->names[in.a],in.b,a);v->sp=base;push(p,v,r);}
            else {
                if(!f)ti_fail(p,"Nieznana funkcja.");if(v->fp+1==TI_FRAMES)ti_fail(p,"Przekroczono limit stosu wywolan (63).");
                Frame *fr=&v->frames[++v->fp];fr->ret=v->pc;fr->base=base;fr->n=0;
                for(int i=0;i<f->argc;i++)store(p,v,f->params[i],a[i]);v->sp=base;v->pc=f->entry;
            }break;
        }
        case O_RET:{Value result=pop(p,v);if(!v->fp)ti_fail(p,"zwroc poza funkcja.");Frame *f=&v->frames[v->fp--];v->pc=f->ret;v->sp=f->base;push(p,v,result);break;}
        case O_HALT:
            if(v->game.started&&v->game.host.frame){
                char message[256]={0};TiInput state;double dt=v->game.dt;
                int r=v->game.host.frame(v->game.host.context,&v->game.scene,&state,&dt,message);
                if(r<0)ti_fail(p,"%s",message);
            }
            p->runtime=0;return 1;
        default:{
            Value b=pop(p,v),a=pop(p,v),r=ti_number(0);
            if(in.op==O_ADD&&(a.kind==1||b.kind==1)){
                const char *sa=text(p,a),*sb=text(p,b);size_t na=strlen(sa),nb=strlen(sb);
                if(na+nb>1024*1024)ti_fail(p,"Przekroczono limit dlugosci tekstu (1 MB).");
                char *s=ti_alloc(p,na+nb+1);memcpy(s,sa,na);memcpy(s+na,sb,nb);r=ti_text(s);
            }else if(in.op==O_EQ||in.op==O_NE){
                int eq=(a.kind==1||b.kind==1)?(a.kind==b.kind&&!strcmp(a.s,b.s)):a.n==b.n;r=ti_bool(in.op==O_EQ?eq:!eq);
            }else {
                double x=num(p,a),y=num(p,b),d=0;
                switch(in.op){
                case O_ADD:d=x+y;break;case O_SUB:d=x-y;break;case O_MUL:d=x*y;break;
                case O_DIV:case O_MOD:if(y==0)ti_fail(p,"Dzielenie przez zero.");d=in.op==O_DIV?x/y:fmod(x,y);break;
                case O_LT:r=ti_bool(x<y);break;case O_LE:r=ti_bool(x<=y);break;case O_GT:r=ti_bool(x>y);break;case O_GE:r=ti_bool(x>=y);break;
                default:ti_fail(p,"Nieznana instrukcja maszyny.");}
                if(in.op<=O_MOD){if(!isfinite(d))ti_fail(p,"Wynik dzialania przekracza zakres liczby.");r=ti_number(d);}
            }push(p,v,r);break;
        }}
    }p->runtime=0;return 1;
}
int ti_execute(TiProgram *p,FILE *in,FILE *out,TiError *error){return ti_execute_host(p,in,out,error,NULL);}
