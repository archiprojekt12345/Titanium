#define UNICODE
#define _UNICODE
#include "editor_win.h"
#include "assist.h"
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include <stdio.h>
#include <limits.h>

/* A plain Unicode EDIT owns the document. Assistance never formats or rewrites
   it in the background. Native EDIT offers a single undo operation. */
static HWND edit,owner,popup;
static HFONT display_font,initial_font,owned_font;
static LOGFONTW base_font;
static WNDPROC original,popup_original;
static int autocorrect,pending,pending_complete,suppress,font_points=11,base_points=11;
static DWORD changed;
static DWORD word_start,word_end;
static char choices[20][64];
static int choice_count;

static void hide(void){if(IsWindow(popup))ShowWindow(popup,SW_HIDE);choice_count=0;}
static void selection(DWORD *a,DWORD *b){SendMessageW(edit,EM_GETSEL,(WPARAM)a,(LPARAM)b);}
static int line_height(void){
 HDC dc=GetDC(edit);TEXTMETRICW tm={0};HFONT old=NULL;
 if(dc){old=SelectObject(dc,display_font);GetTextMetricsW(dc,&tm);SelectObject(dc,old);ReleaseDC(edit,dc);}
 return tm.tmHeight>0?tm.tmHeight:18;
}
static void invalidate_gutter(void){
 if(!IsWindow(edit)||!IsWindow(owner))return;
 RECT r;GetWindowRect(edit,&r);MapWindowPoints(NULL,owner,(POINT*)&r,2);
 r.right=r.left;r.left-=44;if(r.left<0)r.left=0;InvalidateRect(owner,&r,FALSE);
}
wchar_t *ti_editor_get_text(void){
 if(!IsWindow(edit))return NULL;
 int count=GetWindowTextLengthW(edit);if(count<0||count==INT_MAX)return NULL;
 wchar_t *s=calloc((size_t)count+1,sizeof *s);if(!s)return NULL;
 GetWindowTextW(edit,s,count+1);return s;
}
void ti_editor_set_text(const wchar_t *s){
 if(!IsWindow(edit))return;hide();suppress=1;pending_complete=0;
 SetWindowTextW(edit,s?s:L"");SendMessageW(edit,EM_EMPTYUNDOBUFFER,0,0);
 SendMessageW(edit,EM_SETMODIFY,FALSE,0);SendMessageW(edit,EM_SETSEL,0,0);
 pending_complete=0;invalidate_gutter();
}
/* EM_GETLINE takes a WORD buffer size; assistance is deliberately skipped for
   exceptionally long lines. Full document read/write has no such 64K limit. */
static wchar_t *current_line(DWORD *base,DWORD *caret,DWORD *length){
 DWORD a=0,b=0;selection(&a,&b);if(a!=b)return NULL;
 LRESULT line=SendMessageW(edit,EM_LINEFROMCHAR,a,0);
 LRESULT first=SendMessageW(edit,EM_LINEINDEX,line,0);
 LRESULT count=SendMessageW(edit,EM_LINELENGTH,a,0);
 if(first<0||count<0||count>65534||a<(DWORD)first||a>(DWORD)(first+count))return NULL;
 wchar_t *s=calloc((size_t)count+2,sizeof *s);if(!s)return NULL;
 *(WORD*)s=(WORD)(count+1);LRESULT copied=SendMessageW(edit,EM_GETLINE,line,(LPARAM)s);
 if(copied<0||copied>count){free(s);return NULL;}s[copied]=0;
 *base=(DWORD)first;*caret=a-(DWORD)first;*length=(DWORD)copied;return s;
}
static int identifier(wchar_t c){return iswalnum(c)||c==L'_';}
static int ascii_word(const wchar_t *s,DWORD n,char out[64]){
 if(!n||n>63)return 0;
 for(DWORD i=0;i<n;i++){if(s[i]>127)return 0;out[i]=(char)towlower(s[i]);}out[n]=0;return 1;
}
static int protected_context(const wchar_t *s,DWORD caret){
 int quote=0,escape=0;
 for(DWORD i=0;i<caret;i++){
  if(quote){if(escape)escape=0;else if(s[i]==L'\\')escape=1;else if(s[i]==L'"')quote=0;}
  else if(s[i]==L'"')quote=1;
  else if(s[i]==L'#'||(s[i]==L'/'&&s[i+1]==L'/'))return 1;
 }return quote;
}
static void complete(int forced){
 if(!IsWindow(edit)||!IsWindow(popup)||GetFocus()!=edit){hide();return;}
 if(suppress&&!forced){hide();return;}
 DWORD base,caret,length;wchar_t *s=current_line(&base,&caret,&length);
 if(!s)return hide();
 if(!caret||protected_context(s,caret)){free(s);hide();return;}
 DWORD start=caret,end=caret;while(start&&identifier(s[start-1]))start--;
 while(end<length&&identifier(s[end]))end++;
 char prefix[64];if(!ascii_word(s+start,caret-start,prefix)||(!forced&&strlen(prefix)<2)){free(s);hide();return;}
 word_start=base+start;word_end=base+end;
 SendMessageW(popup,LB_RESETCONTENT,0,0);choice_count=0;
 for(size_t i=0;i<20;i++){
  const char *candidate=ti_assist_complete(prefix,i);if(!candidate)break;
  if(!strcmp(candidate,prefix))continue;
  size_t n=strlen(candidate);if(n>=sizeof choices[0])continue;
  memcpy(choices[choice_count++],candidate,n+1);
  wchar_t wide[64];MultiByteToWideChar(CP_UTF8,0,candidate,-1,wide,64);
  SendMessageW(popup,LB_ADDSTRING,0,(LPARAM)wide);
 }
 free(s);if(!choice_count){hide();return;}
 SendMessageW(popup,LB_SETCURSEL,0,0);
 /* Standard EDIT returns packed signed coordinates, not a POINT pointer. */
 LRESULT location=SendMessageW(edit,EM_POSFROMCHAR,word_start,0);
 if(location==-1){hide();return;}
 POINT p={(short)LOWORD(location),(short)HIWORD(location)};MapWindowPoints(edit,owner,&p,1);
 RECT r;GetClientRect(owner,&r);int row=line_height()+4;
 int height=(choice_count<7?choice_count:7)*row+4,width=r.right<260?r.right:260;
 if(p.x+width>r.right)p.x=r.right-width;if(p.x<0)p.x=0;
 p.y+=line_height();if(p.y+height>r.bottom)p.y-=height+line_height();if(p.y<0)p.y=0;
 SetWindowPos(popup,HWND_TOP,p.x,p.y,width,height,SWP_NOACTIVATE|SWP_SHOWWINDOW);
}
static void accept_completion(void){
 int index=(int)SendMessageW(popup,LB_GETCURSEL,0,0);
 if(index<0||index>=choice_count){hide();return;}
 char chosen[64];strcpy(chosen,choices[index]);
 DWORD previous_start=word_start;
 DWORD a,b;selection(&a,&b);
 if(a!=b){hide();return;}
 /* Read the current line again; programmatic edits and caret moves cannot
    apply an old suggestion to a different token. */
 complete(1);if(!choice_count||word_start!=previous_start){hide();return;}
 int valid=0;for(int i=0;i<choice_count;i++)if(!strcmp(chosen,choices[i]))valid=1;
 if(!valid)strcpy(chosen,choices[0]);
 wchar_t wide[64];MultiByteToWideChar(CP_UTF8,0,chosen,-1,wide,64);
 SendMessageW(edit,EM_SETSEL,word_start,word_end);SendMessageW(edit,EM_REPLACESEL,TRUE,(LPARAM)wide);
 hide();suppress=1;pending_complete=0;
}
static void correct(void){
 if(!autocorrect)return;
 DWORD base,caret,length;wchar_t *line=current_line(&base,&caret,&length);if(!line)return;
 DWORD token=0;while(token<length&&(line[token]==L' '||line[token]==L'\t'))token++;
 DWORD end=token;while(end<length&&identifier(line[end]))end++;
 char fix[64];
 if(caret>=end&&ti_assist_correct(line,length,fix)){
  /* Custom function protection needs the source only when a correction is
     actually proposed, never on ordinary typing or timer ticks. */
  wchar_t *source=ti_editor_get_text();
  if(source&&!ti_assist_custom(source,line+token,end-token)){
   wchar_t wide[64];MultiByteToWideChar(CP_UTF8,0,fix,-1,wide,64);
   SendMessageW(edit,EM_SETSEL,base+token,base+end);SendMessageW(edit,EM_REPLACESEL,TRUE,(LPARAM)wide);
   DWORD after=base+caret+(DWORD)wcslen(wide)-(end-token);SendMessageW(edit,EM_SETSEL,after,after);
   SetWindowTextW(GetDlgItem(owner,190),L"Autokorekta polecenia (można wyłączyć w menu). Ctrl+Z cofa ostatnią operację.");
  }free(source);
 }free(line);
}
static LRESULT CALLBACK popup_proc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_MOUSEACTIVATE)return MA_NOACTIVATE;
 if(m==WM_LBUTTONDOWN){
  LRESULT item=SendMessageW(h,LB_ITEMFROMPOINT,0,l);
  if(!HIWORD(item)&&LOWORD(item)<choice_count){SendMessageW(h,LB_SETCURSEL,LOWORD(item),0);accept_completion();}
  return 0;
 }
 return CallWindowProcW(popup_original,h,m,w,l);
}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_GETDLGCODE)return CallWindowProcW(original,h,m,w,l)|DLGC_WANTTAB|DLGC_WANTCHARS;
 if(m==WM_KEYDOWN){
  if(w==VK_SPACE&&GetKeyState(VK_CONTROL)<0){complete(1);return 0;}
  if(IsWindowVisible(popup)){
   if(w==VK_UP||w==VK_DOWN){int i=(int)SendMessageW(popup,LB_GETCURSEL,0,0);i+=w==VK_UP?-1:1;if(i<0)i=choice_count-1;if(i>=choice_count)i=0;SendMessageW(popup,LB_SETCURSEL,i,0);return 0;}
   if(w==VK_ESCAPE){hide();suppress=1;return 0;}
  }
  if(w==VK_LEFT||w==VK_RIGHT||w==VK_HOME||w==VK_END||w==VK_PRIOR||w==VK_NEXT)hide();
 }
 if(m==WM_CHAR){
  if(w==L' '&&GetKeyState(VK_CONTROL)<0)return 0;
  if(w==1){hide();SendMessageW(h,EM_SETSEL,0,-1);return 0;}
  if(w==26){hide();SendMessageW(h,EM_UNDO,0,0);return 0;}
  if(w==L'\t'){
   if(IsWindowVisible(popup))accept_completion();
   else{complete(1);if(IsWindowVisible(popup))accept_completion();else SendMessageW(h,EM_REPLACESEL,TRUE,(LPARAM)L"\t");}
   return 0;
  }
  if(w==L' '||w==L'\r'){hide();if(w==L'\r')correct();suppress=1;}else suppress=0;
 }
 if(m==WM_UNICHAR){
  if(w==UNICODE_NOCHAR)return TRUE;
  if(w>0x10ffff||(w>=0xd800&&w<=0xdfff))return 0;
  if(w>=0x10000){WPARAM value=w-0x10000;CallWindowProcW(original,h,WM_CHAR,0xd800+(value>>10),l);return CallWindowProcW(original,h,WM_CHAR,0xdc00+(value&1023),l);}
  return SendMessageW(h,WM_CHAR,w,l);
 }
 if(m==WM_KILLFOCUS||m==WM_LBUTTONDOWN||m==WM_PASTE||m==WM_CUT||m==WM_UNDO||m==WM_SETTEXT)hide();
 WNDPROC native=original;LRESULT result=CallWindowProcW(native,h,m,w,l);
 if(m==WM_VSCROLL||m==WM_HSCROLL||m==WM_MOUSEWHEEL||m==WM_SIZE||m==WM_SETFONT||m==WM_KEYDOWN||m==WM_CHAR)invalidate_gutter();
 if(m==WM_NCDESTROY){edit=NULL;original=NULL;}
 return result;
}
HWND ti_editor_create(HWND parent,int id,HFONT f){
 if(IsWindow(edit))return NULL;
 owner=parent;initial_font=f;display_font=f;owned_font=NULL;autocorrect=0;pending=pending_complete=suppress=0;choice_count=0;
 memset(&base_font,0,sizeof base_font);GetObjectW(f,sizeof base_font,&base_font);
 HDC dc=GetDC(parent);int dpi=dc?GetDeviceCaps(dc,LOGPIXELSY):96;if(dc)ReleaseDC(parent,dc);if(dpi<=0)dpi=96;
 base_points=MulDiv(abs(base_font.lfHeight),72,dpi);if(base_points<8)base_points=11;font_points=base_points;
 edit=CreateWindowExW(0,L"EDIT",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_WANTRETURN,0,0,0,0,parent,(HMENU)(INT_PTR)id,GetModuleHandleW(NULL),NULL);
 if(!edit)return NULL;
 SendMessageW(edit,WM_SETFONT,(WPARAM)f,FALSE);
 /* Windows defaults to a restrictive typed-text limit. Keep offsets signed
    32-bit and permit documents well beyond the 250k regression case. */
 SendMessageW(edit,EM_SETLIMITTEXT,0x7ffffffe,0);
 SendMessageW(edit,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(7,7));
 popup=CreateWindowExW(WS_EX_CLIENTEDGE|WS_EX_NOACTIVATE,L"LISTBOX",L"",WS_CHILD|WS_BORDER|WS_VSCROLL|LBS_NOINTEGRALHEIGHT,0,0,0,0,parent,(HMENU)(INT_PTR)191,GetModuleHandleW(NULL),NULL);
 if(popup){SendMessageW(popup,WM_SETFONT,(WPARAM)f,FALSE);popup_original=(WNDPROC)SetWindowLongPtrW(popup,GWLP_WNDPROC,(LONG_PTR)popup_proc);}
 original=(WNDPROC)SetWindowLongPtrW(edit,GWLP_WNDPROC,(LONG_PTR)proc);return edit;
}
void ti_editor_changed(void){pending=1;pending_complete=1;changed=GetTickCount();}
void ti_editor_tick(void){
 if(pending&&(DWORD)(GetTickCount()-changed)>180){pending=0;invalidate_gutter();if(pending_complete&&GetFocus()==edit)complete(0);pending_complete=0;}
}
void ti_editor_autocorrect(int enabled){autocorrect=!!enabled;}
int ti_editor_autocorrect_enabled(void){return autocorrect;}
void ti_editor_complete(void){complete(1);}
void ti_editor_insert(const char *command){
 if(!IsWindow(edit)||!command)return;
 int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,command,-1,NULL,0);if(count<=0)return;
 wchar_t *wide=calloc((size_t)count+1,sizeof *wide);if(!wide)return;
 MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,command,-1,wide,count);wide[count-1]=L' ';
 hide();SetFocus(edit);SendMessageW(edit,EM_REPLACESEL,TRUE,(LPARAM)wide);free(wide);suppress=1;
}
void ti_editor_gutter(HDC dc,RECT r){
 HBRUSH brush=CreateSolidBrush(RGB(23,31,44));FillRect(dc,&r,brush);DeleteObject(brush);if(!IsWindow(edit))return;
 int saved=SaveDC(dc);IntersectClipRect(dc,r.left,r.top,r.right,r.bottom);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(98,116,140));SelectObject(dc,display_font);
 LONG first=(LONG)SendMessageW(edit,EM_GETFIRSTVISIBLELINE,0,0),count=(LONG)SendMessageW(edit,EM_GETLINECOUNT,0,0);int height=line_height();
 RECT editor_rect;GetWindowRect(edit,&editor_rect);MapWindowPoints(NULL,owner,(POINT*)&editor_rect,2);
 RECT format;SendMessageW(edit,EM_GETRECT,0,(LPARAM)&format);
 for(LONG i=first;i<count;i++){
  LONG index=(LONG)SendMessageW(edit,EM_LINEINDEX,i,0);LRESULT location=SendMessageW(edit,EM_POSFROMCHAR,index,0);
  int y=location==-1?editor_rect.top+format.top+(i-first)*height:editor_rect.top+(short)HIWORD(location);
  if(y>=r.bottom)break;if(y+height<=r.top)continue;
  wchar_t number[20];swprintf(number,20,L"%ld",i+1);RECT row={r.left,y,r.right-8,y+height};DrawTextW(dc,number,-1,&row,DT_RIGHT|DT_TOP|DT_SINGLELINE);
 }
 RestoreDC(dc,saved);
}
void ti_editor_zoom(int delta){
 if(!IsWindow(edit))return;int next=delta?font_points+delta:base_points;if(next<8)next=8;if(next>32)next=32;
 if(next==font_points)return;
 HDC dc=GetDC(edit);int dpi=dc?GetDeviceCaps(dc,LOGPIXELSY):96;if(dc)ReleaseDC(edit,dc);if(dpi<=0)dpi=96;
 LOGFONTW face=base_font;face.lfHeight=-MulDiv(next,dpi,72);face.lfWidth=0;HFONT replacement=CreateFontIndirectW(&face);if(!replacement)return;
 HFONT previous=owned_font;owned_font=replacement;display_font=replacement;font_points=next;
 SendMessageW(edit,WM_SETFONT,(WPARAM)replacement,TRUE);if(IsWindow(popup))SendMessageW(popup,WM_SETFONT,(WPARAM)replacement,TRUE);
 if(previous)DeleteObject(previous);hide();invalidate_gutter();
}
static int equal_case(const wchar_t *a,const wchar_t *b,size_t n){
 /* Windows ordinal comparison handles Unicode case without relying on the C
    runtime's initial ASCII-only locale. */
 return n<=(size_t)INT_MAX&&CompareStringOrdinal(a,(int)n,b,(int)n,TRUE)==CSTR_EQUAL;
}
static size_t find_between(const wchar_t *text,size_t length,const wchar_t *query,size_t count,size_t first,size_t last){
 if(count>length||first>length-count)return SIZE_MAX;
 if(last>length-count+1)last=length-count+1;
 for(size_t i=first;i<last;i++)if(equal_case(text+i,query,count))return i;
 return SIZE_MAX;
}
int ti_editor_find(const wchar_t *query){
 if(!IsWindow(edit)||!query||!*query)return 0;
 wchar_t *s=ti_editor_get_text();if(!s)return 0;size_t length=wcslen(s),count=wcslen(query);DWORD a,b;selection(&a,&b);
 size_t found=find_between(s,length,query,count,b,length+1);
 if(found==SIZE_MAX)found=find_between(s,length,query,count,0,b);free(s);if(found==SIZE_MAX)return 0;
 hide();SendMessageW(edit,EM_SETSEL,(WPARAM)found,(LPARAM)(found+count));SendMessageW(edit,EM_SCROLLCARET,0,0);SetFocus(edit);return 1;
}
void ti_editor_syntax(int enabled){
 /* Compatibility entry point: syntax coloring was removed with RichEdit.
    Plain source, selection, undo and visibility always remain untouched. */
 (void)enabled;
}
void ti_editor_destroy(void){
 hide();pending=pending_complete=0;
 if(IsWindow(popup)){SetWindowLongPtrW(popup,GWLP_WNDPROC,(LONG_PTR)popup_original);DestroyWindow(popup);}popup=NULL;popup_original=NULL;
 if(IsWindow(edit)){SendMessageW(edit,WM_SETFONT,(WPARAM)initial_font,FALSE);SetWindowLongPtrW(edit,GWLP_WNDPROC,(LONG_PTR)original);}
 if(owned_font)DeleteObject(owned_font);owned_font=NULL;display_font=NULL;initial_font=NULL;original=NULL;edit=NULL;owner=NULL;
}
