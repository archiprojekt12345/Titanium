#include "graphics.h"
#include <math.h>
void ti_graphics_order(const TiScene *s,unsigned order[TI_OBJECTS]){
 unsigned count=s->count<TI_OBJECTS?s->count:TI_OBJECTS;
 for(unsigned i=0;i<count;i++){unsigned j=i;while(j&&s->objects[order[j-1]].layer>s->objects[i].layer){order[j]=order[j-1];j--;}order[j]=i;}
}
void ti_graphics_position(const TiScene*s,const TiObject*o,double*x,double*y,double*scale){
 double z=o->pinned?1:s->zoom;if(z<=0)z=1;
 *x=(o->x-(o->pinned?0:s->camera_x*o->parallax))*z+(o->pinned?0:s->shake_x);
 *y=(o->y-(o->pinned?0:s->camera_y*o->parallax))*z+(o->pinned?0:s->shake_y);
 *scale=o->scale*z;
}
static double random_unit(TiScene*s){s->particle_seed=s->particle_seed*1664525u+1013904223u;return (s->particle_seed>>8)/16777216.0;}
void ti_graphics_particles(TiScene*s,double x,double y,unsigned n,uint32_t color){
 for(unsigned i=0;i<n&&s->particle_count<TI_PARTICLES;i++){
  TiParticle*p=&s->particles[s->particle_count++];double a=random_unit(s)*6.28318530718,v=40+random_unit(s)*170;
  p->x=x;p->y=y;p->vx=cos(a)*v;p->vy=sin(a)*v-40;p->total=p->life=.4+random_unit(s)*.8;p->size=2+random_unit(s)*4;p->color=color;
 }
}
static void trails_update(TiGame*g){
 TiScene*s=&g->scene;double dt=g->dt;unsigned keep=0;
 for(unsigned i=0;i<s->trail_count&&i<TI_TRAILS;i++){TiTrail p=s->trails[i];p.life-=dt;if(p.life>1e-9)s->trails[keep++]=p;}s->trail_count=keep;
 for(unsigned i=0;i<s->count&&i<TI_OBJECTS;i++){
  TiObject*o=&s->objects[i];double x=o->x+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->w/2),y=o->y+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->h/2);
  if(o->visible&&o->opacity>0&&o->trail_count>0&&dt>0){
   double tick=1.0/60,total=o->trail_count*tick,first=tick-o->trail_clock;
   /* Sample a fixed 60 Hz clock; interpolate motion and age catch-up samples.
      At most 24 samples survive any update, including a long paused frame. */
   if(first<dt-total)first+=ceil((dt-total-first)/tick)*tick;
   for(double t=first;t<=dt+1e-10;t+=tick){
    double age=fmax(0,dt-t);if(age>=total-1e-9)continue;
    if(s->trail_count>=TI_TRAILS)break;
    TiTrail*p=&s->trails[s->trail_count++];double f=fmin(1,t/dt);
    p->x=o->trail_x+(x-o->trail_x)*f;p->y=o->trail_y+(y-o->trail_y)*f;
    p->size=fmax(2,fmin(32,fmin(o->w,o->h)*.7*o->scale));p->life=total-age;p->total=total;
    p->parallax=o->parallax;p->color=o->trail_color;p->owner=o->effect_id;p->layer=o->layer;p->pinned=o->pinned;
   }
   o->trail_clock=fmod(o->trail_clock+dt,tick);if(o->trail_clock<1e-10||tick-o->trail_clock<1e-10)o->trail_clock=0;
  }else o->trail_clock=0;
  o->trail_x=x;o->trail_y=y;
 }
}
void ti_graphics_update(TiGame*g){
 TiScene*s=&g->scene;unsigned keep=0;
 if(!isfinite(g->dt)||g->dt<0)return;
 trails_update(g);
 if(s->shake_remaining>0){
  s->shake_remaining=fmax(0,s->shake_remaining-g->dt);
  double t=s->shake_duration-s->shake_remaining,fade=s->shake_duration>0?s->shake_remaining/s->shake_duration:0;
  /* Time-based oscillation avoids frame-count/random-sequence dependence. */
  s->shake_x=sin(t*83)*s->shake_power*fade;s->shake_y=sin(t*109+.7)*s->shake_power*fade;
 }else s->shake_x=s->shake_y=0;
 for(unsigned i=0;i<s->particle_count;i++){TiParticle p=s->particles[i];p.life-=g->dt;if(p.life<=0)continue;p.x+=p.vx*g->dt;p.y+=p.vy*g->dt;p.vy+=140*g->dt;s->particles[keep++]=p;}s->particle_count=keep;
}
