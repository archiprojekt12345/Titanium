#include "game.h"
#include "graphics.h"
#include "commands.h"
#include "physics.h"
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static int fail(char e[256],const char *s) {if(e)snprintf(e,256,"%s",s);return -1;}
static int eq(const char*a,const char*b) {
    if(!a||!b)return 0;
    while(*a&&*b){if(tolower((unsigned char)*a++)!=tolower((unsigned char)*b++))return 0;}return *a==*b;
}
static int textarg(const TiValue *v,size_t limit,int empty) {return v&&v->kind==1&&v->s&&(empty||*v->s)&&strlen(v->s)<limit;}
static int number(const TiValue *v,double lo,double hi) {return v&&v->kind!=1&&isfinite(v->n)&&v->n>=lo&&v->n<=hi;}
static int coord(const TiValue*v){return number(v,-1000000,1000000);}
static int sizearg(const TiValue*v){return number(v,1,4096);}
static void numeric(TiValue *r,double n){if(r){r->kind=0;r->n=n;r->s=NULL;}}
static void boolean(TiValue *r,int n){numeric(r,n!=0);if(r)r->kind=2;}
static int color(const TiValue*v,uint32_t *out) {
    static const struct {const char *name;uint32_t rgb;} colors[]={
        {"czarny",0x000000},{"bialy",0xffffff},{"czerwony",0xff0000},
        {"zielony",0x00ff00},{"niebieski",0x0000ff},{"zolty",0xffff00},
        {"zloty",0xffd700},{"pomaranczowy",0xffa500},{"fioletowy",0x800080},
        {"rozowy",0xffc0cb},{"szary",0x808080},{"granatowy",0x000080}};
    if(!v||v->kind!=1||!v->s)return 0;
    for(size_t i=0;i<sizeof colors/sizeof *colors;i++)if(eq(v->s,colors[i].name)){*out=colors[i].rgb;return 1;}
    if(v->s[0]=='#'&&strlen(v->s)==7){uint32_t n=0;for(int i=1;i<=6;i++){int c=(unsigned char)v->s[i];if(!isxdigit(c))return 0;n=n*16+(isdigit(c)?c-'0':tolower(c)-'a'+10);}*out=n;return 1;}return 0;
}
int ti_game_asset_name(const char *s) {
    if(!s||!*s||strlen(s)>=256||strstr(s,".."))return 0;
    for(const unsigned char*p=(const unsigned char*)s;*p;p++)if(*p<32||*p==127||strchr("/\\:*?\"<>|",*p))return 0;
    const char *ext=strrchr(s,'.');
    return ext&&ext!=s&&(eq(ext,".png")||eq(ext,".jpg")||eq(ext,".jpeg")||eq(ext,".bmp"));
}
void ti_game_init(TiGame *g,const TiHost *h) {
    memset(g,0,sizeof *g);if(h)g->host=*h;
    g->scene.zoom=1;g->scene.particle_seed=1234567;g->scene.width=640;g->scene.height=360;snprintf(g->scene.title,sizeof g->scene.title,"Titanium 2D");g->dt=1.0/60;
    g->scene.world_width=640;g->scene.world_height=360;
}
static TiObject *find(TiGame*g,const TiValue*v) {
    if(!textarg(v,sizeof g->scene.objects[0].name,0))return NULL;
    for(uint32_t i=0;i<g->scene.count;i++)if(!strcmp(g->scene.objects[i].name,v->s))return &g->scene.objects[i];
    return NULL;
}
static TiObject *put(TiGame*g,const char *name,int kind) {
    TiValue n={1,0,name};TiObject *o=find(g,&n);double speed=o?o->speed:0;
    /* Updating a label or sprite must preserve HUD/controller/animation state. */
    if(o&&o->kind==kind){o->visible=1;return o;}
    if(!o){if(g->scene.count>=TI_OBJECTS)return NULL;o=&g->scene.objects[g->scene.count++];}
    memset(o,0,sizeof *o);snprintf(o->name,sizeof o->name,"%s",name);o->visible=1;o->kind=kind;o->color=0xffffff;o->speed=speed;o->direction=1;o->anim_frames=1;o->scale=1;o->opacity=100;o->parallax=1;return o;
}
static int key(const char *s) {
    if(!s)return -1;
    if(s[0]&&!s[1]){int c=(unsigned char)s[0];if(c>='a'&&c<='z')return c-'a'+'A';if((c>='A'&&c<='Z')||(c>='0'&&c<='9'))return c;}
    static const char *names[]={"lewo","gora","prawo","dol","spacja","enter","escape"};
    static const int codes[]={37,38,39,40,32,13,27};
    for(size_t i=0;i<sizeof codes/sizeof *codes;i++)if(eq(s,names[i]))return codes[i];
    return -1;
}
static double clamp(double n,double lo,double hi){return n<lo?lo:(n>hi?hi:n);}
static int collision(const TiObject*a,const TiObject*b) {
    if(!a->visible||!b->visible||a->pinned||b->pinned||a->kind==TI_LABEL||b->kind==TI_LABEL)return 0;
    if(a->kind==TI_CIRCLE&&b->kind==TI_CIRCLE){double x=a->x-b->x,y=a->y-b->y,r=(a->w+b->w)/2;return x*x+y*y<=r*r;}
    if(a->kind==TI_CIRCLE||b->kind==TI_CIRCLE){const TiObject*c=a->kind==TI_CIRCLE?a:b,*r=c==a?b:a;double x=c->x-clamp(c->x,r->x,r->x+r->w),y=c->y-clamp(c->y,r->y,r->y+r->h);return x*x+y*y<=c->w*c->w/4;}
    return a->x<=b->x+b->w&&a->x+a->w>=b->x&&a->y<=b->y+b->h&&a->y+a->h>=b->y;
}
static void move(TiGame*g) {
    double dx=(g->input.keys['D']||g->input.keys[39])-(g->input.keys['A']||g->input.keys[37]);
    double dy=(g->input.keys['S']||g->input.keys[40])-(g->input.keys['W']||g->input.keys[38]);
    if(dx&&dy){dx*=0.7071067811865475244;dy*=0.7071067811865475244;}
    for(uint32_t i=0;i<g->scene.count;i++){TiObject *o=&g->scene.objects[i];
        /* Only positive-speed objects use automatic movement and scene bounds.
           steruj 0 leaves positioning entirely under program control. */
        if(o->speed<=0||!o->visible||o->pinned)continue;
        o->x+=dx*o->speed*g->dt;o->y+=dy*o->speed*g->dt;
        if(o->kind==TI_CIRCLE){double r=o->w/2;o->x=clamp(o->x,fmin(r,g->scene.width/2.0),fmax(g->scene.width-r,g->scene.width/2.0));o->y=clamp(o->y,fmin(r,g->scene.height/2.0),fmax(g->scene.height-r,g->scene.height/2.0));}
        else{o->x=clamp(o->x,0,fmax(0,g->scene.width-o->w));o->y=clamp(o->y,0,fmax(0,g->scene.height-o->h));}
    }
}
static int rectangular(const TiObject*o){return !o->pinned&&(o->kind==TI_RECT||o->kind==TI_IMAGE);}
static void body(TiObject*o,int gravity){
    if(!o->body){ti_body_reset(o);o->gravity=gravity?900:0;o->walk_speed=220;o->jump_speed=430;}
    if(!o->has_home){o->has_home=1;o->home_x=o->x;o->home_y=o->y;}
    o->body=1;o->solid=0;o->speed=0;
}
static int extended(TiGame*g,const char*n,const TiValue*a,TiValue*r,char e[256]){
    if(!strcmp(n,"swiat")){
        if(!number(a,160,100000)||!number(a+1,90,100000)||floor(a[0].n)!=a[0].n||floor(a[1].n)!=a[1].n)return fail(e,"Swiat wymaga calkowitych wymiarow 160..100000 x 90..100000");
        g->scene.world_width=a[0].n;g->scene.world_height=a[1].n;g->scene.world_custom=1;ti_camera_update(&g->scene);return 1;
    }
    if(!strcmp(n,"widok")){
        if(!coord(a)||!coord(a+1))return fail(e,"Widok wymaga wspolrzednych liczbowych");
        g->scene.camera_target[0]=0;g->scene.camera_x=a[0].n;g->scene.camera_y=a[1].n;ti_camera_update(&g->scene);return 1;
    }
    if(!strcmp(n,"zoom")){if(!number(a,.25,4))return fail(e,"Zoom musi byc liczba 0.25..4");g->scene.zoom=a[0].n;ti_camera_update(&g->scene);return 1;}
    if(!strcmp(n,"gradient")){uint32_t c,d;if(!color(a,&c)||!color(a+1,&d))return fail(e,"Gradient wymaga dwoch kolorow");g->scene.background=c;g->scene.background2=d;g->scene.gradient=1;return 1;}
    if(!strcmp(n,"czasteczki")){uint32_t c;if(!coord(a)||!coord(a+1)||!number(a+2,1,100)||floor(a[2].n)!=a[2].n||!color(a+3,&c))return fail(e,"Czasteczki: x y liczba 1..100 kolor");ti_graphics_particles(&g->scene,a[0].n,a[1].n,(unsigned)a[2].n,c);return 1;}
    if(!strcmp(n,"wstrzas")){
        if(!number(a,0,30)||!number(a+1,0,5))return fail(e,"Wstrzas: sila 0..30, sekundy 0..5");
        g->scene.shake_power=a[0].n;g->scene.shake_duration=a[1].n;
        g->scene.shake_remaining=a[0].n>0?a[1].n:0;g->scene.shake_x=g->scene.shake_y=0;return 1;
    }
    TiObject*o=find(g,a);if(!o)return fail(e,"Nie znaleziono obiektu o tej nazwie");
    if(!strcmp(n,"poswiata")){
        uint32_t c;if(!number(a+1,0,64)||!number(a+2,0,100)||!color(a+3,&c))return fail(e,"Poswiata: obiekt promien 0..64 intensywnosc 0..100 kolor");
        o->glow_radius=a[1].n;o->glow_intensity=a[2].n;o->glow_color=c;return 1;
    }
    if(!strcmp(n,"swiatlo")){
        uint32_t c;if(!number(a+1,10,1000)||!number(a+2,0,100)||!color(a+3,&c))return fail(e,"Swiatlo: obiekt promien 10..1000 sila 0..100 kolor");
        o->light_radius=a[1].n;o->light_strength=a[2].n;o->light_color=c;return 1;
    }
    if(!strcmp(n,"smuga")){
        uint32_t c;if(!number(a+1,0,24)||floor(a[1].n)!=a[1].n||!color(a+2,&c))return fail(e,"Smuga: obiekt liczba calkowita 0..24 kolor");
        if(!o->trail_count&&a[1].n>0){o->trail_clock=0;o->trail_x=o->x+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->w/2);o->trail_y=o->y+(o->kind==TI_CIRCLE||o->kind==TI_LABEL?0:o->h/2);}
        o->trail_count=(int)a[1].n;o->trail_color=c;
        if(!o->effect_id){o->effect_id=++g->scene.next_effect_id;if(!o->effect_id)o->effect_id=++g->scene.next_effect_id;}return 1;
    }
    if(!strcmp(n,"warstwa")){if(!number(a+1,-1000,1000)||floor(a[1].n)!=a[1].n)return fail(e,"Warstwa musi byc calkowita -1000..1000");o->layer=(int)a[1].n;return 1;}
    if(!strcmp(n,"obrot")){if(!number(a+1,-360000,360000))return fail(e,"Obrot wymaga liczby stopni -360000..360000");o->angle=fmod(a[1].n,360);return 1;}
    if(!strcmp(n,"przezroczystosc")){if(!number(a+1,0,100))return fail(e,"Przezroczystosc musi wynosic 0..100");o->opacity=100-a[1].n;return 1;}
    if(!strcmp(n,"skala")){if(!number(a+1,.1,10))return fail(e,"Skala musi wynosic 0.1..10");o->scale=a[1].n;return 1;}
    if(!strcmp(n,"paralaksa")){if(!number(a+1,0,2))return fail(e,"Paralaksa musi wynosic 0..2");o->parallax=a[1].n;return 1;}
    if(!strcmp(n,"lustro")){if(!number(a+1,0,1)||floor(a[1].n)!=a[1].n)return fail(e,"Lustro: 0 lub 1");o->mirror=(int)a[1].n;return 1;}
    if(!strcmp(n,"obrys")){uint32_t c;if(!number(a+1,0,32)||!color(a+2,&c))return fail(e,"Obrys: grubosc 0..32 kolor");o->outline=a[1].n;o->outline_color=c;return 1;}
    if(!strcmp(n,"kamera")){
        if(o->pinned)return fail(e,"Kamera nie moze sledzic obiektu przypietego do ekranu");
        snprintf(g->scene.camera_target,sizeof g->scene.camera_target,"%s",o->name);ti_camera_update(&g->scene);return 1;
    }
    if(!strcmp(n,"przypnij")){o->pinned=1;o->body=o->solid=o->controller=0;o->speed=o->patrol_speed=0;ti_body_reset(o);return 1;}
    if(!strcmp(n,"animuj")){
        if(o->kind!=TI_IMAGE||!number(a+1,1,64)||floor(a[1].n)!=a[1].n||!number(a+2,0,60))return fail(e,"Animuj wymaga obrazu, 1..64 rownych klatek i 0..60 klatek/s");
        if(o->anim_frames!=(int)a[1].n||o->anim_fps!=a[2].n){o->anim_frames=(int)a[1].n;o->anim_fps=a[2].n;o->anim_frame=0;o->anim_time=0;}return 1;
    }
    if(!strcmp(n,"odrodzenie")){
        if(!coord(a+1)||!coord(a+2))return fail(e,"Punkt odrodzenia wymaga poprawnych wspolrzednych");
        o->home_x=a[1].n;o->home_y=a[2].n;o->has_home=1;return 1;
    }
    if(!strcmp(n,"odrodz")){
        if(!o->has_home)return fail(e,"Najpierw ustaw odrodzenie lub wlacz fizyke obiektu");
        o->x=o->home_x;o->y=o->home_y;o->visible=1;ti_body_reset(o);return 1;
    }
    if(!strcmp(n,"na_ziemi")){boolean(r,ti_physics_grounded(&g->scene,o));return 1;}
    if(!strcmp(n,"spada")){boolean(r,o->visible&&o->body&&o->vy>0);return 1;}
    if(!rectangular(o))return fail(e,"Ta komenda wymaga prostokata lub obrazu bez przypiecia do ekranu");
    if(!strcmp(n,"sciana")||!strcmp(n,"platforma")){
        o->solid=!strcmp(n,"sciana")?1:2;o->body=o->controller=0;o->speed=o->patrol_speed=0;ti_body_reset(o);return 1;
    }
    if(!strcmp(n,"platformowka")){body(o,1);o->gravity=900;o->controller=1;o->patrol_speed=0;return 1;}
    if(!strcmp(n,"fizyka")){body(o,1);o->gravity=900;o->controller=0;o->patrol_speed=0;return 1;}
    if(!strcmp(n,"chodzenie")||!strcmp(n,"skakanie")){
        if(!o->controller||!number(a+1,0,2000))return fail(e,"Najpierw wlacz platformowka; wartosc musi byc 0..2000");
        if(!strcmp(n,"chodzenie"))o->walk_speed=a[1].n;else o->jump_speed=a[1].n;return 1;
    }
    if(!strcmp(n,"grawitacja")){
        if(!number(a+1,0,5000))return fail(e,"Grawitacja musi byc liczba 0..5000");body(o,1);o->gravity=a[1].n;return 1;
    }
    if(!strcmp(n,"predkosc")){
        if(!number(a+1,-2000,2000)||!number(a+2,-2000,2000))return fail(e,"Predkosci vx i vy musza byc liczbami -2000..2000");
        body(o,0);o->controller=0;o->patrol_speed=0;ti_body_reset(o);o->vx=a[1].n;o->vy=a[2].n;return 1;
    }
    if(!strcmp(n,"odbij")){
        if(!number(a+1,0,2000))return fail(e,"Sila odbicia musi byc liczba 0..2000");body(o,1);o->vy=-a[1].n;o->grounded=0;o->coyote=o->jump_buffer=0;return 1;
    }
    if(!strcmp(n,"patrol")){
        if(!coord(a+1)||!coord(a+2)||a[1].n>=a[2].n||!number(a+3,1,2000))return fail(e,"Patrol wymaga rosnacych granic X i predkosci 1..2000");
        body(o,1);o->gravity=900;o->controller=0;o->patrol_min=a[1].n;o->patrol_max=a[2].n;o->patrol_speed=a[3].n;o->direction=1;o->x=clamp(o->x,o->patrol_min,o->patrol_max);return 1;
    }
    return fail(e,"Komenda gry nie ma implementacji");
}
int ti_game_call(TiGame*g,const char*name,int argc,const TiValue*a,TiValue*r,char e[256]) {
    static const char *commands[]={
        "wywolaj","okno","tlo","prostokat","kolo","obraz","napis",
        "pozycja","przesun","rozmiar","kolor","ukryj","pokaz","usun",
        "steruj","dotyka","x","y","klawisz","wcisnieto","klik",
        "mysz_x","mysz_y","czas","delta","klatka","koncz"};
    int index=-1;if(e)e[0]=0;numeric(r,0);
    const TiCommand *cmd=name?ti_command(name):NULL;
    if(!cmd||!cmd->game)return 0;
    if(!g)return fail(e,"Brak stanu gry");
    if(argc<cmd->min||argc>cmd->max||(argc&&!a))return fail(e,"Nieprawidlowa liczba argumentow gry");
    for(size_t i=0;i<sizeof commands/sizeof *commands;i++)if(!strcmp(name,commands[i])){index=(int)i;break;}
    if(index==0){
        if(!textarg(a,16,0)||!eq(a->s,"2d"))return fail(e,"Uzyj wywolaj 2D");
        if(!g->host.frame)return fail(e,"Podglad 2D jest niedostepny w tym trybie; uruchom program w edytorze lub natywnym oknie");
        g->started=1;g->scene.active=1;return 1;
    }
    if(!g->started)return fail(e,"Najpierw uzyj wywolaj 2D");
    if(index<0)return extended(g,name,a,r,e);
    if(index==1){if(!textarg(a,sizeof g->scene.title,1)||!number(a+1,160,3840)||!number(a+2,90,2160)||floor(a[1].n)!=a[1].n||floor(a[2].n)!=a[2].n)return fail(e,"Okno wymaga tytulu, calkowitej szerokosci 160..3840 i wysokosci 90..2160");snprintf(g->scene.title,sizeof g->scene.title,"%s",a[0].s);g->scene.width=(uint32_t)a[1].n;g->scene.height=(uint32_t)a[2].n;if(!g->scene.world_custom){g->scene.world_width=g->scene.width;g->scene.world_height=g->scene.height;}ti_camera_update(&g->scene);return 1;}
    if(index==2){uint32_t c;if(!color(a,&c))return fail(e,"Nieznany kolor; podaj nazwe lub #RRGGBB");g->scene.background=c;g->scene.gradient=0;return 1;}
    if(index>=3&&index<=6){
        uint32_t c=0xffffff;int k=index==3?TI_RECT:index==4?TI_CIRCLE:index==5?TI_IMAGE:TI_LABEL;
        if(!textarg(a,sizeof g->scene.objects[0].name,0))return fail(e,"Nazwa obiektu musi miec od 1 do 63 bajtow");
        int xy=index>=5?2:1;
        if(!coord(a+xy)||!coord(a+xy+1))return fail(e,"Wspolrzedne musza byc liczbami od -1000000 do 1000000");
        if(index==3&&(!sizearg(a+3)||!sizearg(a+4)))return fail(e,"Rozmiar obiektu musi byc od 1 do 4096");
        if(index==4&&!number(a+3,1,2048))return fail(e,"Promien kola musi byc od 1 do 2048");
        if(index==5&&(!sizearg(a+4)||!sizearg(a+5)))return fail(e,"Rozmiar obrazu musi byc od 1 do 4096");
        if(index==6&&!textarg(a+1,sizeof g->scene.objects[0].text,1))return fail(e,"Tekst moze miec do 511 bajtow");
        if(index!=5&&!color(a+(index==3?5:4),&c))return fail(e,"Nieznany kolor; podaj nazwe lub #RRGGBB");
        if(!find(g,a)&&g->scene.count>=TI_OBJECTS)return fail(e,"Osiagnieto limit 128 obiektow");
        if(index==5){if(!textarg(a+1,sizeof g->scene.objects[0].asset,0)||!ti_game_asset_name(a[1].s))return fail(e,"Obraz wymaga nazwy pliku PNG, JPG lub BMP z folderu assety");if(!g->host.asset)return fail(e,"Obrazy sa niedostepne w tym trybie");if(!g->host.asset(g->host.context,a[1].s,e)){if(e&&!e[0])fail(e,"Nie mozna wczytac obrazu z folderu assety");return -1;}}
        TiObject *o=put(g,a[0].s,k);if(!o)return fail(e,"Osiagnieto limit 128 obiektow");o->x=a[xy].n;o->y=a[xy+1].n;o->color=c;
        if(index==3){o->w=a[3].n;o->h=a[4].n;}else if(index==4)o->w=o->h=a[3].n*2;else if(index==5){o->w=a[4].n;o->h=a[5].n;snprintf(o->asset,sizeof o->asset,"%s",a[1].s);}else{snprintf(o->text,sizeof o->text,"%s",a[1].s);o->h=20;}
        return 1;
    }
    if(index>=7&&index<=17){
        TiObject *o=find(g,a);if(!o)return fail(e,"Nie znaleziono obiektu o tej nazwie");
        if(index==7||index==8){if(!coord(a+1)||!coord(a+2))return fail(e,"Nieprawidlowe wspolrzedne obiektu");double x=a[1].n+(index==8?o->x:0),y=a[2].n+(index==8?o->y:0);if(!isfinite(x)||!isfinite(y)||fabs(x)>1000000||fabs(y)>1000000)return fail(e,"Wspolrzedne przekraczaja dozwolony zakres");o->x=x;o->y=y;if(index==7&&o->body)ti_body_reset(o);}
        else if(index==9){if(!sizearg(a+1)||!sizearg(a+2))return fail(e,"Rozmiar obiektu musi byc od 1 do 4096");if(o->kind==TI_CIRCLE&&a[1].n!=a[2].n)return fail(e,"Kolo wymaga rownej szerokosci i wysokosci");o->w=a[1].n;o->h=a[2].n;}
        else if(index==10){uint32_t c;if(!color(a+1,&c))return fail(e,"Nieznany kolor; podaj nazwe lub #RRGGBB");o->color=c;}
        else if(index==11||index==12)o->visible=index==12;
        else if(index==13){size_t pos=(size_t)(o-g->scene.objects);memmove(o,o+1,(g->scene.count-pos-1)*sizeof *o);memset(&g->scene.objects[--g->scene.count],0,sizeof *o);}
        else if(index==14){if(!number(a+1,0,2000))return fail(e,"Predkosc musi byc od 0 do 2000");o->speed=a[1].n;o->body=o->controller=o->solid=0;o->patrol_speed=0;ti_body_reset(o);}
        else if(index==15){TiObject *b=find(g,a+1);if(!b)return fail(e,"Nie znaleziono drugiego obiektu");boolean(r,collision(o,b));}
        else numeric(r,index==16?o->x:o->y);
        return 1;
    }
    if(index==18||index==19){int k=a[0].kind==1?key(a[0].s):-1;if(k<0)return fail(e,"Nieznana nazwa klawisza");boolean(r,g->input.keys[k]&&(index==18||!g->previous.keys[k]));return 1;}
    if(index==20){int b=a[0].kind==1&&eq(a[0].s,"lewy")?0:a[0].kind==1&&eq(a[0].s,"prawy")?1:-1;if(b<0)return fail(e,"Przycisk myszy musi byc lewy lub prawy");boolean(r,g->input.buttons[b]&&!g->previous.buttons[b]);return 1;}
    if(index>=21&&index<=24){numeric(r,index==21?g->input.mouse_x:index==22?g->input.mouse_y:index==23?g->elapsed:g->dt);return 1;}
    if(index==25){
        if(!g->scene.active){boolean(r,0);return 1;}
        ti_camera_update(&g->scene);TiInput input={0};double dt=g->dt;int status=g->host.frame(g->host.context,&g->scene,&input,&dt,e);
        if(status<0){if(e&&!e[0])fail(e,"Blad natywnego podgladu 2D");return -1;}
        if(!status){g->scene.active=0;boolean(r,0);return 1;}
        g->previous=g->input;g->input=input;g->dt=isfinite(dt)?clamp(dt,0,.1):0;g->elapsed+=g->dt;move(g);ti_physics_update(g);ti_graphics_update(g);boolean(r,1);return 1;
    }
    g->scene.active=0;return 1;
}
