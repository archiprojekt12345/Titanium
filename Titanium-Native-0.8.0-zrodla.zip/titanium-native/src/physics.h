#ifndef TI_PHYSICS_H
#define TI_PHYSICS_H
#include "game.h"
void ti_physics_update(TiGame *game);
void ti_camera_update(TiScene *scene);
void ti_body_reset(TiObject *object);
int ti_physics_grounded(const TiScene *scene,const TiObject *object);
#endif
