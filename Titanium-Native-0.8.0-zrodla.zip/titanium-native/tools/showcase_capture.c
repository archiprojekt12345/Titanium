/* Portable preview source capture: executes the real Titanium engine and writes
   its POD scene as JSON. This is not Windows GUI validation or a screenshot. */
#include "../src/internal.h"
#include "../src/game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static FILE *output;static unsigned frame_number,target_frame;static int captured;
static void quoted(const char*s){fputc('"',output);for(const unsigned char*p=(const unsigned char*)s;*p;p++){unsigned c=*p;if(c=='"'||c=='\\'){fputc('\\',output);fputc((int)c,output);}else if(c<32)fprintf(output,"\\u%04x",c);else fputc((int)c,output);}fputc('"',output);}
static void snapshot(const TiScene*s){
 fprintf(output,"{\"metadata\":\"Portable renderer preview from real Titanium engine state; not a native Windows screenshot or GUI validation\",\"frame\":%u,\"width\":%u,\"height\":%u,\"background\":%u,\"background2\":%u,\"gradient\":%d,\"zoom\":%.17g,\"camera_x\":%.17g,\"camera_y\":%.17g,\"shake_x\":%.17g,\"shake_y\":%.17g,\"objects\":[",frame_number,s->width,s->height,s->background,s->background2,s->gradient,s->zoom,s->camera_x,s->camera_y,s->shake_x,s->shake_y);
 for(unsigned i=0;i<s->count;i++){const TiObject*o=&s->objects[i];if(i)fputc(',',output);fputs("{\"name\":",output);quoted(o->name);
  fprintf(output,",\"kind\":%d,\"visible\":%d,\"color\":%u,\"x\":%.17g,\"y\":%.17g,\"w\":%.17g,\"h\":%.17g,\"scale\":%.17g,\"angle\":%.17g,\"opacity\":%.17g,\"parallax\":%.17g,\"outline\":%.17g,\"outline_color\":%u,\"layer\":%d,\"mirror\":%d,\"pinned\":%d,\"glow_radius\":%.17g,\"glow_intensity\":%.17g,\"glow_color\":%u,\"light_radius\":%.17g,\"light_strength\":%.17g,\"light_color\":%u,\"anim_frames\":%d,\"anim_frame\":%d,\"text\":",o->kind,o->visible,o->color,o->x,o->y,o->w,o->h,o->scale,o->angle,o->opacity,o->parallax,o->outline,o->outline_color,o->layer,o->mirror,o->pinned,o->glow_radius,o->glow_intensity,o->glow_color,o->light_radius,o->light_strength,o->light_color,o->anim_frames,o->anim_frame);
  quoted(o->text);fputs(",\"asset\":",output);quoted(o->asset);fputc('}',output);
 }
 fputs("],\"trails\":[",output);for(unsigned i=0;i<s->trail_count;i++){const TiTrail*p=&s->trails[i];if(i)fputc(',',output);fprintf(output,"{\"x\":%.17g,\"y\":%.17g,\"size\":%.17g,\"life\":%.17g,\"total\":%.17g,\"color\":%u,\"parallax\":%.17g,\"layer\":%d,\"pinned\":%d}",p->x,p->y,p->size,p->life,p->total,p->color,p->parallax,p->layer,p->pinned);}
 fputs("],\"particles\":[",output);for(unsigned i=0;i<s->particle_count;i++){const TiParticle*p=&s->particles[i];if(i)fputc(',',output);fprintf(output,"{\"x\":%.17g,\"y\":%.17g,\"size\":%.17g,\"life\":%.17g,\"total\":%.17g,\"color\":%u}",p->x,p->y,p->size,p->life,p->total,p->color);}
 fputs("]}\n",output);captured=1;
}
static int frame(void*c,const TiScene*s,TiInput*i,double*dt,char error[256]){(void)c;(void)error;memset(i,0,sizeof *i);*dt=1.0/60;if(++frame_number==target_frame){snapshot(s);return 0;}return frame_number<target_frame;}
static int asset(void*c,const char*n,char error[256]){(void)c;(void)error;return ti_game_asset_name(n);}
int main(int argc,char**argv){
 if(argc<3||argc>4){fputs("usage: showcase_capture source.ti snapshot.json [frame=600]\n",stderr);return 2;}
 target_frame=argc==4?(unsigned)strtoul(argv[3],0,10):600;if(!target_frame||target_frame>36000)return 2;
 FILE*f=fopen(argv[1],"rb");if(!f)return 2;char*source=calloc(1,250001);if(!source){fclose(f);return 2;}size_t n=fread(source,1,250000,f);fclose(f);
 TiError error;TiProgram*p=ti_compile(source,n,&error);free(source);if(!p){fprintf(stderr,"compile line %d: %s\n",error.line,error.text);return 1;}
 output=fopen(argv[2],"wb");if(!output){ti_free(p);return 2;}TiHost host={0,frame,asset,0};int ok=ti_execute_host(p,stdin,stderr,&error,&host);if(!ok)fprintf(stderr,"runtime line %d: %s\n",error.line,error.text);fclose(output);ti_free(p);return ok&&captured?0:1;
}
