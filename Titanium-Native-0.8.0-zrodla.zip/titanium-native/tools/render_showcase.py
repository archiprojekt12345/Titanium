#!/usr/bin/env python3
"""Portable Pillow preview of actual scene JSON from showcase_capture.c.

This approximates GDI+ rendering; it is NOT a native Windows screenshot or GUI
validation. Geometry, layers, gradients, glow/light parameters, trails, particles,
camera, animation frame and HUD positions come from the real engine snapshot.
Font rasterization substitutes DejaVu Sans for Windows Segoe UI.

Build capture: cc -std=c11 -O2 src/{compiler,vm,commands,game,physics,graphics,assist,app,lowlevel,files}.c tools/showcase_capture.c -lm -o /tmp/showcase_capture
Capture: /tmp/showcase_capture demos/showcase08.ti /tmp/neon-scene.json 600
Render: python tools/render_showcase.py /tmp/neon-scene.json demos/NEON-HARBOR-preview.png --assets wydanie/Przyklady/assety
"""
import argparse
import json
from pathlib import Path
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, PngImagePlugin

SS = 2
RESAMPLE = Image.Resampling.LANCZOS

def rgb(n):
    return ((int(n) >> 16) & 255, (int(n) >> 8) & 255, int(n) & 255)

def rgba(n, opacity=100):
    return (*rgb(n), round(max(0, min(100, opacity)) * 2.55))

class Preview:
    def __init__(self, scene, assets):
        self.s = scene
        self.assets = Path(assets)
        self.w, self.h = scene['width'] * SS, scene['height'] * SS
        first = np.array(rgb(scene['background']), dtype=float)
        last = np.array(rgb(scene['background2'] if scene['gradient'] else scene['background']), dtype=float)
        rows = np.linspace(first, last, self.h).astype(np.uint8)
        self.image = Image.fromarray(np.broadcast_to(rows[:, None, :], (self.h, self.w, 3)).copy()).convert('RGBA')
        self.radials = {}
        self.fonts = {}
        self.drawn_trails = set()

    def paste(self, img, x, y):
        self.image.alpha_composite(img, (round(x), round(y)))

    def point(self, x, y, pinned=False, parallax=1):
        s = self.s
        z = 1 if pinned else s['zoom']
        return ((x - (0 if pinned else s['camera_x'] * parallax)) * z + (0 if pinned else s['shake_x'])) * SS, ((y - (0 if pinned else s['camera_y'] * parallax)) * z + (0 if pinned else s['shake_y'])) * SS

    def radial(self, x, y, radius, color, opacity):
        r = max(1, round(radius))
        key = (r, color, round(opacity, 3))
        if key not in self.radials:
            yy, xx = np.ogrid[-r:r+1, -r:r+1]
            fade = np.clip(1 - np.sqrt(xx * xx + yy * yy) / r, 0, 1)
            data = np.zeros((r * 2 + 1, r * 2 + 1, 4), dtype=np.uint8)
            data[:, :, :3] = rgb(color)
            data[:, :, 3] = np.rint(fade * max(0, min(100, opacity)) * 2.55).astype(np.uint8)
            self.radials[key] = Image.fromarray(data)
        self.paste(self.radials[key], x-r, y-r)

    def ellipse(self, x, y, size, color, opacity):
        r = max(1, math.ceil(size/2)+2)
        tile = Image.new('RGBA', (r*2+1, r*2+1))
        ImageDraw.Draw(tile).ellipse((r-size/2, r-size/2, r+size/2, r+size/2), fill=rgba(color, opacity))
        self.paste(tile, x-r, y-r)

    def trails(self, pinned, layer):
        for i, p in enumerate(self.s['trails']):
            if i in self.drawn_trails or bool(p['pinned']) != pinned or p['layer'] > layer:
                continue
            self.drawn_trails.add(i)
            fade = min(1, p['life']/p['total'])
            x,y = self.point(p['x'],p['y'],pinned,p['parallax'])
            z = 1 if pinned else self.s['zoom']
            self.ellipse(x,y,p['size']*z*SS*(.25+.75*fade),p['color'],fade*55)

    def obj(self, o):
        if not o['visible'] or o['opacity'] <= 0:
            return
        z = 1 if o['pinned'] else self.s['zoom']
        scale = o['scale'] * z * SS
        x,y = self.point(o['x'],o['y'],o['pinned'],o['parallax'])
        if o['kind'] not in (2,4):
            x += o['w']*z*SS/2
            y += o['h']*z*SS/2
        if o['light_radius'] and o['light_strength']:
            self.radial(x,y,o['light_radius']*z*SS,o['light_color'],o['light_strength']*o['opacity']/100*.6)
        w,h = o['w']*scale,o['h']*scale
        if o['kind']==4:
            size = max(1,round(h))
            if size not in self.fonts:
                self.fonts[size] = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',size)
            font = self.fonts[size]
            # GDI+ DrawString adds its ordinary glyph padding inside RectF.
            tile = Image.new('RGBA',(max(1,math.ceil(font.getlength(o['text'])+size)),size*2))
            ImageDraw.Draw(tile).text((size/6,size*.13),o['text'],font=font,fill=rgba(o['color'],o['opacity']),anchor='lt')
            if o['mirror']:
                tile = tile.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            self.paste(tile,x,y)
            return
        pad = math.ceil(max(o['glow_radius'],o['outline']) * scale + 3)
        tw,th = max(1,math.ceil(w+pad*2)),max(1,math.ceil(h+pad*2))
        tile = Image.new('RGBA',(tw,th))
        for ring in range(4,0,-1):
            if o['glow_radius'] and o['glow_intensity']:
                spread = o['glow_radius']*scale*ring/4
                halo = Image.new('RGBA',tile.size)
                draw = ImageDraw.Draw(halo)
                shape = draw.ellipse if o['kind']==2 else draw.rectangle
                shape((pad-spread,pad-spread,pad+w+spread,pad+h+spread),fill=rgba(o['glow_color'],o['glow_intensity']*o['opacity']/100*.065))
                tile.alpha_composite(halo)
        if o['kind']==3:
            img = Image.open(self.assets/o['asset']).convert('RGBA')
            frames = max(1,o['anim_frames'])
            frame = o['anim_frame']%frames
            fw = img.width/frames
            img = img.crop((round(frame*fw),0,round((frame+1)*fw),img.height)).resize((max(1,round(w)),max(1,round(h))),RESAMPLE)
            if o['opacity']<100:
                img.putalpha(img.getchannel('A').point(lambda a: round(a*o['opacity']/100)))
            tile.alpha_composite(img,(pad,pad))
        else:
            draw = ImageDraw.Draw(tile)
            shape = draw.ellipse if o['kind']==2 else draw.rectangle
            outline = o['outline']*scale
            if outline:
                shape((pad-outline/2,pad-outline/2,pad+w+outline/2,pad+h+outline/2),fill=rgba(o['outline_color'],o['opacity']))
                shape((pad+outline/2,pad+outline/2,pad+w-outline/2,pad+h-outline/2),fill=rgba(o['color'],o['opacity']))
            else:
                shape((pad,pad,pad+w,pad+h),fill=rgba(o['color'],o['opacity']))
        if o['mirror']:
            tile = tile.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        if o['angle']:
            tile = tile.rotate(-o['angle'],resample=Image.Resampling.BICUBIC,expand=True)
        self.paste(tile,x-tile.width/2,y-tile.height/2)

    def render(self):
        order = sorted(self.s['objects'],key=lambda o:o['layer'])
        for pinned in (False,True):
            for o in order:
                if bool(o['pinned']) == pinned:
                    self.trails(pinned,o['layer'])
                    self.obj(o)
            self.trails(pinned,1001)
            if not pinned:
                for p in self.s['particles']:
                    x,y = self.point(p['x'],p['y'])
                    self.ellipse(x,y,p['size']*self.s['zoom']*SS,p['color'],p['life']/p['total']*100)
        return self.image.convert('RGB').resize((self.s['width'],self.s['height']),RESAMPLE)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--assets',default='wydanie/Przyklady/assety')
    args = parser.parse_args()
    scene = json.loads(args.snapshot.read_text())
    metadata = PngImagePlugin.PngInfo()
    metadata.add_text('Description',scene['metadata'])
    metadata.add_text('Source',f"Titanium real engine scene, frame {scene['frame']} at 60 Hz; Pillow 2x supersampling; DejaVu Sans substitutes Segoe UI")
    Preview(scene,args.assets).render().save(args.output,pnginfo=metadata,optimize=True)
    print(f"{args.output}: portable scene preview, {scene['width']}x{scene['height']}, {len(scene['objects'])} objects")
if __name__=='__main__':
    main()
