#include "../src/assist.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
int main(void){
 char out[64];
 assert(ti_assist_correct(L"prostkoat",9,out)&&!strcmp(out,"prostokat"));
 assert(ti_assist_correct(L"wywoalj",7,out)&&!strcmp(out,"wywolaj"));
 assert(!ti_assist_correct(L"przesun",7,out));
 assert(!ti_assist_correct(L"foo = ",6,out));
 assert(!ti_assist_correct(L"pisz \"prostkoat",15,out));
 assert(!ti_assist_correct(L"# prostkoat",11,out));
 assert(!ti_assist_correct(L"// prostkoat",12,out));
 assert(!ti_assist_correct(L"ustaw prostkoat",15,out));
 assert(!ti_assist_correct(L"moja_funkcja",12,out));
 assert(!ti_assist_correct(L"przes",5,out));
 assert(ti_assist_correct(L"  prostkoat",11,out));
 assert(ti_assist_correct(L"PROSTKOAT",9,out));
 assert(!strcmp(ti_assist_suggest("prostkoat"),"prostokat"));
 assert(ti_assist_complete("pros",0)&&!strcmp(ti_assist_complete("pros",0),"prostokat"));
 assert(!ti_assist_complete("zzzz",0));
 assert(ti_assist_correct(L"prostkoat gracz 10 20 30 40 czerwony",wcslen(L"prostkoat gracz 10 20 30 40 czerwony"),out)&&!strcmp(out,"prostokat"));
 assert(!ti_assist_correct(L"prostkoat = 10",14,out));
 assert(ti_assist_custom(L"FUNKCJA PROSTKOAT wartosc\nzwroc wartosc\nkoniec",L"prostkoat",9));
 assert(ti_assist_custom(L"funkcja\tPrzesuń\nkoniec",L"przesun",7));
 assert(!ti_assist_custom(L"# funkcja prostkoat\n",L"prostkoat",9));
 puts("assist: corrections, literals, assignment and completion passed");
}
