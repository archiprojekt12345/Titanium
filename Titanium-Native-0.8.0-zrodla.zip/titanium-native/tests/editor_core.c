#include "../src/editor_core.h"
#include <assert.h>
#include <wchar.h>
#include <stdio.h>
int main(void){
 TiEditorWork w={0};assert(ti_editor_work_needed(&w,1,0,300));assert(!ti_editor_work_needed(&w,1,0,300));assert(ti_editor_work_needed(&w,2,0,300));assert(ti_editor_work_needed(&w,2,100,400));
 TiCodeSpan spans[TI_EDITOR_SPANS];size_t n=ti_editor_spans(L"pisz \"# tekst\\\" nadal\" # uwaga\nprostokat gracz 10 20 30 40 bialy",spans,TI_EDITOR_SPANS);assert(n>4);assert(spans[0].style==TI_CODE_COMMAND);assert(spans[1].style==TI_CODE_STRING);assert(spans[2].style==TI_CODE_COMMENT);
 static wchar_t many[250001];for(int i=0;i<250000;i++)many[i]=(i%5==4)?' ':'1';n=ti_editor_spans(many,spans,TI_EDITOR_SPANS);assert(n<=TI_EDITOR_SPANS);for(size_t i=0;i<n;i++)assert(spans[i].end<=TI_EDITOR_CHARS);
 puts("editor_core: unchanged view skipped, edits/scroll invalidation and bounded syntax scan passed");
}
