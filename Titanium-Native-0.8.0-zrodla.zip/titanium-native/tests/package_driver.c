#include "../src/package.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){
    if(argc<3)return 2;
    if(!strcmp(argv[1],"console")){
        FILE *f=fopen(argv[2],"r+b");if(!f)return 2;int ok=ti_package_console(f);fclose(f);return ok?0:1;
    }
    if(!strcmp(argv[1],"unpack")){
        FILE *f=fopen(argv[2],"rb");char *src=NULL;size_t n;uint64_t base;
        int r=ti_package_read(f,&src,&n,&base);fclose(f);
        if(r==1)fwrite(src,1,n,stdout);free(src);return r==1?0:1;
    }
    if(argc<5)return 2;
    FILE *base=fopen(argv[2],"rb"),*src=fopen(argv[3],"rb"),*out=fopen(argv[4],"wb");
    char text[250001];size_t n=fread(text,1,sizeof text,src);
    int ok=ti_package_write(base,out,text,n);fclose(base);fclose(src);fclose(out);return ok?0:1;
}
