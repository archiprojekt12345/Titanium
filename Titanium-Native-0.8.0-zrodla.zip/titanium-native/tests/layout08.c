#include "../src/layout.h"
#include <assert.h>
#include <stdio.h>
static int overlap(TiRect a,TiRect b){return a.w>0&&a.h>0&&b.w>0&&b.h>0&&a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
int main(void){
 for(int w=960;w<=2560;w+=160)for(int h=620;h<=1440;h+=100)for(int flags=0;flags<8;flags++){
 TiLayout l;ti_layout(w,h,flags&1,flags&2,flags&4,&l);
 TiRect r[]={l.navigation,l.code,l.library,l.preview,l.console};
 for(int i=0;i<5;i++){assert(r[i].w>=0&&r[i].h>=0);assert(r[i].x>=0&&r[i].y>=0);assert(r[i].x+r[i].w<=w&&r[i].y+r[i].h<=h);for(int j=0;j<i;j++)assert(!overlap(r[i],r[j]));}
 assert(l.code.w>=300&&l.code.h>=150);
 }puts("layout08: 960..2560 geometry, focus/library/drawer states, no overlap passed");
}
