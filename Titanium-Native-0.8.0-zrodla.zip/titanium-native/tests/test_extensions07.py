import os,subprocess,tempfile,unittest
from pathlib import Path
COMPILER=os.environ.get('TI_TEST_EXE','/tmp/titanium07')
class Extensions07(unittest.TestCase):
 def run_code(self,code):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'kod.ti';p.write_text(code,encoding='utf8')
   return subprocess.run([COMPILER,str(p)],text=True,capture_output=True,timeout=5,cwd=d)
 def test_lowlevel_and_literals(self):
  r=self.run_code('bufor dane 4\nwpisz_bajt dane 0 0xFF\nwpisz_bajt dane 1 0b1010\npisz bajt dane 0\npisz bity_i 0xFF 0b1111\npisz bity_lewo 1 31\npisz bity_nie 0\npisz rozmiar_bufora dane\n')
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stdout.splitlines(),['255','15','2147483648','4294967295','4'])
 def test_literal_errors(self):
  for literal in ['0b2','0x','0b','0x12G','0b102']:
   with self.subTest(literal=literal):
    r=self.run_code('pisz '+literal+'\n');self.assertNotEqual(r.returncode,0)
 def test_bad_memory_access(self):
  for code in ['bufor dane 2\npisz bajt dane 2','bufor dane 2\nwpisz_bajt dane -1 1','pisz bity_lewo 1 32','pisz bity_i 0x100000000 1']:
   r=self.run_code(code+'\n');self.assertNotEqual(r.returncode,0)

 def test_utf8_files(self):
  r=self.run_code('zapisz_plik "notatka-żółć.txt" "Zażółć\\nDrugi wiersz"\npisz czytaj_plik "notatka-żółć.txt"\n')
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stdout,'Zażółć\nDrugi wiersz\n')
 def test_missing_file(self):
  r=self.run_code('pisz czytaj_plik "brak.txt"\n');self.assertNotEqual(r.returncode,0)
