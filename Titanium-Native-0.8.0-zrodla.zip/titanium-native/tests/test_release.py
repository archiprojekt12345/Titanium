import os, struct, subprocess, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text().strip()
EXE_NAME=f'Titanium-Native-{VERSION}.exe'
DRIVER=os.environ.get('TI_PACKAGE_EXE','/tmp/titanium-package-test')
COMPILER=os.environ.get('TI_TEST_EXE','/tmp/titanium-native-test')

@unittest.skipUnless((ROOT/'wydanie/Demo-Konsola.exe').exists(),'Run release.py to assemble release artifacts')
class Release(unittest.TestCase):
    def test_demo_can_be_read_by_real_c_package_reader(self):
        p=ROOT/'wydanie/Demo-Konsola.exe'
        r=subprocess.run([DRIVER,'unpack',str(p)],capture_output=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn(b'Czesc',r.stdout)
        game=subprocess.run([DRIVER,'unpack',str(ROOT/'wydanie/Demo-2D.exe')],capture_output=True)
        self.assertEqual(game.returncode,0,game.stderr);self.assertIn(b'wywolaj 2D',game.stdout)

    def test_native_pe_subsystems(self):
        for name,subsystem in [(EXE_NAME,2),('Demo-Konsola.exe',3),('Demo-Kalkulator.exe',2),('Demo-Notatnik.exe',2)]:
            b=(ROOT/'wydanie'/name).read_bytes();self.assertEqual(b[:2],b'MZ')
            pe=struct.unpack_from('<I',b,60)[0];self.assertEqual(b[pe:pe+4],b'PE\0\0')
            self.assertEqual(struct.unpack_from('<H',b,pe+4)[0],0x8664)
            self.assertEqual(struct.unpack_from('<H',b,pe+24+68)[0],subsystem)

    def test_teaching_examples(self):
        inputs=['','','Jan\n15\n','','','\n'.join(map(str,range(1,21)))+'\n']
        expected=['Czesc','Punkty: 15','Czesc, Jan!','Wygrana!','14','Brawo!']
        for p,data,want in zip(sorted((ROOT/'wydanie/Przyklady').glob('*.ti')),inputs,expected):
            with self.subTest(file=p.name):
                r=subprocess.run([COMPILER,str(p)],input=data,text=True,capture_output=True,timeout=5)
                self.assertEqual(r.returncode,0,r.stderr);self.assertIn(want,r.stdout)
        self.assertEqual(len(list((ROOT/'wydanie/Przyklady').glob('*.ti'))),15)
    def test_reference_exact_and_assets_present(self):
        r=subprocess.run([COMPILER,'--komendy'],capture_output=True)
        self.assertEqual(r.returncode,0)
        self.assertEqual(r.stdout,(ROOT/'wydanie/KOMENDY-TITANIUM.txt').read_bytes())
        self.assertTrue(r.stdout.isascii())
        self.assertIn(VERSION.encode(),r.stdout.splitlines()[0])
        self.assertFalse(any(line.startswith((b" ",b"\t")) for line in r.stdout.splitlines()))
        for p in (ROOT/"wydanie/Przyklady").glob("*.ti"):
            self.assertFalse(any(line.startswith((b" ",b"\t")) for line in p.read_bytes().splitlines()))
        for directory in ['assety','Przyklady/assety']:
            for name in ['bohater.png','moneta.png','bieg.png']:
                self.assertEqual((ROOT/'wydanie'/directory/name).read_bytes()[:8],b'\x89PNG\r\n\x1a\n')
    def test_platformer_export_contains_simplified_level(self):
        r=subprocess.run([DRIVER,'unpack',str(ROOT/'wydanie/Demo-Platformowka.exe')],capture_output=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn(b'platformowka gracz',r.stdout)
        self.assertNotIn(b'delta',r.stdout)
        self.assertIn(b'kamera gracz',r.stdout)
        self.assertIn(b'odrodz gracz',r.stdout)

if __name__=='__main__':unittest.main()
