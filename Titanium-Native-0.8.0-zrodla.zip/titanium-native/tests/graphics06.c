#include "../src/game.h"
#include "../src/graphics.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define S(x) (TiValue){1,0,x}
#define N(x) (TiValue){0,x,0}
static int frame(void*c,const TiScene*s,TiInput*i,double*d,char e[256]){(void)c;(void)s;(void)i;(void)e;*d=.1;return 1;}
static TiGame g;static TiValue r;static char err[256];
static void ok(const char*n,int c,TiValue*a){int z=ti_game_call(&g,n,c,a,&r,err);if(z!=1)fprintf(stderr,"%s: %s\n",n,err);assert(z==1);}
static void bad(const char*n,int c,TiValue*a){assert(ti_game_call(&g,n,c,a,&r,err)==-1);}
int main(void){
 TiHost h={0,frame,0,NULL};ti_game_init(&g,&h);ok("wywolaj",1,(TiValue[]){S("2D")});
 ok("prostokat",6,(TiValue[]){S("a"),N(10),N(20),N(30),N(40),S("bialy")});
 assert(g.scene.objects[0].opacity==100&&g.scene.zoom==1&&g.scene.objects[0].scale==1);
 ok("warstwa",2,(TiValue[]){S("a"),N(4)});ok("obrot",2,(TiValue[]){S("a"),N(450)});
 ok("przezroczystosc",2,(TiValue[]){S("a"),N(35)});assert(g.scene.objects[0].opacity==65);
 ok("skala",2,(TiValue[]){S("a"),N(2)});ok("paralaksa",2,(TiValue[]){S("a"),N(.5)});
 ok("obrys",3,(TiValue[]){S("a"),N(2),S("czerwony")});
 ok("prostokat",6,(TiValue[]){S("b"),N(0),N(0),N(20),N(20),S("bialy")});
 unsigned order[TI_OBJECTS];ti_graphics_order(&g.scene,order);assert(order[0]==1&&order[1]==0);
 ok("warstwa",2,(TiValue[]){S("b"),N(4)});ti_graphics_order(&g.scene,order);assert(order[0]==0&&order[1]==1);
 ok("swiat",2,(TiValue[]){N(2000),N(1000)});ok("zoom",1,(TiValue[]){N(2)});ok("widok",2,(TiValue[]){N(9999),N(9999)});
 assert(g.scene.camera_x==1680&&g.scene.camera_y==820);
 double x,y,s;ti_graphics_position(&g.scene,&g.scene.objects[0],&x,&y,&s);assert(s==4&&x==2*(10-1680*.5));
 ok("przypnij",1,(TiValue[]){S("a")});ti_graphics_position(&g.scene,&g.scene.objects[0],&x,&y,&s);assert(x==10&&y==20&&s==2);
 ok("gradient",2,(TiValue[]){S("niebieski"),S("czarny")});assert(g.scene.gradient);
 ok("czasteczki",4,(TiValue[]){N(100),N(100),N(20),S("zloty")});assert(g.scene.particle_count==20);
 for(int i=0;i<30;i++)ok("klatka",0,NULL);assert(g.scene.particle_count==0);
 for(int i=0;i<10;i++)ok("czasteczki",4,(TiValue[]){N(0),N(0),N(100),S("bialy")});assert(g.scene.particle_count==TI_PARTICLES);
 bad("zoom",1,(TiValue[]){N(0)});bad("zoom",1,(TiValue[]){N(NAN)});
 bad("skala",2,(TiValue[]){S("a"),N(-1)});bad("warstwa",2,(TiValue[]){S("a"),N(1.5)});
 bad("przezroczystosc",2,(TiValue[]){S("a"),N(101)});bad("czasteczki",4,(TiValue[]){N(0),N(0),N(1.5),S("bialy")});
 ok("okno",3,(TiValue[]){S("4K"),N(3840),N(2160)});
 puts("graphics06: transforms, layer stability, HUD, camera zoom, validation, particle expiry/capacity passed");
}
