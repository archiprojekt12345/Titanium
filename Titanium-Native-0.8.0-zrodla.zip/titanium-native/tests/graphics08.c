#include "../src/game.h"
#include "../src/graphics.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#define S(x) (TiValue){1,0,x}
#define N(x) (TiValue){0,x,0}
static TiGame g;static TiValue result;static char error[256];
static int frame(void*c,const TiScene*s,TiInput*i,double*d,char e[256]){(void)c;(void)s;(void)i;(void)e;*d=1.0/60;return 1;}
static void ok(const char*n,int c,TiValue*a){int z=ti_game_call(&g,n,c,a,&result,error);if(z!=1)fprintf(stderr,"%s: %s\n",n,error);assert(z==1);}
static void bad(const char*n,int c,TiValue*a){TiScene before=g.scene;assert(ti_game_call(&g,n,c,a,&result,error)==-1);assert(!memcmp(&before,&g.scene,sizeof before));}
static void step(TiGame*a,double dt){a->dt=dt;ti_graphics_update(a);}
int main(void){
 TiHost host={0,frame,0,0};ti_game_init(&g,&host);ok("wywolaj",1,(TiValue[]){S("2D")});
 ok("prostokat",6,(TiValue[]){S("craft"),N(20),N(40),N(30),N(10),S("bialy")});
 TiObject*o=&g.scene.objects[0];assert(!o->glow_radius&&!o->light_radius&&!o->trail_count&&!g.scene.trail_count&&!g.scene.shake_x);
 ok("poswiata",4,(TiValue[]){S("craft"),N(64),N(100),S("#12ABEF")});assert(o->glow_radius==64&&o->glow_intensity==100&&o->glow_color==0x12abef);
 ok("swiatlo",4,(TiValue[]){S("craft"),N(1000),N(100),S("niebieski")});assert(o->light_radius==1000&&o->light_strength==100);
 ok("smuga",3,(TiValue[]){S("craft"),N(24),S("#00FFFF")});
 ok("prostokat",6,(TiValue[]){S("craft"),N(20),N(40),N(30),N(10),S("bialy")});assert(o->glow_radius==64&&o->trail_count==24);
 for(int i=0;i<120;i++){o->x+=1;step(&g,1.0/60);}assert(g.scene.trail_count>0&&g.scene.trail_count<=24);
 assert(g.scene.trails[g.scene.trail_count-1].x==o->x+15);
 ok("smuga",3,(TiValue[]){S("craft"),N(0),S("bialy")});for(int i=0;i<30;i++)step(&g,1.0/60);assert(!g.scene.trail_count);
 bad("poswiata",4,(TiValue[]){S("craft"),N(65),N(50),S("bialy")});bad("poswiata",4,(TiValue[]){S("craft"),N(NAN),N(50),S("bialy")});bad("poswiata",4,(TiValue[]){S("craft"),N(1),N(INFINITY),S("bialy")});
 bad("swiatlo",4,(TiValue[]){S("craft"),N(9),N(50),S("bialy")});bad("swiatlo",4,(TiValue[]){S("craft"),N(1001),N(50),S("bialy")});bad("swiatlo",4,(TiValue[]){S("craft"),N(100),N(NAN),S("bialy")});
 bad("smuga",3,(TiValue[]){S("craft"),N(24.1),S("bialy")});bad("smuga",3,(TiValue[]){S("craft"),N(-1),S("bialy")});bad("smuga",3,(TiValue[]){S("craft"),N(NAN),S("bialy")});
 bad("poswiata",4,(TiValue[]){S("craft"),N(-.1),N(50),S("bialy")});bad("poswiata",4,(TiValue[]){S("craft"),N(10),N(-1),S("bialy")});
 bad("swiatlo",4,(TiValue[]){S("craft"),N(10),N(101),S("bialy")});bad("smuga",3,(TiValue[]){S("craft"),N(25),S("bialy")});
 bad("poswiata",4,(TiValue[]){S("craft"),N(10),N(50),S("unknown")});bad("swiatlo",4,(TiValue[]){S("missing"),N(10),N(50),S("bialy")});
 bad("wstrzas",2,(TiValue[]){N(-.1),N(1)});bad("wstrzas",2,(TiValue[]){N(1),N(-.1)});
 bad("wstrzas",2,(TiValue[]){N(31),N(1)});bad("wstrzas",2,(TiValue[]){N(10),N(5.1)});bad("wstrzas",2,(TiValue[]){N(NAN),N(1)});bad("wstrzas",2,(TiValue[]){N(1),N(INFINITY)});
 ok("wstrzas",2,(TiValue[]){N(30),N(1)});double physical_x=o->x,physical_y=o->y;
 static TiGame slow,fast;slow=g;fast=g;for(int i=0;i<10;i++)step(&slow,.05);for(int i=0;i<50;i++)step(&fast,.01);
 assert(fabs(slow.scene.shake_x-fast.scene.shake_x)<1e-8&&fabs(slow.scene.shake_y-fast.scene.shake_y)<1e-8);
 assert(fabs(slow.scene.shake_x)<=30&&fabs(slow.scene.shake_y)<=30);assert(slow.scene.objects[0].x==physical_x&&slow.scene.objects[0].y==physical_y);
 double x,y,z;ti_graphics_position(&slow.scene,&slow.scene.objects[0],&x,&y,&z);assert(fabs(x-(physical_x+slow.scene.shake_x))<1e-9);
 slow.scene.objects[0].pinned=1;ti_graphics_position(&slow.scene,&slow.scene.objects[0],&x,&y,&z);assert(x==physical_x&&y==physical_y);
 for(int i=0;i<100;i++)step(&slow,.01);assert(!slow.scene.shake_x&&!slow.scene.shake_y&&!slow.scene.shake_remaining);
 ok("wstrzas",2,(TiValue[]){N(0),N(5)});assert(!g.scene.shake_x&&!g.scene.shake_y);
 ok("wstrzas",2,(TiValue[]){N(30),N(0)});assert(!g.scene.shake_remaining);
 /* Fixed-clock trail samples agree for linear motion at 20 and 100 Hz. */
 ok("smuga",3,(TiValue[]){S("craft"),N(24),S("bialy")});slow=g;fast=g;
 for(int i=0;i<20;i++){slow.scene.objects[0].x=physical_x+(i+1)*5;step(&slow,.05);}
 for(int i=0;i<100;i++){fast.scene.objects[0].x=physical_x+i+1;step(&fast,.01);}
 assert(slow.scene.trail_count==24&&fast.scene.trail_count==24);
 for(unsigned i=0;i<24;i++){assert(fabs(slow.scene.trails[i].x-fast.scene.trails[i].x)<1e-8);assert(fabs(slow.scene.trails[i].life-fast.scene.trails[i].life)<1e-8);}
 ok("poswiata",4,(TiValue[]){S("craft"),N(0),N(0),S("bialy")});ok("swiatlo",4,(TiValue[]){S("craft"),N(10),N(0),S("bialy")});
 /* Every emitter can be active; the independent pool never grows or borrows burst slots. */
 for(int i=1;i<TI_OBJECTS;i++){g.scene.objects[i]=*o;g.scene.objects[i].effect_id=0;g.scene.objects[i].trail_count=24;g.scene.objects[i].trail_clock=0;}g.scene.count=TI_OBJECTS;o->trail_count=24;
 for(int i=0;i<60;i++)step(&g,1.0/60);assert(g.scene.trail_count<=TI_TRAILS&&g.scene.trail_count>0&&g.scene.particle_count==0);
 for(unsigned i=0;i<g.scene.count;i++)g.scene.objects[i].visible=0;for(int i=0;i<30;i++)step(&g,1.0/60);assert(!g.scene.trail_count);
 puts("graphics08: limits/NaN, pooled finite trails, data-only state, deterministic visual shake and stable HUD passed");
}
