#include "../src/text.h"
#include <assert.h>
int main(void){
    wchar_t *s=ti_crlf(L"a\nb\r\nc\rd");assert(s&&!wcscmp(s,L"a\r\nb\r\nc\r\nd"));free(s);
    s=ti_crlf(L"");assert(s&&!*s);free(s);
    s=ti_flat_code(L"\tjesli\tprawda\r\n    pisz \"  tekst\t\"\r\nkoniec");
    assert(s&&!wcscmp(s,L"jesli prawda\r\npisz \"  tekst\t\"\r\nkoniec"));free(s);return 0;
}
