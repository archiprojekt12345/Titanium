import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXE = Path(os.environ.get('TI_TEST_EXE', '/tmp/titanium-native-test'))

class Language(unittest.TestCase):
    def run_ti(self, source, data=''):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'próba.ti'
            p.write_text(source, encoding='utf-8')
            return subprocess.run([str(EXE), str(p)], input=data, text=True,
                                  capture_output=True, timeout=5)

    def good(self, source, expected, data=''):
        r = self.run_ti(source, data)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(r.stdout, expected)

    def bad(self, source, message):
        r = self.run_ti(source)
        self.assertNotEqual(r.returncode, 0, r.stdout)
        self.assertIn(message, r.stderr)
        self.assertIn('wiersz', r.stderr)

    def test_basics(self):
        self.good('pisz "Cześć, Titanium!"\npunkty = 2 + 3 * 4\npisz punkty, "pkt"',
                  'Cześć, Titanium!\n14 pkt\n')

    def test_unicode_and_bom(self):
        self.good('\ufeffżółć = "żółw"\njeśli długość(żółć) == 4\n pisz żółć\ninaczej\n pisz "błąd"\nkoniec', 'żółw\n')

    def test_loops(self):
        self.good('suma = 0\npowtórz 3\n suma = suma + 2\nkoniec\ndopóki suma < 9\n suma = suma + 1\nkoniec\ndla i od 1 do 3\n pisz i\nkoniec\npisz suma', '1\n2\n3\n9\n')

    def test_functions_and_recursion(self):
        self.good('pisz silnia(6)\nfunkcja silnia(n)\n jeśli n <= 1\n  zwróć 1\n koniec\n zwróć n * silnia(n - 1)\nkoniec', '720\n')

    def test_input(self):
        self.good('imie = pytaj("Imię? ")\nwiek = liczba(pytaj("Wiek? "))\npisz "Cześć " + imie\npisz wiek + 1',
                  'Imię? Wiek? Cześć Jan\n16\n', 'Jan\n15\n')

    def test_short_circuit(self):
        self.good('pisz falsz i 1 / 0\npisz prawda lub 1 / 0\npisz nie falsz', 'falsz\nprawda\nprawda\n')

    def test_check_does_not_run(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'x.ti'
            p.write_text('pisz pytaj("nie pytaj")', encoding='utf-8')
            r = subprocess.run([str(EXE), '--check', str(p)], text=True, capture_output=True, timeout=5)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertNotIn('nie pytaj', r.stdout)

    def test_errors(self):
        for src, msg in [('pisz 1 / 0','zero'), ('pisz brak','brak'),
                         ('jeśli prawda\npisz 1','koniec'), ('x = "a" - 2','liczb'),
                         ('powtórz -1\nkoniec','powt'), ('pisz liczba("abc")','liczb'),
                         ('funkcja f(x)\n zwróć x\nkoniec\npisz f()','argument'),
                         ('zwróć 2','funkcj'), ('pisz 1e999','liczb')]:
            with self.subTest(src=src): self.bad(src, msg)

    def test_limits(self):
        self.bad('dopóki prawda\nkoniec', 'limit')
        self.bad('funkcja f()\n zwróć f()\nkoniec\nf()', 'stos')
        self.bad('pisz ' + '(' * 300 + '1' + ')' * 300, 'zagniezd')

    def test_crlf_comments_and_escape(self):
        self.good('# nauka\r\npisz("a\\nb", 5 % 2) // komentarz\r\n', 'a\nb 1\n')

    def test_local_variables(self):
        self.good('x = 10\nfunkcja f(x)\n x = x + 1\n zwróć x\nkoniec\npisz f(3), x', '4 10\n')

if __name__ == '__main__': unittest.main()
