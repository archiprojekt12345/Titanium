#include "../src/legacy.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    const char *legacy[]={"gra \"Moja gra\"", "\xef\xbb\xbfgra \"BOM\"", "gracz = postać(1,2,3,\"red\")", "x = [1,2]", "x[0] = 2", "gracz.życie = 2", "co klatkę\n pisz(1)\nkoniec", "co 2 sekundy\n pisz(1)\nkoniec", "dla x w lista\n pisz(x)\nkoniec", "wybuch 1, 2, \"red\"", "pisz(obiekty(\"wrog\"))", "tekst(\"Hi\", 2, 3)", "kolo(2, 3, 4, \"red\")", "usuń(xs, 2)"};
    const char *native[]={"", "pisz \"gra sterowanie [1] gracz.x\"", "# gra \"a\"\npisz 1", "// postac(1,2)\npisz 1", "pisz \"escaped \\\" postac(\"", "pisz 1.25", "x = .5", "pisz \"x\"\n", "funkcja gra x\nzwroc x\nkoniec\ngra 2", "funkcja postac(x)\nzwroc x\nkoniec\npostac(2)", "gra = 2\npisz gra", "sterowanie = 1", "wywolaj 2D\nkolo moneta 2 3 4 zloty", "dodaj punkty 1", "dodaj(punkty, 1)", "usun moneta", "tekst(123)", "pisz(1)", "sin(2)", "funkcja co(x)\nzwroc x\nkoniec\nco(2)", "dla n od 1 do 3\npisz n\nkoniec", "funkcja gra()\nzwroc 2\nkoniec\npisz(gra())", "funkcja f(gra)\nzwroc gra\nkoniec"};
    for(size_t i=0;i<sizeof legacy/sizeof *legacy;i++){if(!ti_legacy_detect(legacy[i]))fprintf(stderr,"Not detected: %s\n",legacy[i]);assert(ti_legacy_detect(legacy[i]));}
    for(size_t i=0;i<sizeof native/sizeof *native;i++){if(ti_legacy_detect(native[i]))fprintf(stderr,"False legacy: %s\n",native[i]);assert(!ti_legacy_detect(native[i]));}
    char error[256],buf[8192];FILE *f=tmpfile();assert(f);
    const char *html="<!doctype html><html><body><script>original()</script></body></html>";
    const char *payload="pisz(\"</script><script>globalThis.PWNED=1</script> łódź\")\n# \xe2\x80\xa8\xe2\x80\xa9";
    assert(ti_legacy_write_html(f,html,strlen(html),payload,strlen(payload),error));rewind(f);size_t n=fread(buf,1,sizeof buf-1,f);buf[n]=0;fclose(f);
    assert(strstr(buf,"original()"));assert(strstr(buf,"atob('"));assert(!strstr(buf,"PWNED"));assert(!strstr(buf,"łódź"));assert(strstr(buf,"</script>\n</body></html>"));
    f=tmpfile();assert(f);assert(!ti_legacy_write_html(f,"bad",3,"",0,error));fclose(f);assert(error[0]);
    puts("Legacy detection and safe HTML export: OK");return 0;
}
