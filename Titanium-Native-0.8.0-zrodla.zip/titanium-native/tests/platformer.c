#include "../src/game.h"
#include "../src/commands.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#define N(x) ((TiValue){0,(x),NULL})
#define S(x) ((TiValue){1,0,(x)})
static TiValue result;
static char error[256];
static TiInput input;
static double dt;
static int frame(void *ctx,const TiScene *s,TiInput *i,double *d,char e[256]) {
    (void)ctx;(void)s;(void)e;*i=input;*d=dt;return 1;
}
static int asset(void *ctx,const char *s,char e[256]){(void)ctx;(void)s;(void)e;return 1;}
static void ok(TiGame*g,const char*n,int c,TiValue*a){
    int r=ti_game_call(g,n,c,a,&result,error);
    if(r!=1)fprintf(stderr,"MISSING/FAILED %s: %s (%d)\n",n,error,r);assert(r==1);
}
static void bad(TiGame*g,const char*n,int c,TiValue*a){assert(ti_game_call(g,n,c,a,&result,error)==-1);assert(*error);}
static void init(TiGame*g){TiHost h={NULL,frame,asset,NULL};ti_game_init(g,&h);memset(&input,0,sizeof input);dt=1.0/60;ok(g,"wywolaj",1,(TiValue[]){S("2D")});}
static void rect(TiGame*g,const char*n,double x,double y,double w,double h){ok(g,"prostokat",6,(TiValue[]){S(n),N(x),N(y),N(w),N(h),S("zielony")});}
static void tick(TiGame*g,int n){while(n--)ok(g,"klatka",0,NULL);}
static double value(TiGame*g,const char*n,const char*o){ok(g,n,1,(TiValue[]){S(o)});return result.n;}
static void position(TiGame*g,const char*n,double x,double y){ok(g,"pozycja",3,(TiValue[]){S(n),N(x),N(y)});}
static void floor_hero(TiGame*g){init(g);rect(g,"ziemia",0,300,640,60);ok(g,"sciana",1,(TiValue[]){S("ziemia")});rect(g,"gracz",40,260,20,40);ok(g,"platformowka",1,(TiValue[]){S("gracz")});tick(g,1);}
static void test_jump_landing(void){
    TiGame g;floor_hero(&g);assert(value(&g,"na_ziemi","gracz"));
    input.keys[32]=1;tick(&g,1);assert(value(&g,"y","gracz")<260);
    double low=value(&g,"y","gracz");for(int i=0;i<120;i++){tick(&g,1);double y=value(&g,"y","gracz");if(y<low)low=y;assert(y<=260.001);}
    assert(low<170);assert(value(&g,"na_ziemi","gracz"));assert(fabs(value(&g,"y","gracz")-260)<1e-8);
    /* Holding space cannot jump again on landing. */
    tick(&g,5);assert(value(&g,"y","gracz")==260);
    input.keys[32]=0;tick(&g,1);input.keys[32]=1;tick(&g,1);assert(value(&g,"y","gracz")<260);
}
static void test_swept_contacts(void){
    TiGame g;init(&g);rect(&g,"wall",150,0,1,300);ok(&g,"sciana",1,(TiValue[]){S("wall")});
    rect(&g,"hero",50,50,20,20);ok(&g,"predkosc",3,(TiValue[]){S("hero"),N(2000),N(0)});dt=.1;tick(&g,1);assert(value(&g,"x","hero")==130);
    rect(&g,"ceiling",0,20,640,1);ok(&g,"sciana",1,(TiValue[]){S("ceiling")});
    ok(&g,"predkosc",3,(TiValue[]){S("hero"),N(0),N(-2000)});tick(&g,1);assert(value(&g,"y","hero")==21);
    rect(&g,"thin_floor",0,250,640,1);ok(&g,"sciana",1,(TiValue[]){S("thin_floor")});
    ok(&g,"predkosc",3,(TiValue[]){S("hero"),N(0),N(2000)});tick(&g,2);assert(value(&g,"y","hero")==230);assert(value(&g,"na_ziemi","hero"));
}
static void test_one_way(void){
    TiGame g;init(&g);rect(&g,"platform",0,200,640,8);ok(&g,"platforma",1,(TiValue[]){S("platform")});
    rect(&g,"hero",60,240,20,30);ok(&g,"fizyka",1,(TiValue[]){S("hero")});ok(&g,"odbij",2,(TiValue[]){S("hero"),N(430)});
    double low=240;for(int i=0;i<120;i++){tick(&g,1);double y=value(&g,"y","hero");if(y<low)low=y;}
    assert(low<160);assert(fabs(value(&g,"y","hero")-170)<1e-8);assert(value(&g,"na_ziemi","hero"));
    ok(&g,"ukryj",1,(TiValue[]){S("platform")});tick(&g,5);assert(value(&g,"spada","hero"));assert(value(&g,"y","hero")>170);
}
static double travel(double fps){TiGame g;init(&g);rect(&g,"hero",0,0,10,10);ok(&g,"predkosc",3,(TiValue[]){S("hero"),N(220),N(0)});dt=1/fps;tick(&g,(int)fps);return value(&g,"x","hero");}
static void test_rates_and_controller(void){
    assert(fabs(travel(30)-220)<1e-6);assert(fabs(travel(60)-220)<1e-6);assert(fabs(travel(120)-220)<1e-6);
    TiGame g;floor_hero(&g);input.keys[38]=1;tick(&g,10);assert(value(&g,"y","gracz")==260);
    input.keys[39]=1;tick(&g,60);assert(fabs(value(&g,"x","gracz")-260)<1e-6);
    ok(&g,"chodzenie",2,(TiValue[]){S("gracz"),N(400)});tick(&g,120);assert(value(&g,"x","gracz")==620);
}
static void test_patrol_respawn(void){
    TiGame g;floor_hero(&g);rect(&g,"enemy",100,280,20,20);ok(&g,"patrol",4,(TiValue[]){S("enemy"),N(100),N(200),N(100)});
    for(int i=0;i<180;i++){tick(&g,1);assert(value(&g,"x","enemy")>=100-1e-7&&value(&g,"x","enemy")<=200+1e-7);}
    ok(&g,"odrodzenie",3,(TiValue[]){S("gracz"),N(60),N(100)});ok(&g,"odbij",2,(TiValue[]){S("gracz"),N(400)});tick(&g,1);ok(&g,"odrodz",1,(TiValue[]){S("gracz")});
    assert(value(&g,"x","gracz")==60&&value(&g,"y","gracz")==100);tick(&g,1);assert(value(&g,"spada","gracz"));
}
static void test_invalid_atomic(void){
    TiGame g;floor_hero(&g);TiScene old=g.scene;
    bad(&g,"chodzenie",2,(TiValue[]){S("gracz"),N(NAN)});bad(&g,"swiat",2,(TiValue[]){N(3000),N(0)});
    bad(&g,"patrol",4,(TiValue[]){S("gracz"),N(200),N(100),N(100)});
    bad(&g,"animuj",3,(TiValue[]){S("gracz"),N(4),N(8)});
    bad(&g,"sciana",1,(TiValue[]){S("missing")});assert(!memcmp(&old,&g.scene,sizeof old));
    ok(&g,"napis",5,(TiValue[]){S("hud"),S("test"),N(10),N(10),S("bialy")});
    bad(&g,"platformowka",1,(TiValue[]){S("hud")});bad(&g,"sciana",1,(TiValue[]){S("hud")});
}
static void test_buffered_jump(void){
    TiGame g;floor_hero(&g);position(&g,"gracz",40,258);input.keys[32]=1;tick(&g,12);
    /* Pressing shortly before landing is remembered and jumps on contact. */
    assert(value(&g,"y","gracz")<240);
    double vy=g.scene.objects[1].vy;input.keys[32]=0;tick(&g,1);input.keys[32]=1;tick(&g,1);
    assert(g.scene.objects[1].vy>vy); /* no air jump / velocity reset */
}
static void test_camera_hud_animation(void){
    TiGame g;init(&g);ok(&g,"swiat",2,(TiValue[]){N(2400),N(720)});
    rect(&g,"hero",1000,400,20,40);ok(&g,"kamera",1,(TiValue[]){S("hero")});
    assert(g.scene.camera_x==690&&g.scene.camera_y==240);assert(value(&g,"x","hero")==1000);
    ok(&g,"napis",5,(TiValue[]){S("hud"),S("0"),N(10),N(10),S("bialy")});ok(&g,"przypnij",1,(TiValue[]){S("hud")});
    ok(&g,"napis",5,(TiValue[]){S("hud"),S("1"),N(10),N(10),S("bialy")});assert(g.scene.objects[1].pinned);
    ok(&g,"usun",1,(TiValue[]){S("hero")});tick(&g,1);assert(g.scene.camera_x==690);
    rect(&g,"hero",0,0,20,20);tick(&g,1);assert(g.scene.camera_x==0&&g.scene.camera_y==0);
    ok(&g,"widok",2,(TiValue[]){N(9999),N(9999)});assert(g.scene.camera_x==1760&&g.scene.camera_y==360);
    position(&g,"hero",500,300);tick(&g,1);assert(g.scene.camera_x==1760);
    ok(&g,"obraz",6,(TiValue[]){S("image"),S("walk.png"),N(0),N(0),N(32),N(32)});
    ok(&g,"animuj",3,(TiValue[]){S("image"),N(4),N(8)});dt=.1;tick(&g,2);assert(g.scene.objects[2].anim_frame==1);
    ok(&g,"przypnij",1,(TiValue[]){S("image")});tick(&g,1);assert(g.scene.objects[2].anim_frame==2);
    ok(&g,"animuj",3,(TiValue[]){S("image"),N(4),N(0)});tick(&g,5);assert(g.scene.objects[2].anim_frame==0);
}
static void test_diagonal_sweep(void){
    TiGame g;init(&g);rect(&g,"wall",100,95,1,100);ok(&g,"sciana",1,(TiValue[]){S("wall")});
    rect(&g,"hero",90,90,1,1);ok(&g,"predkosc",3,(TiValue[]){S("hero"),N(2000),N(2000)});dt=1.0/120;tick(&g,1);
    assert(value(&g,"x","hero")<=99+1e-6);assert(value(&g,"y","hero")>100);
}
static void test_live_support_and_mode_change(void){
    TiGame g;floor_hero(&g);ok(&g,"ukryj",1,(TiValue[]){S("ziemia")});assert(!value(&g,"na_ziemi","gracz"));
    ok(&g,"pokaz",1,(TiValue[]){S("ziemia")});assert(value(&g,"na_ziemi","gracz"));
    position(&g,"ziemia",0,310);assert(!value(&g,"na_ziemi","gracz"));
    position(&g,"gracz",60,100);ok(&g,"predkosc",3,(TiValue[]){S("gracz"),N(0),N(0)});
    ok(&g,"fizyka",1,(TiValue[]){S("gracz")});tick(&g,1);assert(value(&g,"spada","gracz"));
    ok(&g,"grawitacja",2,(TiValue[]){S("gracz"),N(0)});ok(&g,"predkosc",3,(TiValue[]){S("gracz"),N(0),N(0)});
    ok(&g,"platformowka",1,(TiValue[]){S("gracz")});tick(&g,1);assert(value(&g,"spada","gracz"));
}
static void test_floor_seams(void){
    TiGame g;init(&g);rect(&g,"left",0,300,100,60);ok(&g,"sciana",1,(TiValue[]){S("left")});
    rect(&g,"right",100,300,540,60);ok(&g,"sciana",1,(TiValue[]){S("right")});
    rect(&g,"hero",80,260,20,40);ok(&g,"platformowka",1,(TiValue[]){S("hero")});input.keys[39]=1;tick(&g,30);
    assert(fabs(value(&g,"x","hero")-190)<1e-6);assert(value(&g,"y","hero")==260);
}
int main(void){test_jump_landing();test_swept_contacts();test_one_way();test_rates_and_controller();test_patrol_respawn();test_invalid_atomic();test_buffered_jump();test_camera_hud_animation();test_diagonal_sweep();test_live_support_and_mode_change();test_floor_seams();puts("platformer: physics, input, collisions, frame rates, camera, HUD and animation passed");}
