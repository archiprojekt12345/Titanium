import test_language as base
import unittest
class Simple04(unittest.TestCase):
    run_ti=base.Language.run_ti
    good=base.Language.good
    def test_space_arguments_and_prefix_expressions(self):
        self.good('pisz "A" 12\nx = liczba pytaj "Wiek? "\npisz x + 1\npisz losuj 4 4',
                  'A 12\nWiek? 16\n4\n','15\n')
    def test_single_equals_words_and_updates(self):
        self.good('ustaw punkty 1\ndodaj punkty 4\nodejmij punkty 2\njesli punkty = 3 i punkty conajmniej 2\n pisz "ok"\nkoniec\npisz punkty rozne 1\npisz punkty najwyzej 3', 'ok\nprawda\nprawda\n')
    def test_function_without_punctuation(self):
        self.good('pisz razy 3 4\nfunkcja razy a b\n zwroc a * b\nkoniec\nrazy 2 3', '12\n')
    def test_negative_space_arguments(self):
        self.good('pisz 1 -2 3\npisz 5 - 2\npisz abs -4', '1 -2 3\n3\n4\n')
    def test_not_comparison_and_optional_prompt(self):
        self.good('pisz nie 2 = 3\nimie = pytaj\npisz imie','prawda\nJan\n','Jan\n')
    def test_variables_can_share_builtin_names(self):
        self.good('x = 10\ny = 20\npisz x y\nliczba = 3\npisz liczba + 1\nfunkcja f(tekst)\n zwroc tekst + 2\nkoniec\npisz f(4)', '10 20\n4\n6\n')
    def test_i_counter_after_text(self):
        self.good('dla i od 1 do 3\n pisz "Licznik:" i\nkoniec', 'Licznik: 1\nLicznik: 2\nLicznik: 3\n')
    def test_group_first_argument(self):
        self.good('pisz (1) 2\npisz (1 + 2) 4\npisz(5, 6)', '1 2\n3 4\n5 6\n')
    def test_help_generated_from_registry(self):
        import subprocess
        from test_language import EXE
        r=subprocess.run([str(EXE),'--komendy'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        for name in ['wywolaj','prostokat','dotyka','steruj','napis','obraz','zawsze','rozne']:
            self.assertIn(name,r.stdout)
        self.assertTrue(r.stdout.isascii())
