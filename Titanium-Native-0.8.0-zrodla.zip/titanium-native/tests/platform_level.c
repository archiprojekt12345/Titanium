#include "../src/game.h"
#include "../src/titanium.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int n,stage,jump,jumped[9],lose;double fps;} Test;
static const TiObject *object(const TiScene*s,const char*n){for(unsigned i=0;i<s->count;i++)if(!strcmp(s->objects[i].name,n))return &s->objects[i];return NULL;}
static int frame(void*ctx,const TiScene*s,TiInput*in,double*dt,char e[256]){
 (void)e;Test*t=ctx;memset(in,0,sizeof *in);*dt=1/t->fps;if(!s->active)return 1;
 const TiObject*p=object(s,"gracz"),*c1=object(s,"moneta1"),*c2=object(s,"moneta2"),*c3=object(s,"moneta3");
 if(!p)return 1;
 if(t->n++>4000){fprintf(stderr,"Timeout stage%d x%g y%g\n",t->stage,p->x,p->y);return 0;}
 if(t->lose){in->keys[39]=1;return 1;}
 int right=1,jump=0,original_stage=t->stage;
 switch(t->stage){
 case 0:if(p->x>=180&&p->grounded)jump=1;if(!c1->visible)t->stage=1;break;
 case 1:if(p->x>=345&&p->grounded)jump=1;if(!c2->visible)t->stage=2;break;
 case 2:if(p->x>=690){right=0;if(p->grounded)t->stage=3;}break;
 case 3:if(p->x>=710&&p->grounded){jump=1;t->stage=4;}break;
 case 4:if(p->x>=1000&&p->grounded)jump=1;if(!c3->visible)t->stage=5;break;
 case 5:if(p->x>=1198&&p->grounded){jump=1;t->stage=6;}break;
 case 6:if(p->x>=1580){right=0;if(p->grounded)t->stage=7;}break;
 case 7:if(p->x>=1650&&p->grounded){jump=1;t->stage=8;}break;
 default:break;
 }
 if(jump&&t->jumped[original_stage])jump=0;else if(jump)t->jumped[original_stage]=1;
 in->keys[39]=right;in->keys[32]=jump&&!t->jump;t->jump=in->keys[32];
 return 1;
}
static int asset(void*c,const char*n,char*e){(void)c;(void)e;return !strcmp(n,"bieg.png");}
int main(int argc,char**argv){assert(argc==2);FILE*f=fopen(argv[1],"rb");assert(f);char code[20000];size_t n=fread(code,1,sizeof code,f);fclose(f);
 for(int k=0;k<4;k++){
 TiError e;TiProgram*p=ti_compile(code,n,&e);if(!p){fprintf(stderr,"compile%d %s\n",e.line,e.text);return 1;}
 Test t={.fps=k==0?30:k==2?120:60,.lose=k==3};TiHost h={&t,frame,0,NULL};FILE*out=tmpfile();
 /* Asset validation in this host validates the logical scene only. */
 h.asset=asset;
 int ok=ti_execute_host(p,stdin,out,&e,&h);if(!ok){fprintf(stderr,"runtime%d %s\n",e.line,e.text);return 1;}
 rewind(out);char result[4000]={0};size_t got=fread(result,1,sizeof result-1,out);result[got]=0;fclose(out);ti_free(p);
 if(!strstr(result,t.lose?"Koniec gry.":"Brawo!")){fprintf(stderr,"FAIL %gfps stage%d after%d: %s\n",t.fps,t.stage,t.n,result);return 1;}
 printf("platform_level: %s at %g FPS in %d frames\n",t.lose?"loss verified":"won",t.fps,t.n);
 }
}
