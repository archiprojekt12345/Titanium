import subprocess, tempfile, unittest, struct, os
from pathlib import Path
DRIVER = os.environ.get('TI_PACKAGE_EXE', '/tmp/titanium-package-test')
class Package(unittest.TestCase):
    def test_console_subsystem(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'sample.exe';data=bytearray(512);data[:2]=b'MZ'
            struct.pack_into('<I',data,60,128);data[128:132]=b'PE\0\0'
            struct.pack_into('<H',data,152,0x20b);struct.pack_into('<H',data,220,2)
            p.write_bytes(data)
            r=subprocess.run([DRIVER,'console',str(p)],capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertEqual(struct.unpack_from('<H',p.read_bytes(),220)[0],3)
            p.write_bytes(b'broken')
            self.assertNotEqual(subprocess.run([DRIVER,'console',str(p)]).returncode,0)

    def test_roundtrip_repack_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);base=d/'base';src=d/'x.ti';out=d/'x.exe';out2=d/'y.exe'
            base.write_bytes(b'MZ'+b'base'*100);src.write_text('pisz "żółw"',encoding='utf8')
            def run(*a):return subprocess.run([DRIVER,*map(str,a)],capture_output=True)
            self.assertEqual(run('pack',base,src,out).returncode,0)
            self.assertEqual(run('unpack',out).stdout,src.read_bytes())
            self.assertEqual(run('pack',out,src,out2).returncode,0)
            self.assertEqual(out.read_bytes(),out2.read_bytes())
            damaged=bytearray(out.read_bytes());damaged[-33]^=1;out.write_bytes(damaged)
            self.assertNotEqual(run('unpack',out).returncode,0)
            out.write_bytes(out2.read_bytes()[:-1])
            self.assertNotEqual(run('unpack',out).returncode,0)
if __name__=='__main__':unittest.main()
