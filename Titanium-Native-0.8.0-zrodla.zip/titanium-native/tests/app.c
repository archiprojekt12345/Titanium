#include "../src/app.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../src/app_win.h"
#endif
#define S(x) (TiValue){1,0,x}
#define N(x) (TiValue){0,x,0}
static TiApp app;static TiValue result;static char error[256];
static struct {int status,calls;const char *click,*edit;} fake;
static int frame(void *p,TiAppScene *s,TiAppInput *i,char e[256]){
 (void)p;fake.calls++;if(fake.click)snprintf(i->click,sizeof i->click,"%s",fake.click);
 if(fake.edit&&s->count)snprintf(s->controls[0].text,sizeof s->controls[0].text,"%s",fake.edit);
 if(fake.status<0)snprintf(e,256,"test host error");return fake.status;
}
static void ok(const char *n,int c,TiValue *a){int status=ti_app_call(&app,n,c,a,&result,error);if(status!=1)fprintf(stderr,"%s: %s (%d)\n",n,error,status);assert(status==1);}
static void bad(const char *n,int c,TiValue *a){assert(ti_app_call(&app,n,c,a,&result,error)==-1);assert(*error);}
static void open_app(void){ok("aplikacja",3,(TiValue[]){S("Żółta aplikacja"),N(640),N(480)});}
static void control(const char *cmd,const char *name,const char *text){ok(cmd,6,(TiValue[]){S(name),S(text),N(10),N(20),N(120),N(30)});}
#ifdef _WIN32
static void native_test(void){
 TiAppScene scene={0};TiAppInput input;char err[256]={0};
 scene.active=1;scene.width=640;scene.height=480;strcpy(scene.title,"Titanium app native test");scene.count=3;
 for(unsigned i=0;i<scene.count;i++){TiControl *c=&scene.controls[i];snprintf(c->name,sizeof c->name,"c%u",i);c->kind=i==0?TI_APP_EDIT:i==1?TI_APP_BUTTON:TI_APP_CHECK;c->x=10;c->y=10+(int)i*40;c->w=150;c->h=30;c->visible=c->enabled=1;strcpy(c->text,"Start");}
 TiAppView *view=ti_app_view_create();assert(view);assert(ti_app_view_frame(view,&scene,&input,err)==1);
 HWND window=FindWindowW(NULL,L"Titanium app native test");assert(window);
 HWND edit=GetDlgItem(window,100),button=GetDlgItem(window,101),check=GetDlgItem(window,102);assert(edit&&button&&check);
 SetWindowTextW(edit,L"Zażółć");SendMessageW(edit,EM_SETSEL,2,2);
 for(int i=0;i<130;i++)PostMessageW(window,WM_COMMAND,MAKEWPARAM(i%2?102:101,BN_CLICKED),(LPARAM)(i%2?check:button));
 assert(ti_app_view_frame(view,&scene,&input,err)==1);assert(!strcmp(scene.controls[0].text,"Zażółć"));assert(!strcmp(input.click,"c1"));
 DWORD start,end;SendMessageW(edit,EM_GETSEL,(WPARAM)&start,(LPARAM)&end);assert(start==2&&end==2);
 for(int i=1;i<130;i++){assert(ti_app_view_frame(view,&scene,&input,err)==1);assert(!strcmp(input.click,i%2?"c2":"c1"));}
 assert(ti_app_view_frame(view,&scene,&input,err)==1&&!input.click[0]);
 strcpy(scene.controls[0].text,"Program");scene.controls[1].enabled=0;scene.controls[2].visible=0;
 assert(ti_app_view_frame(view,&scene,&input,err)==1);wchar_t value[64];GetWindowTextW(edit,value,64);assert(!wcscmp(value,L"Program"));assert(!IsWindowEnabled(button)&&!IsWindowVisible(check));
 PostMessageW(window,WM_CLOSE,0,0);assert(ti_app_view_frame(view,&scene,&input,err)==0);assert(!scene.active);
 scene.active=1;assert(ti_app_view_frame(view,&scene,&input,err)==1);scene.active=0;assert(ti_app_view_frame(view,&scene,&input,err)==0);
 ti_app_view_destroy(view);
 puts("app native: Unicode edits, caret, 130 queued clicks, states, close/reopen passed");
}
#endif
int main(void){
 TiHost host={0};host.app=frame;fake.status=1;
 ti_app_init(&app,NULL);bad("aplikacja",3,(TiValue[]){S("test"),N(640),N(480)});
 ti_app_init(&app,&host);assert(!app.scene.active&&!app.started);
 assert(ti_app_call(&app,"nieznana",0,NULL,&result,error)==0);
 bad("pole",6,(TiValue[]){S("x"),S(""),N(0),N(0),N(10),N(10)});
 bad("aplikacja",2,(TiValue[]){S("test"),N(640)});
 bad("aplikacja",3,(TiValue[]){S("test"),N(239),N(480)});
 bad("aplikacja",3,(TiValue[]){S("test"),N(640),N(160.5)});
 open_app();assert(app.scene.active&&app.started&&app.scene.width==640);
 control("pole","tekst","Cześć");control("przycisk","start","Start");control("notatnik","dziennik","A\nB");
 control("etykieta","opis","Opis");control("wybor","zgoda","Zgoda");assert(app.scene.count==5);
 assert(app.scene.controls[0].enabled&&app.scene.controls[0].visible);
 ok("wartosc",1,(TiValue[]){S("tekst")});assert(result.kind==1&&!strcmp(result.s,"Cześć"));
 ok("ustaw_tekst",2,(TiValue[]){S("tekst"),S("Nowy")});assert(!strcmp(app.scene.controls[0].text,"Nowy"));
 ok("ustaw_wybor",2,(TiValue[]){S("zgoda"),N(1)});ok("zaznaczone",1,(TiValue[]){S("zgoda")});assert(result.kind==2&&result.n==1);
 ok("wlacz",2,(TiValue[]){S("zgoda"),N(0)});ok("widoczny",2,(TiValue[]){S("zgoda"),N(0)});
 control("wybor","zgoda","Nowa zgoda");assert(app.scene.count==5&&app.scene.controls[4].checked&&!app.scene.controls[4].enabled&&!app.scene.controls[4].visible);
 bad("pole",6,(TiValue[]){S("zgoda"),S(""),N(0),N(0),N(20),N(20)});
 fake.click="start";fake.edit="Tekst użytkownika";ok("klatka",0,NULL);assert(result.kind==2&&result.n==1);
 ok("wartosc",1,(TiValue[]){S("tekst")});assert(!strcmp(result.s,"Tekst użytkownika"));
 ok("kliknieto",1,(TiValue[]){S("start")});assert(result.n==1);ok("kliknieto",1,(TiValue[]){S("start")});assert(result.n==1);
 fake.click=NULL;fake.edit=NULL;ok("klatka",0,NULL);ok("kliknieto",1,(TiValue[]){S("start")});assert(!result.n);
 bad("ustaw_wybor",2,(TiValue[]){S("tekst"),N(1)});bad("zaznaczone",1,(TiValue[]){S("tekst")});
 bad("wlacz",2,(TiValue[]){S("zgoda"),N(.5)});bad("widoczny",2,(TiValue[]){S("zgoda"),S("tak")});
 bad("wartosc",1,(TiValue[]){S("brak")});bad("przycisk",6,(TiValue[]){S(""),S(""),N(0),N(0),N(1),N(1)});
 bad("przycisk",6,(TiValue[]){S("poza"),S(""),N(630),N(0),N(20),N(20)});
 bad("przycisk",6,(TiValue[]){S("poza"),S(""),N(-1),N(0),N(20),N(20)});
 bad("przycisk",6,(TiValue[]){S("poza"),S(""),N(0),N(0),N(NAN),N(20)});
 bad("ustaw_tekst",2,(TiValue[]){S("tekst"),S("\xc0\xaf")});
 char text[4097];memset(text,'a',sizeof text-1);text[4096]=0;
 bad("ustaw_tekst",2,(TiValue[]){S("tekst"),S(text)});text[4095]=0;ok("ustaw_tekst",2,(TiValue[]){S("tekst"),S(text)});
 char longname[65];memset(longname,'x',64);longname[64]=0;bad("wartosc",1,(TiValue[]){S(longname)});
 for(int k=5;k<TI_APP_CONTROLS;k++){char name[64];snprintf(name,sizeof name,"b%d",k);control("przycisk",name,"B");}
 assert(app.scene.count==TI_APP_CONTROLS);bad("pole",6,(TiValue[]){S("overflow"),S(""),N(0),N(0),N(10),N(10)});
 fake.status=-1;bad("klatka",0,NULL);assert(!strcmp(error,"test host error")&&!app.input.click[0]);
 fake.status=0;ok("klatka",0,NULL);assert(!result.n&&!app.scene.active);int calls=fake.calls;
 ok("klatka",0,NULL);assert(!result.n&&calls==fake.calls);
 fake.status=1;open_app();assert(app.scene.count==0);control("pole","new","New");
 ok("zamknij_aplikacje",0,NULL);assert(!app.scene.active);ok("klatka",0,NULL);assert(!result.n);

#ifdef _WIN32
 native_test();
#endif
 puts("app: lifecycle, controls, user state, event frames, limits and UTF-8 passed");return 0;
}
