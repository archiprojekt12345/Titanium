#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "../src/editor_win.h"
static HWND e;static int changes;
static LRESULT CALLBACK parent(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_COMMAND&&HIWORD(w)==EN_CHANGE){changes++;ti_editor_changed();return 0;}
 return DefWindowProcW(h,m,w,l);
}
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void type(const wchar_t*s){while(*s)SendMessageW(e,WM_CHAR,*s++,1);}
static void reset(const wchar_t*s){ti_editor_set_text(s);SendMessageW(e,EM_SETSEL,(WPARAM)-1,(LPARAM)-1);}
static int equals(const wchar_t*s){wchar_t*t=ti_editor_get_text();int same=t&&!wcscmp(t,s);free(t);return same;}
static int contains(const wchar_t*s){wchar_t*t=ti_editor_get_text();int found=t&&wcsstr(t,s)!=NULL;free(t);return found;}
static void selection(DWORD*a,DWORD*b){SendMessageW(e,EM_GETSEL,(WPARAM)a,(LPARAM)b);}
static int paste(const wchar_t*s){
 if(!OpenClipboard(e))return 0;EmptyClipboard();size_t bytes=(wcslen(s)+1)*sizeof(wchar_t);HGLOBAL mem=GlobalAlloc(GMEM_MOVEABLE,bytes);
 if(!mem){CloseClipboard();return 0;}void*p=GlobalLock(mem);if(!p){GlobalFree(mem);CloseClipboard();return 0;}
 memcpy(p,s,bytes);GlobalUnlock(mem);if(!SetClipboardData(CF_UNICODETEXT,mem)){GlobalFree(mem);CloseClipboard();return 0;}
 CloseClipboard();SendMessageW(e,WM_PASTE,0,0);return 1;
}
int main(void){
 WNDCLASSW wc={0};wc.lpfnWndProc=parent;wc.hInstance=GetModuleHandleW(0);wc.lpszClassName=L"TiEditorTest";CHECK(RegisterClassW(&wc));
 HWND p=CreateWindowW(wc.lpszClassName,L"Editor test",WS_OVERLAPPEDWINDOW|WS_VISIBLE,0,0,900,700,0,0,wc.hInstance,0);CHECK(p);
 HFONT f=CreateFontW(-18,0,0,0,400,0,0,0,DEFAULT_CHARSET,0,0,0,0,L"Consolas");CHECK(f);
 e=ti_editor_create(p,101,f);CHECK(e);MoveWindow(e,44,0,800,600,TRUE);SetFocus(e);
 wchar_t class_name[32];GetClassNameW(e,class_name,32);CHECK(!lstrcmpiW(class_name,L"EDIT"));CHECK(!ti_editor_autocorrect_enabled());
 const wchar_t*unicode=L"pisz \"Zażółć gęślą jaźń 東京 \xD83D\xDE80\"\r\npisz 2 + 3";
 reset(unicode);CHECK(equals(unicode));CHECK(!SendMessageW(e,EM_CANUNDO,0,0));
 reset(L"wiersz 1\nwiersz 2");CHECK(equals(L"wiersz 1\nwiersz 2"));
 ti_editor_set_text(NULL);CHECK(equals(L""));
 reset(L"");type(L"Zażółć 東京 \xD83D\xDE80");CHECK(equals(L"Zażółć 東京 \xD83D\xDE80"));
 reset(L"prostkoat gracz");type(L"\r");CHECK(contains(L"prostkoat gracz"));
 reset(L"pierwszy\r\ndrugi");SendMessageW(e,EM_SETSEL,3,8);DWORD a,b;selection(&a,&b);ti_editor_syntax(1);ti_editor_tick();ti_editor_syntax(0);DWORD c,d;selection(&c,&d);CHECK(a==c&&b==d);CHECK(equals(L"pierwszy\r\ndrugi"));
 reset(L"abc");SendMessageW(e,WM_CHAR,1,1);selection(&a,&b);CHECK(a==0&&b==3);
 SendMessageW(e,WM_CHAR,L'X',1);CHECK(equals(L"X"));SendMessageW(e,WM_CHAR,26,1);CHECK(equals(L"abc"));
 reset(L"abc");CHECK(paste(L"Żółć\r\n東京"));CHECK(equals(L"abcŻółć\r\n東京"));SendMessageW(e,EM_UNDO,0,0);CHECK(equals(L"abc"));
 reset(L"");type(L"pros");ti_editor_complete();SendMessageW(e,WM_CHAR,'\t',1);CHECK(equals(L"prostokat"));CHECK(GetFocus()==e);
 reset(L"pro");SendMessageW(e,EM_SETSEL,1,2);ti_editor_complete();SendMessageW(e,EM_REPLACESEL,TRUE,(LPARAM)L"R");CHECK(equals(L"pRo"));
 reset(L"");type(L"pr");ti_editor_complete();type(L"os");SendMessageW(e,WM_CHAR,'\t',1);CHECK(equals(L"prostokat"));
 reset(L"pros\r\npisz 42");SendMessageW(e,EM_SETSEL,4,4);ti_editor_complete();SendMessageW(e,EM_SETSEL,9,9);SendMessageW(e,WM_CHAR,'\t',1);CHECK(contains(L"pros\r\npisz 42"));
 reset(L"pisz \"pros\"");SendMessageW(e,EM_SETSEL,10,10);ti_editor_complete();SendMessageW(e,WM_CHAR,'\t',1);CHECK(contains(L"pisz \"pros"));
 reset(L"One two ONE");SendMessageW(e,EM_SETSEL,0,0);CHECK(ti_editor_find(L"one"));selection(&a,&b);CHECK(a==0&&b==3);CHECK(ti_editor_find(L"oNe"));selection(&a,&b);CHECK(a==8&&b==11);CHECK(ti_editor_find(L"ONE"));selection(&a,&b);CHECK(a==0&&b==3);CHECK(!ti_editor_find(L"missing"));selection(&c,&d);CHECK(a==c&&b==d);
 ti_editor_autocorrect(1);reset(L"prostkoat gracz 10 20 30 40 czerwony");type(L"\r");CHECK(contains(L"prostokat gracz"));
 reset(L"prostkoat = 10");type(L"\r");CHECK(contains(L"prostkoat = 10"));
 reset(L"pisz \"prostkoat\"");type(L"\r");CHECK(contains(L"pisz \"prostkoat\""));
 reset(L"FUNKCJA PROSTKOAT wartosc\r\nzwroc wartosc\r\nkoniec\r\n");type(L"prostkoat 42\r");CHECK(contains(L"prostkoat 42"));ti_editor_autocorrect(0);
 wchar_t*large=malloc(250001*sizeof *large);CHECK(large);for(size_t i=0;i<250000;i++)large[i]=L'a';large[250000]=0;large[200000]=L'Ż';
 reset(large);CHECK(equals(large));SendMessageW(e,EM_SETSEL,200000,200001);selection(&a,&b);CHECK(a==200000&&b==200001);
 SendMessageW(e,EM_REPLACESEL,TRUE,(LPARAM)L"Ł");large[200000]=L'Ł';CHECK(equals(large));SendMessageW(e,EM_UNDO,0,0);large[200000]=L'Ż';CHECK(equals(large));
 SendMessageW(e,EM_SETSEL,220000,220000);CHECK(ti_editor_find(L"Ż"));selection(&a,&b);CHECK(a==200000&&b==200001);
 SendMessageW(e,EM_SETSEL,200002,200002);ti_editor_complete();selection(&c,&d);CHECK(c==200002&&d==200002);CHECK(equals(large));
 SendMessageW(e,EM_SETSEL,120000,120000);ti_editor_zoom(2);ti_editor_zoom(0);selection(&a,&b);CHECK(a==120000&&b==120000);CHECK(equals(large));for(size_t i=0;i<249998;i+=10){large[i+8]=L'\r';large[i+9]=L'\n';}large[200000]=L'Ż';
 reset(large);SendMessageW(e,EM_SETSEL,200005,200005);ti_editor_complete();selection(&a,&b);CHECK(a==200005&&b==200005);CHECK(equals(large));free(large);
 CHECK(changes>0);ti_editor_destroy();DestroyWindow(p);DeleteObject(f);
 puts("Windows editor: plain text, Unicode, paste/undo, completion, protected correction, find, selection and 250k document cases passed");return 0;
}
