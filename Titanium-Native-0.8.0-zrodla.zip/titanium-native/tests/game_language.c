#include "../src/game.h"
#include "../src/internal.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct {int frames,limit,assets;TiScene scene;} Fixture;
static int frame(void *ctx,const TiScene *s,TiInput *in,double *dt,char error[256]){
    Fixture *f=ctx;(void)error;f->scene=*s;memset(in,0,sizeof *in);in->keys['D']=1;*dt=.05;return ++f->frames<=f->limit;
}
static int asset(void *ctx,const char *file,char error[256]){
    Fixture *f=ctx;(void)error;assert(!strcmp(file,"bohater.png")||!strcmp(file,"moneta.png")||!strcmp(file,"bieg.png"));f->assets++;return 1;
}
static TiProgram *run(const char *code,Fixture *f,FILE *out){
    TiError e;TiProgram *p=ti_compile(code,strlen(code),&e);
    if(!p){fprintf(stderr,"compile line%d: %s\n",e.line,e.text);assert(p);}
    TiHost h={f,frame,asset,NULL};int ok=ti_execute_host(p,stdin,out,&e,&h);
    if(!ok)fprintf(stderr,"runtime line%d: %s\n",e.line,e.text);assert(ok);return p;
}
int main(int argc,char **argv){
    const char *code="wywolaj 2D\nokno \"Test\" 640 360\ntlo granatowy\nprostokat gracz 10 10 10 10 niebieski\nkolo moneta 30 15 8 zloty\nobraz ozdoba \"bohater.png\" 60 60 20 20\nsteruj gracz 100\npunkty = 0\nzawsze\n jesli dotyka gracz moneta\n  dodaj punkty 1\n  pozycja moneta 500 100\n koniec\n napis wynik (\"Punkty: \" + punkty) 10 10 bialy\nkoniec\npisz punkty\n";
    Fixture f={.limit=3};FILE *out=tmpfile();assert(out);TiProgram *p=run(code,&f,out);
    assert(f.assets==1&&f.scene.count==4);assert(!strcmp(f.scene.objects[3].text,"Punkty: 1"));
    assert(f.scene.objects[0].x==25);rewind(out);char b[64];assert(fgets(b,sizeof b,out)&&!strcmp(b,"1\n"));ti_free(p);fclose(out);
    const char *frame_name="funkcja klatka a\nzwroc a\nkoniec\nwywolaj 2D\nn = 0\nzawsze\ndodaj n 1\nkoniec\npisz klatka(n)\n";
    f=(Fixture){.limit=3};out=tmpfile();assert(out);p=run(frame_name,&f,out);
    assert(f.frames>=4&&f.frames<=5);rewind(out);assert(fgets(b,sizeof b,out)&&!strcmp(b,"3\n"));ti_free(p);fclose(out);
    const char *long_run="wywolaj 2D\nstaly = tekst 12345\nn = 0\nzawsze\n dodaj n 1\n opis = \"Klatka: \" + n\n napis hud opis 10 10 bialy\nkoniec\npisz staly\n";
    f=(Fixture){.limit=100000};out=tmpfile();assert(out);p=run(long_run,&f,out);
    assert(p->bytes<3*1024*1024);rewind(out);assert(fgets(b,sizeof b,out)&&!strcmp(b,"12345\n"));ti_free(p);fclose(out);
    for(int i=1;i<argc;i++){
        FILE *file=fopen(argv[i],"rb");assert(file);char *src=calloc(1,250001);assert(src);size_t n=fread(src,1,250000,file);src[n]=0;fclose(file);
        f=(Fixture){.limit=8};out=tmpfile();p=run(src,&f,out);assert(f.scene.count>1);ti_free(p);fclose(out);free(src);
    }
    puts("game_language: integration and 100000-frame memory test passed");return 0;
}
