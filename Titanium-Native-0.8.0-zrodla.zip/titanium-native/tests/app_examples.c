#include "../src/app.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int calls;
static int frame(void*ctx,TiAppScene*s,TiAppInput*i,char e[256]){(void)ctx;(void)i;(void)e;assert(s->count>=4);return ++calls<10;}
int main(int argc,char**argv){
 TiHost host={.app=frame};for(int i=1;i<argc;i++){
 FILE*f=fopen(argv[i],"rb");assert(f);char*source=calloc(250001,1);assert(source);size_t n=fread(source,1,250000,f);fclose(f);TiError e;TiProgram*p=ti_compile(source,n,&e);if(!p)fprintf(stderr,"%s line %d %s\n",argv[i],e.line,e.text);assert(p&&ti_program_is_app(p));calls=0;FILE*out=tmpfile();assert(ti_execute_host(p,stdin,out,&e,&host));assert(calls==10);ti_free(p);free(source);fclose(out);
 }puts("app_examples: calculator and notepad compile and run through app frames");
}
