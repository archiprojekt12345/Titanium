#include "../src/app.h"
#include "../src/internal.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct {int frames,limit;char result[4096];} Fixture;
static int frame(void*context,TiAppScene*scene,TiAppInput*input,char error[256]){
 Fixture*f=context;(void)error;if(!scene->active)return 0;
 if(f->frames==0){strcpy(scene->controls[0].text,"21");strcpy(input->click,"oblicz");}
 if(scene->count>2)strcpy(f->result,scene->controls[2].text);
 return ++f->frames<=f->limit;
}
int main(void){
 const char*code="aplikacja \"Test\" 640 420\npole dane \"10\" 20 20 200 30\nprzycisk oblicz \"Oblicz\" 20 80 160 30\netykieta wynik \"\" 20 130 300 30\nstary = wartosc dane\nzawsze\njesli kliknieto oblicz\nustaw_tekst wynik tekst (liczba wartosc dane * 2)\nkoniec\nkoniec\npisz stary\n";
 TiError e;TiProgram*p=ti_compile(code,strlen(code),&e);if(!p)fprintf(stderr,"line %d %s\n",e.line,e.text);assert(p);assert(ti_program_is_app(p));Fixture f={.limit=4};TiHost h={.context=&f,.app=frame};FILE*out=tmpfile();assert(ti_execute_host(p,stdin,out,&e,&h));assert(!strcmp(f.result,"42"));rewind(out);char text[64];assert(fgets(text,sizeof text,out)&&!strcmp(text,"10\n"));fclose(out);ti_free(p);
 const char*game="# aplikacja in comment\npisz \"aplikacja\"\n";p=ti_compile(game,strlen(game),&e);assert(p&&!ti_program_is_app(p));ti_free(p);
 const char*long_run="aplikacja \"Stress\" 640 420\npole dane \"sample\" 20 20 200 30\nzawsze\na = wartosc dane\nkoniec\n";p=ti_compile(long_run,strlen(long_run),&e);assert(p);f=(Fixture){.limit=100000};out=tmpfile();assert(ti_execute_host(p,stdin,out,&e,&h));assert(p->bytes<3*1024*1024);fclose(out);ti_free(p);
 puts("app_language: event routing, immutable value snapshots, GUI classification, 100000-frame memory passed");
}
