#include "../src/lowlevel.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#define N(x) (TiValue){0,(x),NULL}
#define S(x) (TiValue){1,0,(x)}
static TiMemory memory;
static TiValue result;
static char error[256];
static void ok(const char *name,int argc,const TiValue *args) {
    int rc=ti_memory_call(&memory,name,argc,args,&result,error);
    if(rc!=1)fprintf(stderr,"%s: %s\n",name,error);
    assert(rc==1);
}
static void bad(const char *name,int argc,const TiValue *args) {
    error[0]=0;
    assert(ti_memory_call(&memory,name,argc,args,&result,error)==-1);
    assert(error[0]);
}
static void number(double expected) { assert(result.kind==0 && result.n==expected); }
int main(void) {
    ti_memory_init(&memory);
    assert(ti_memory_call(&memory,"unknown",0,NULL,&result,error)==0);
    const char *names[]={"bufor","wpisz_bajt","bajt","rozmiar_bufora","zwolnij_bufor","bity_i","bity_lub","bity_xor","bity_nie","bity_lewo","bity_prawo"};
    int counts[]={2,3,2,1,1,2,2,2,1,2,2};
    for(unsigned i=0;i<sizeof names/sizeof *names;i++) {
        bad(names[i],-1,NULL);bad(names[i],0,NULL);
        bad(names[i],counts[i],NULL);
        bad(names[i],counts[i]+1,(TiValue[]){N(0),N(0),N(0),N(0)});
    }
    char borrowed[]="data";
    ok("bufor",2,(TiValue[]){S(borrowed),N(65536)});
    borrowed[0]='X';
    ok("rozmiar_bufora",1,(TiValue[]){S("data")});number(65536);
    ok("bajt",2,(TiValue[]){S("data"),N(65535)});number(0);
    ok("wpisz_bajt",3,(TiValue[]){S("data"),N(65535),N(255)});
    ok("bajt",2,(TiValue[]){S("data"),N(65535)});number(255);
    bad("bajt",2,(TiValue[]){S("data"),N(65536)});
    bad("wpisz_bajt",3,(TiValue[]){S("data"),N(0),N(256)});
    ok("bufor",2,(TiValue[]){S("data"),N(65536)});
    ok("bajt",2,(TiValue[]){S("data"),N(65535)});number(0);
    ok("wpisz_bajt",3,(TiValue[]){S("data"),N(3),N(222)});
    ok("bufor",2,(TiValue[]){S("data"),N(1)});
    bad("bajt",2,(TiValue[]){S("data"),N(3)});
    ok("bufor",2,(TiValue[]){S("data"),N(4)});
    ok("bajt",2,(TiValue[]){S("data"),N(3)});number(0);
    double invalid[]={-1,.5,NAN,INFINITY,-INFINITY,4294967296.};
    for(unsigned i=0;i<sizeof invalid/sizeof *invalid;i++) {
        double v=invalid[i];
        bad("bufor",2,(TiValue[]){S("data"),N(v)});
        bad("bajt",2,(TiValue[]){S("data"),N(v)});
        bad("wpisz_bajt",3,(TiValue[]){S("data"),N(0),N(v)});
        bad("bity_nie",1,(TiValue[]){N(v)});
        bad("bity_i",2,(TiValue[]){N(0),N(v)});
        bad("bity_lewo",2,(TiValue[]){N(1),N(v)});
    }
    bad("bufor",2,(TiValue[]){S("data"),N(65537)});
    bad("bufor",2,(TiValue[]){S(""),N(1)});
    bad("bufor",2,(TiValue[]){S("\xc3\xa9"),N(1)});
    char longname[65];memset(longname,'a',64);longname[64]=0;
    bad("bufor",2,(TiValue[]){S(longname),N(1)});
    longname[63]=0;ok("bufor",2,(TiValue[]){S(longname),N(1)});
    bad("bufor",2,(TiValue[]){N(1),N(1)});
    bad("bufor",2,(TiValue[]){S(NULL),N(1)});
    bad("bity_i",2,(TiValue[]){S("1"),N(1)});
    bad("bajt",2,(TiValue[]){S("missing"),N(0)});
    bad("zwolnij_bufor",1,(TiValue[]){S("missing")});
    ok("bufor",2,(TiValue[]){S("empty"),N(0)});
    ok("rozmiar_bufora",1,(TiValue[]){S("empty")});number(0);
    bad("bajt",2,(TiValue[]){S("empty"),N(0)});
    ti_memory_init(&memory);
    for(int i=0;i<16;i++) { char name[16];snprintf(name,sizeof name,"slot%d",i);ok("bufor",2,(TiValue[]){S(name),N(2)}); }
    bad("bufor",2,(TiValue[]){S("overflow"),N(2)});
    ok("wpisz_bajt",3,(TiValue[]){S("slot0"),N(0),N(99)});
    ok("bufor",2,(TiValue[]){S("slot0"),N(2)});
    ok("bajt",2,(TiValue[]){S("slot0"),N(0)});number(0);
    ok("zwolnij_bufor",1,(TiValue[]){S("slot0")});
    bad("rozmiar_bufora",1,(TiValue[]){S("slot0")});
    ok("bufor",2,(TiValue[]){S("reuse"),N(2)});
    ok("bajt",2,(TiValue[]){S("reuse"),N(0)});number(0);
    ok("bity_i",2,(TiValue[]){N(4294967295.),N(2147483648.)});number(2147483648.);
    ok("bity_lub",2,(TiValue[]){N(2147483648.),N(1)});number(2147483649.);
    ok("bity_xor",2,(TiValue[]){N(4294967295.),N(2147483648.)});number(2147483647.);
    ok("bity_nie",1,(TiValue[]){N(0)});number(4294967295.);
    ok("bity_nie",1,(TiValue[]){N(4294967295.)});number(0);
    ok("bity_lewo",2,(TiValue[]){N(4294967295.),N(31)});number(2147483648.);
    ok("bity_lewo",2,(TiValue[]){N(2147483648.),N(1)});number(0);
    ok("bity_prawo",2,(TiValue[]){N(4294967295.),N(31)});number(1);
    ok("bity_prawo",2,(TiValue[]){N(4294967295.),N(0)});number(4294967295.);
    bad("bity_lewo",2,(TiValue[]){N(1),N(32)});
    bad("bity_prawo",2,(TiValue[]){N(1),N(32)});
    puts("lowlevel: buffer lifecycle/capacity, copied names, zeroing, numeric validation and uint32 bit operations passed");
    return 0;
}
