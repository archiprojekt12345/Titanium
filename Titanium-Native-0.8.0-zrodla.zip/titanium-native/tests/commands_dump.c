#include "../src/commands.h"
int main(void){ti_write_commands(stdout);return 0;}
