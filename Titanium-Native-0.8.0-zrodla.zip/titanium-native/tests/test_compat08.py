import os,subprocess,tempfile,unittest
from pathlib import Path
COMPILER=os.environ.get('TI_TEST_EXE','/tmp/titanium08')
class Compat08(unittest.TestCase):
 def run_code(self,code):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'old.ti';p.write_text(code,encoding='utf8');return subprocess.run([COMPILER,str(p)],text=True,capture_output=True,timeout=5)
 def test_old_function_can_keep_name_added_in_later_release(self):
  r=self.run_code('funkcja wartosc a b\nzwroc a + b\nkoniec\nfunkcja sin x\nzwroc x * 2\nkoniec\npisz wartosc(2,3)\npisz sin 7\n')
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stdout.splitlines(),['5','14'])
 def test_legacy_interpunctuation_and_names(self):
  r=self.run_code('FUNKCJA podwój(x)\nZWROC x*2\nKONIEC\nwartość = 4\npisz("Zażółć:",podwój(wartość))\n')
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stdout,'Zażółć: 8\n')

 def test_hexadecimal_forms_from_original_native_lexer(self):
  r=self.run_code('pisz 0x100000000\npisz 0x1p2\n')
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stdout.splitlines(),['4294967296','4'])
