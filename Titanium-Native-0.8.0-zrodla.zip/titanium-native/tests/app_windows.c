/* Standalone Win32 application host verification. Run on a Windows desktop. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "../src/app_win.h"

static void native_test(void){
 TiAppScene scene={0};TiAppInput input;char err[256]={0};
 scene.active=1;scene.width=640;scene.height=480;strcpy(scene.title,"Titanium app native test");scene.count=3;
 for(unsigned i=0;i<scene.count;i++){TiControl *c=&scene.controls[i];snprintf(c->name,sizeof c->name,"c%u",i);c->kind=i==0?TI_APP_EDIT:i==1?TI_APP_BUTTON:TI_APP_CHECK;c->x=10;c->y=10+(int)i*40;c->w=150;c->h=30;c->visible=c->enabled=1;strcpy(c->text,"Start");}
 TiAppView *view=ti_app_view_create();assert(view);assert(ti_app_view_frame(view,&scene,&input,err)==1);
 HWND window=FindWindowW(NULL,L"Titanium app native test");assert(window);
 HWND edit=GetDlgItem(window,100),button=GetDlgItem(window,101),check=GetDlgItem(window,102);assert(edit&&button&&check);
 SetWindowTextW(edit,L"Zażółć");SendMessageW(edit,EM_SETSEL,2,2);
 for(int i=0;i<130;i++)PostMessageW(window,WM_COMMAND,MAKEWPARAM(i%2?102:101,BN_CLICKED),(LPARAM)(i%2?check:button));
 assert(ti_app_view_frame(view,&scene,&input,err)==1);assert(!strcmp(scene.controls[0].text,"Zażółć"));assert(!strcmp(input.click,"c1"));
 DWORD start,end;SendMessageW(edit,EM_GETSEL,(WPARAM)&start,(LPARAM)&end);assert(start==2&&end==2);
 for(int i=1;i<130;i++){assert(ti_app_view_frame(view,&scene,&input,err)==1);assert(!strcmp(input.click,i%2?"c2":"c1"));}
 assert(ti_app_view_frame(view,&scene,&input,err)==1&&!input.click[0]);
 strcpy(scene.controls[0].text,"Program");scene.controls[1].enabled=0;scene.controls[2].visible=0;
 assert(ti_app_view_frame(view,&scene,&input,err)==1);wchar_t value[64];GetWindowTextW(edit,value,64);assert(!wcscmp(value,L"Program"));assert(!IsWindowEnabled(button)&&!IsWindowVisible(check));
 PostMessageW(window,WM_CLOSE,0,0);assert(ti_app_view_frame(view,&scene,&input,err)==0);assert(!scene.active);
 scene.active=1;assert(ti_app_view_frame(view,&scene,&input,err)==1);scene.active=0;assert(ti_app_view_frame(view,&scene,&input,err)==0);
 ti_app_view_destroy(view);
 puts("app native: Unicode edits, caret, 130 queued clicks, states, close/reopen passed");
}

int main(void){native_test();return 0;}
