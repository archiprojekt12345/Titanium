import json,re,unittest,os,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
COMPILER=os.environ.get('TI_TEST_EXE','/tmp/titanium08')
class Historical08(unittest.TestCase):
 def test_all_old_command_signatures_remain(self):
  rows=re.findall(r'C\("([^"]+)",(\d+),(\d+),(\d+),(\d+),(\d+),',(ROOT/'src/commands.c').read_text())
  current={row[0]:dict(zip(['min','max','prefix','game','names'],map(int,row[1:]))) for row in rows}
  for version in ['0.5.0','0.6.0','0.7.0']:
   for old in json.loads((ROOT/'tests/historical'/('commands-'+version+'.json')).read_text()):
    with self.subTest(version=version,command=old['name']):
     now=current[old['name']]
     for key in ['min','max','prefix','game','names']:self.assertEqual(now[key],old[key])
 def test_every_archived_program_compiles_unchanged(self):
  for p in sorted((ROOT/'tests/historical').rglob('*.ti')):
   with self.subTest(file=p.relative_to(ROOT).as_posix()):
    r=subprocess.run([COMPILER,'--check',str(p)],text=True,capture_output=True,timeout=5);self.assertEqual(r.returncode,0,r.stderr)
