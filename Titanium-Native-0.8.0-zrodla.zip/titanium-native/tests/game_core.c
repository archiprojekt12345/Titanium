#include "../src/game.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#define N(x) ((TiValue){0,(x),NULL})
#define S(x) ((TiValue){1,0,(x)})
static TiValue result;
static char error[256];
static TiInput next_input;
static double next_dt;
static int frame_status=1,asset_ok=1,frames,assets;
static TiScene published;
static int frame(void *ctx,const TiScene *s,TiInput *i,double *dt,char e[256]) {
    (void)ctx; frames++;published=*s;*i=next_input;*dt=next_dt;
    if(frame_status<0)strcpy(e,"Blad testowego podgladu");
    return frame_status;
}
static int asset(void *ctx,const char *s,char e[256]) {
    (void)ctx;(void)s;assets++;if(!asset_ok)strcpy(e,"Brak obrazu");return asset_ok;
}
static int call(TiGame *g,const char *s,int n,TiValue *a) {return ti_game_call(g,s,n,a,&result,error);}
static void ok(TiGame *g,const char *s,int n,TiValue *a) {int r=call(g,s,n,a);if(r!=1)fprintf(stderr,"%s: %s (%d)\n",s,error,r);assert(r==1);}
static void bad(TiGame *g,const char *s,int n,TiValue *a) {assert(call(g,s,n,a)==-1);assert(*error);}
static void init(TiGame *g) {TiHost h={NULL,frame,asset,NULL};ti_game_init(g,&h);memset(&next_input,0,sizeof next_input);next_dt=1.0/60;frame_status=asset_ok=1;ok(g,"wywolaj",1,(TiValue[]){S("2d")});}
static void rect(TiGame*g,const char*s,double x,double y,double w,double h) {ok(g,"prostokat",6,(TiValue[]){S(s),N(x),N(y),N(w),N(h),S("czerwony")});}
static void circle(TiGame*g,const char*s,double x,double y,double r) {ok(g,"kolo",5,(TiValue[]){S(s),N(x),N(y),N(r),S("bialy")});}
static int hit(TiGame*g,const char*a,const char*b) {ok(g,"dotyka",2,(TiValue[]){S(a),S(b)});assert(result.kind==2);return result.n!=0;}
static void test_lifecycle(void) {
    TiGame g;ti_game_init(&g,NULL);assert(g.scene.width==640&&g.scene.height==360&&g.scene.background==0&&g.dt>0);
    assert(call(&g,"unknown",0,NULL)==0);bad(&g,"klatka",0,NULL);bad(&g,"wywolaj",1,(TiValue[]){S("2d")});
    init(&g);assert(g.started&&g.scene.active);bad(&g,"wywolaj",1,(TiValue[]){S("3d")});
    ok(&g,"okno",3,(TiValue[]){S("Proba"),N(800),N(600)});assert(g.scene.width==800&&g.scene.height==600&&!strcmp(g.scene.title,"Proba"));
    bad(&g,"okno",3,(TiValue[]){S("Zle"),N(0),N(600)});assert(g.scene.width==800);
    bad(&g,"okno",3,(TiValue[]){S("Za waskie"),N(159),N(90)});
    bad(&g,"okno",3,(TiValue[]){S("Za niskie"),N(160),N(89)});
    bad(&g,"okno",3,(TiValue[]){S("Za szerokie"),N(3841),N(720)});
    bad(&g,"okno",3,(TiValue[]){S("Za wysokie"),N(1280),N(2161)});
    bad(&g,"okno",3,(TiValue[]){S("Ulamek"),N(640.5),N(360)});
    bad(&g,"okno",3,(TiValue[]){S("Ulamek"),N(640),N(360.5)});
    ok(&g,"okno",3,(TiValue[]){S("Minimum"),N(160),N(90)});
    ok(&g,"okno",3,(TiValue[]){S("Maksimum"),N(1280),N(720)});
    ok(&g,"tlo",1,(TiValue[]){S("#12AbEF")});assert(g.scene.background==0x12abef);
    bad(&g,"tlo",1,(TiValue[]){S("#zzffff")});bad(&g,"tlo",0,NULL);
    ok(&g,"koncz",0,NULL);assert(!g.scene.active);ok(&g,"klatka",0,NULL);assert(result.kind==2&&!result.n);
}
static void test_objects(void) {
    TiGame g;init(&g);char name[32]="gracz";rect(&g,name,10,20,30,40);name[0]='X';
    assert(g.scene.count==1&&!strcmp(g.scene.objects[0].name,"gracz"));assert(g.scene.objects[0].kind==TI_RECT&&g.scene.objects[0].color==0xff0000);
    ok(&g,"steruj",2,(TiValue[]){S("gracz"),N(100)});rect(&g,"gracz",20,30,40,50);assert(g.scene.count==1);
    ok(&g,"pozycja",3,(TiValue[]){S("gracz"),N(2),N(3)});ok(&g,"przesun",3,(TiValue[]){S("gracz"),N(4),N(5)});
    ok(&g,"x",1,(TiValue[]){S("gracz")});assert(result.kind==0&&result.n==6);ok(&g,"y",1,(TiValue[]){S("gracz")});assert(result.n==8);
    ok(&g,"rozmiar",3,(TiValue[]){S("gracz"),N(7),N(9)});assert(g.scene.objects[0].w==7&&g.scene.objects[0].h==9);
    ok(&g,"kolor",2,(TiValue[]){S("gracz"),S("zloty")});assert(g.scene.objects[0].color==0xffd700);
    ok(&g,"ukryj",1,(TiValue[]){S("gracz")});assert(!g.scene.objects[0].visible);ok(&g,"pokaz",1,(TiValue[]){S("gracz")});assert(g.scene.objects[0].visible);
    bad(&g,"pozycja",3,(TiValue[]){S("gracz"),N(NAN),N(0)});bad(&g,"przesun",3,(TiValue[]){S("gracz"),N(1e6),N(0)});
    bad(&g,"steruj",2,(TiValue[]){S("gracz"),N(2001)});bad(&g,"rozmiar",3,(TiValue[]){S("gracz"),N(0),N(3)});
    bad(&g,"prostokat",6,(TiValue[]){S("bad"),N(0),N(0),N(2),N(2),S("nope")});assert(g.scene.count==1);
    ok(&g,"napis",5,(TiValue[]){S("etykieta"),S("Zazolc UTF8 \xc4\x85"),N(0),N(0),S("bialy")});assert(g.scene.objects[1].kind==TI_LABEL&&!strcmp(g.scene.objects[1].text,"Zazolc UTF8 \xc4\x85"));
    ok(&g,"usun",1,(TiValue[]){S("gracz")});assert(g.scene.count==1);bad(&g,"x",1,(TiValue[]){S("gracz")});
    for(int i=1;i<TI_OBJECTS;i++){char b[32];snprintf(b,sizeof b,"o%d",i);rect(&g,b,0,0,1,1);}assert(g.scene.count==TI_OBJECTS);
    bad(&g,"prostokat",6,(TiValue[]){S("overflow"),N(0),N(0),N(1),N(1),S("bialy")});ok(&g,"usun",1,(TiValue[]){S("o1")});rect(&g,"reused",0,0,1,1);assert(g.scene.count==TI_OBJECTS);
}
static void test_collisions(void) {
    TiGame g;init(&g);rect(&g,"box",0,0,10,10);circle(&g,"ball",12,12,2);assert(!hit(&g,"box","ball"));
    ok(&g,"pozycja",3,(TiValue[]){S("ball"),N(11),N(11)});assert(hit(&g,"box","ball")&&hit(&g,"ball","box"));
    circle(&g,"other",15,11,2);assert(hit(&g,"ball","other"));ok(&g,"przesun",3,(TiValue[]){S("other"),N(0.1),N(0)});assert(!hit(&g,"ball","other"));
    rect(&g,"edge",10,0,10,10);assert(hit(&g,"box","edge"));ok(&g,"ukryj",1,(TiValue[]){S("edge")});assert(!hit(&g,"box","edge"));
    ok(&g,"napis",5,(TiValue[]){S("text"),S("hi"),N(0),N(0),S("bialy")});assert(!hit(&g,"box","text"));
}
static void test_assets(void) {
    const char *good[]={"sprite.png","x.JPG","x.jpeg","x.bmp","gracz \xc4\x85.png"};
    const char *badnames[]={"","../x.png","x..png","a/b.png","a\\b.png","C:x.png","x.gif","x.png/",".","x\n.png"};
    for(size_t i=0;i<sizeof good/sizeof *good;i++)assert(ti_game_asset_name(good[i]));
    for(size_t i=0;i<sizeof badnames/sizeof *badnames;i++)assert(!ti_game_asset_name(badnames[i]));
    TiGame g;init(&g);int old=assets;ok(&g,"obraz",6,(TiValue[]){S("image"),S("sprite.png"),N(0),N(0),N(10),N(20)});assert(assets==old+1&&g.scene.objects[0].kind==TI_IMAGE);
    asset_ok=0;bad(&g,"obraz",6,(TiValue[]){S("missing"),S("missing.png"),N(0),N(0),N(10),N(20)});assert(g.scene.count==1);
    old=assets;bad(&g,"obraz",6,(TiValue[]){S("evil"),S("../x.png"),N(0),N(0),N(10),N(20)});assert(assets==old);
}
static void test_input_time_motion(void) {
    TiGame g;init(&g);rect(&g,"hero",10,10,10,10);ok(&g,"steruj",2,(TiValue[]){S("hero"),N(100)});
    next_input.keys['D']=next_input.keys[40]=next_input.keys[32]=1;next_input.buttons[0]=1;next_input.mouse_x=33;next_input.mouse_y=44;next_dt=.1;
    ok(&g,"klatka",0,NULL);assert(result.kind==2&&result.n&&published.count==1);assert(fabs(g.scene.objects[0].x-(10+10/sqrt(2)))<1e-9);
    ok(&g,"klawisz",1,(TiValue[]){S("spacja")});assert(result.kind==2&&result.n);ok(&g,"wcisnieto",1,(TiValue[]){S("spacja")});assert(result.n);
    ok(&g,"klik",1,(TiValue[]){S("lewy")});assert(result.n);ok(&g,"mysz_x",0,NULL);assert(result.n==33);ok(&g,"mysz_y",0,NULL);assert(result.n==44);
    next_dt=10;ok(&g,"klatka",0,NULL);ok(&g,"delta",0,NULL);assert(result.n==.1);ok(&g,"czas",0,NULL);assert(fabs(result.n-.2)<1e-9);
    ok(&g,"wcisnieto",1,(TiValue[]){S("spacja")});assert(!result.n);ok(&g,"klik",1,(TiValue[]){S("lewy")});assert(!result.n);
    bad(&g,"klawisz",1,(TiValue[]){S("unknown")});bad(&g,"klik",1,(TiValue[]){S("srodek")});
    ok(&g,"pozycja",3,(TiValue[]){S("hero"),N(638),N(359)});ok(&g,"klatka",0,NULL);assert(g.scene.objects[0].x==630&&g.scene.objects[0].y==350);
    rect(&g,"stationary",-25,-30,10,10);circle(&g,"circle",0,0,5);
    ok(&g,"steruj",2,(TiValue[]){S("circle"),N(100)});ok(&g,"klatka",0,NULL);
    assert(g.scene.objects[1].x==-25&&g.scene.objects[1].y==-30);
    assert(g.scene.objects[2].x>=5&&g.scene.objects[2].y>=5);
    ok(&g,"steruj",2,(TiValue[]){S("circle"),N(0)});
    ok(&g,"pozycja",3,(TiValue[]){S("circle"),N(-20),N(-21)});ok(&g,"klatka",0,NULL);
    assert(g.scene.objects[2].x==-20&&g.scene.objects[2].y==-21);
    frame_status=-1;bad(&g,"klatka",0,NULL);assert(!strcmp(error,"Blad testowego podgladu"));frame_status=0;ok(&g,"klatka",0,NULL);assert(!result.n&&!g.scene.active);
}
int main(void) {test_lifecycle();test_objects();test_collisions();test_assets();test_input_time_motion();puts("game_core: all tests passed");return 0;}
