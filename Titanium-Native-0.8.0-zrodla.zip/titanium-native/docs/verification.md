# Weryfikacja wydania 0.3

2026-10-19: `python3 build.py --zig /tmp/titanium-native-zig/ziglang/zig` zakończone kodem 0. Plik PE32+ Windows x64, edytor subsystem GUI (2); Demo-Konsola.exe subsystem CUI (3). Importy wyłącznie bibliotek systemu Windows i systemowego UCRT. Brak WebView2 i DLL dołączanych przez projekt.

`python3 test.py`: 16 testów PASS, w tym wykonanie sześciu lekcji, czytanie gotowego demo rzeczywistym czytnikiem pakietów C, ponowne pakowanie, uszkodzenia pakietu, kontrola podsystemu, polskie znaki, wejście, funkcje, rekurencja, warunki, krótkie spięcia, pętle i limity. Osobny test C normalizacji CR/LF/CRLF również PASS.

ASan i UBSan: 11 testów silnika PASS. LeakSanitizer wyłączony, ponieważ dostęp do `/proc` jest zablokowany w środowisku. Nie traktować tego jako testu wycieków.

Niezależny przegląd kodu wskazał odczytywanie pliku przed pytaniem o zapis (możliwy powrót do starej treści). Zmieniono kolejność: pytanie i zapis, potem odczyt; nieudany odczyt nie czyści edytora. Przegląd nie znalazł innych ważnych błędów silnika i formatu pakietu.

Komunikaty kończącego się wysyłania odpowiedzi mają identyfikator uruchomienia, aby nie zmieniały stanu kolejnego programu. Polecenia są wykonywane w procesie potomnym, odczyt i zapis potoków w wątkach roboczych. Eksport tworzy konsolowy podsystem PE; edytor zachowuje natywne GUI.

Nie uruchomiono aplikacji w Windows. Testy okna, dialogów, potoków Win32 i eksportowanego EXE wymagają Windows. Lista scenariuszy znajduje się w README. Nie deklarujemy ich potwierdzenia.
