# Titanium Native 0.5.0 — prostsze platformowki

Cel: uczen tworzy postac platformowki bez delta, recznego liczenia grawitacji,
testowania wysokosci podlogi i ograniczania pozycji. Istniejace programy 0.4.1
zachowuja znaczenie komend. Edytor pozostaje natywny Win32, szary, bez zaleznosci
instalowanych przez ucznia. Kod przykladow i nazwy komend ASCII, bez wciec.

## Interfejs

- `platformowka gracz`: sterowanie lewo/prawo lub A/D, pojedynczy skok spacja,
  domyslnie bieg 220 px/s, skok 430 px/s, grawitacja 900 px/s2.
- `sciana obiekt`: statyczna pelna kolizja prostokata/obrazu.
- `platforma obiekt`: statyczna podloga przepuszczajaca od dolu.
- `fizyka obiekt`: swobodne cialo prostokatne z grawitacja.
- `chodzenie obiekt predkosc`, `skakanie obiekt sila`, `grawitacja obiekt sila`:
  zmieniaja ustawienia; 0 dozwolone, maksymalnie 2000/2000/5000.
- `predkosc obiekt vx vy`: utrzymuje ruch w px/s bez delta, wlacza cialo bez
  grawitacji gdy obiekt nie mial fizyki; zakres -2000..2000.
- `na_ziemi obiekt`, `spada obiekt`: logiczne odczyty stanu fizyki.
- `odbij obiekt sila`: natychmiastowe wybicie nawet w powietrzu, 0..2000.
- `patrol obiekt lewa prawa predkosc`: grawitacja i ruch miedzy granicami X
  lewego boku, zawracanie na scianie; nie wykrywa konca platformy.
- `swiat szerokosc wysokosc`: granice poziomu 160..100000 / 90..100000.
- `kamera obiekt`: sledzi srodek obiektu, ograniczona granicami swiata.
- `widok x y`: reczna pozycja kamery, wylacza sledzenie.
- `przypnij obiekt`: wspolrzedne ekranu dla HUD, bez fizyki/kolizji.
- `odrodzenie obiekt x y`, `odrodz obiekt`: punkt powrotu i wyzerowanie ruchu.
- `animuj obraz klatki fps`: poziomy pasek klatek, 1..64, 0..60 fps;
  fps=0 zatrzymuje na pierwszej klatce. Rozmiar obiektu to rozmiar jednej klatki.

## Architektura i kolejnosc

Rejestr commands.c jest jedynym zrodlem arnosci i spisu komend. game.c zachowuje
obsluge starego API i walidacje, physics.c odpowiada za ruch i kamere. Obiekty
przenosza stan fizyki, renderowania i animacji jako liczby/stale bufory bez
wskaznikow; wspoldzielona pamiec nadal przenosi cala scene.

klatka publikuje poprzedni stan, pobiera wejscie i czas, nastepnie aktualizuje
sterowanie i fizyke, potem wykonuje sie kod uzytkownika. Fizyka dzieli dt na kroki
nie dluzsze niz 1/120 s i rozwiazuje ciagle kolizje swept AABB w pelnym wektorze
ruchu z poslizgiem, wybierajac najblizsza przecieta powierzchnie. Zapobiega to przechodzeniu przez cienkie sciany przy
duzej predkosci. Nieruchome podpory wykrywane z tolerancja kontaktu; zetkniecie
samym naroznikiem nie jest podparciem. Nie ma wzajemnego popychania cial,
dynamicznych platform, obrotow ani poczatkowego wypychania z wnetrza sciany.

Sterownik: bufor skoku 0.12 s i tolerancja po zejsciu z krawedzi 0.10 s.
Trzymanie spacji nie powtarza skoku. Zmiana pozycji zeruje predkosci i stan
kontaktu ciala; zwykly przesun pozostaje natychmiastowym przesunieciem.
Niewidoczne/przypiete obiekty nie uczestnicza w fizyce. Usuniecie sledzonego
obiektu pozostawia kamere w ostatniej pozycji, ponowne utworzenie przywraca
sledzenie po nazwie. Kamera jest aktualizowana takze przed publikacja sceny.

## Weryfikacja i wydanie

Testy C: upadek i podparcie, skok i brak podwojnego skoku, sciany/sufit,
cienkie przeszkody, platformy jednostronne, roznice 30/60/120 FPS, patrol,
odrodzenie, kamera/HUD, animacja, usuwanie i walidacja bez czesciowych zmian.
Integracja kompilatora: nowe nazwy bez nawiasow, proste demo i pelny poziom.
Dotychczasowy komplet testow musi pozostac zielony. Wydanie Windows x64:
EXE, ZIP z assetami i instrukcjami oraz ZIP zrodel. Brak dostepnego Windows
oznacza jawne odroznienie testow silnika/cross-kompilacji od testu GUI.

Dzwiek, edytor map i zaawansowane oswietlenie pozostaja poza wersja 0.5.0.
