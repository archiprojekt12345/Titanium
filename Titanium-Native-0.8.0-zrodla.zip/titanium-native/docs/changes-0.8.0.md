# Titanium Studio 0.8.0

Nowy układ Studio: po lewej projekt i szablony, pośrodku duży edytor, po prawej paleta komend z wyszukiwaniem. Podgląd i konsola są dolnym panelem otwieranym podczas uruchamiania lub przyciskiem. F11 skupia widok na kodzie. Główne menu otwiera przycisk Menu albo F10.

Moduł edytora został wymieniony na natywny edytor tekstowy Unicode. Tekstu nie rysuje już mechanizm formatowania RichEdit/TOM. Program używa jednej jawnej ścieżki odczytu i wczytania źródła, a po wczytaniu sprawdza pełny tekst i w razie błędu przywraca poprzedni. Nie usuwa wcięć przy otwarciu pliku. Podpowiedzi Ctrl+Spacja / Tab, wyszukiwanie Ctrl+F i powiększanie tekstu działają nadal. Autokorekta jest domyślnie wyłączona i dostępna opcjonalnie w menu Program. Edytor nie koloruje składni i korzysta z pojedynczej operacji Undo natywnego kontrolera; te ograniczenia są celowe w tej stabilizacji.

Zgodność natywna: rejestry komend 0.5.0, 0.6.0 i 0.7.0 są sprawdzane automatycznie, a wszystkie 35 programów z tych paczek kompiluje się bez zmian. Składnia z nawiasami i przecinkami, polskie znaki, starsze gry i aplikacje pozostają obsługiwane. Jawnie zadeklarowana funkcja użytkownika ma pierwszeństwo przed dodaną później komendą — nowa nazwa nie blokuje starszego programu.

Wersje 0.1 i 0.2 miały odmienny język i przeglądarkowy silnik. Dołączono ich oryginalne, niezmienione silniki oraz przykłady. Program automatycznie rozpoznaje wyraźnie klasyczną składnię po niepowodzeniu natywnej kompilacji. Dla niejednoznacznego programu wybierz Menu > Program > Silnik klasyczny 0.1 lub 0.2. Tryb klasyczny uruchamia program lokalnie w przeglądarce, a eksportuje samodzielny HTML. Program natywny eksportuje EXE. Folder compatibility musi pozostać obok Titanium EXE. Pełne sprawdzenie dowolnego programu nie wynika z testów przykładów; nie deklarujemy nieudowodnionej zgodności 100% dla wszystkich wejść.

Nowa grafika: poswiata, swiatlo, smuga, wstrzas oraz sin/cos w radianach. Poświaty i radialne światła śledzą obiekty; smugi mają osobny ograniczony bufor; wstrząsy są wyłącznie wizualne i nie zmieniają fizyki ani HUD. Neutralne wartości domyślne zachowują wcześniejsze rysowanie.

NEON HARBOR: przycisk NEON • pokaz albo Przykłady > 15, potem F5. Orbitująca planeta i satelita, wielowarstwowe miasto, światła, ruchomy statek, podwójne smugi silników, animowany mechanik, cząsteczki, odbicia i stały HUD. P przełącza autopilota/WASD, spacja wywołuje impuls i wstrząs, Z/X zmienia zoom, Escape kończy. Samodzielny program NEON-HARBOR.exe jest w paczce.

Weryfikacja natywnego wyglądu i działania na Windows pozostaje do wykonania: w środowisku przygotowania paczki możliwa jest kompilacja Windows oraz testy przenośne, ale nie uruchomienie interfejsu Windows. Przyczynę pustego edytora na zrzucie ograniczono przez wymianę modułu; nie uznajemy jej za odtworzoną bez uruchomienia na docelowym komputerze.
