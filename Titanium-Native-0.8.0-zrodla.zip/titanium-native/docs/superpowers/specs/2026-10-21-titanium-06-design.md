# Titanium Native 0.6.0

Modernizacja istniejącego natywnego programu Windows x64. Użytkownik chce sam pisać gry: proste polskie komendy bez obowiązkowych nawiasów i TAB pozostają zgodne z 0.5.0.

Edytor: jasna hierarchia narzędzi, ciemny obszar kodu z kolorowaniem, numery wierszy, boczna wyszukiwarka komend z opisem i składnią, podpowiedzi Ctrl+Spacja i Tab. Autokorekta domyślnie włączona, przełączana w menu; poprawia tylko jednoznaczne literówki pierwszego polecenia po Enter, omija komentarze, napisy, przypisania i nazwy własnych funkcji. Ctrl+Z cofa poprawkę. Kompilator sugeruje poprawną komendę, ale nie zmienia plików automatycznie.

Silnik: rozbudowa istniejącego renderera GDI+ zamiast zmiany instalacji użytkownika. Warstwy -1000..1000 (stabilne sortowanie), przezroczystość 0..100, obrót w stopniach, skala 0.1..10, parallax 0..2, zoom 0.25..4, gradient tła, obrys, lustro sprite, cząsteczki z ograniczonym buforem, powiększenie rozdzielczości do 3840x2160. HUD niezależny od kamery. Obrót i skala są wizualne, kolizje nadal bazują na prostych figurach. Brak deklaracji akceleracji GPU.

Kontrola: testy istniejącego kompilatora/fizyki oraz nowe testy korekty, walidacji parametrów, kamery i cząsteczek. Kompilacja Windows; próba uruchomienia pod Wine, a ograniczenia weryfikacji opisane w wydaniu. Dostawa: ZIP Windows, EXE, źródła, aktualne komendy i krótka instrukcja.
