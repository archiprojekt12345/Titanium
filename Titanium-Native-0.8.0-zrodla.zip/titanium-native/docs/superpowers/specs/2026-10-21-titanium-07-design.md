# Titanium 0.7.0

Zamówienie: prosty język do gier i aplikacji, obsługa niskiego poziomu, usunięcie przycięć edytora i rozbudowany ciemny interfejs.

W tej wersji niski poziom oznacza nazwane bufory bajtowe i 32-bitowe operacje bitowe; bez obietnicy wykonywania inline C/assemblera. Bufory do 64 KiB, maksymalnie 16, zakresy sprawdzane. Nowe literały 0x/0b ułatwiają pracę z bitami.

Aplikacja ma okno oraz kontrolki: przycisk, pole, notatnik, etykieta, wybór. Odczyt wartości i zdarzeń przez proste polecenia. Pętla zawsze obsługuje grę albo aplikację. Eksport aplikacji tworzy GUI EXE. Dane modelu oddzielone od Win32, testy na fałszywym hoście. W Windows aplikacja otwiera osobne okno, Stop zamyka cały proces potomny.

Przycięcia: w 0.6 każdy WM_KEYUP wymuszał ponowne pobranie całego dokumentu i formatowanie przez zmianę zaznaczenia każdego tokenu. Nowy edytor pobiera ograniczony wycinek widocznego kodu, koloruje zakresami TOM bez ruszania zaznaczenia, ogranicza pracę na jeden przebieg i ignoruje niezmienione widoki. Uzupełnianie czyta tylko aktualny wiersz. Pełny tekst pobierany przy zapisie/kompilacji i sprawdzaniu własnych funkcji.

Ciemny interfejs obejmuje całą powierzchnię klienta, kontrolki i listy, a obsługiwane Windows dostają ciemny pasek tytułu. Większy edytor, przeciągany podział kod/podgląd, zwijane panele, tryb skupienia, powiększanie czcionki, wyszukiwanie Ctrl+F i szablony nowej gry/aplikacji. Systemowe dialogi pozostają systemowe.

Weryfikacja: stare gry i 27 testów plus nowe testy niskiego poziomu, modelu aplikacji, literałów i planowania pracy edytora. Kompilacja Windows x64. W tym środowisku uruchomienie Wine/Xvfb zablokowane przez gniazda Unix; bez deklaracji zaliczonego testu GUI.
