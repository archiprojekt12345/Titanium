# Titanium 0.8.0 — remont

Cel użytkownika: naprawić pusty/niesprawny edytor, całkowicie odnowić układ, zachować polecenia wcześniejszych wersji i pokazać grafikę.

Dowód: zrzut 0.7.0 pokazuje pustą powierzchnię edytora i rozległe niewykorzystane panele. Nie dowodzi, czy źródło było puste. Nie przypisujemy pewnej przyczyny bez natywnego uruchomienia. Wymiana modułu usuwa zależność renderowania tekstu od RichEdit/TOM. Dane źródła korzystają z jednej jawnej ścieżki get_text/set_text, a ładowanie nie usuwa wcięć. Domyślnie autokorekta jest wyłączona; podpowiedzi pozostają dostępne.

Nowy układ: kompaktowy pasek akcji; po lewej nawigacja projektu i szablony; pośrodku dominujący edytor; po prawej wyszukiwarka komend. Podgląd i konsola są dolnym, zwijanym panelem. Pełny ekran kodu przez F11. Geometrię wylicza testowany moduł, bez ujemnych rozmiarów i nakładania obszarów przy minimalnym oknie. Menu otwierane przyciskiem usuwa biały pas standardowego menu.

Zgodność: porównanie rejestru i historycznych przykładów z 0.5–0.7; przywrócenie ewentualnych kolizji nowych nazw z dawnymi funkcjami użytkownika. Źródła 0.1/0.2 zostaną zbadane; deklaracja zgodności musi rozróżniać natywny język i dawny silnik przeglądarkowy, jeśli ich semantyka różni się zasadniczo. Bez nieudowodnionego zapewnienia 100% dla wszystkich programów.

Grafika: nowe poświaty, światła, smugi i drganie kamery, z neutralnymi domyślnymi wartościami zachowującymi stare rysowanie/fizykę. Pokaz z kompozycją neonowego świata, ruchem, paralaksą, cząsteczkami i sterowaniem. Ograniczone bufory i walidowane parametry. Nie deklarujemy GPU ani 3D.

Weryfikacja: przenośne regresje języka/silnika/aplikacji, historyczny korpus, układ paneli, natywne testy edytora skompilowane. Brak natywnego środowiska GUI oznacza jawne ograniczenie weryfikacji.
