# Titanium Native 0.5.0 Implementation Plan

Goal: proste platformowki bez recznej obslugi delta.
Architecture: rejestr komend + przenosna fizyka + natywny renderer Win32.
Tech stack: C11, GDI+, Python release tooling.
Spec: docs/design-05.md.

## Constraints
ASCII command names, flat examples, backward compatibility, no browser runtime.

## Review focus
Thin walls at high speed; held/queued jump; deleting a camera target;
recreating a HUD label each frame; invalid values must not partially mutate state.

## Tasks
1. Add tests/platformer.c with expected commands and physics behavior. Run RED.
2. Extend game.h; add physics.c/.h; register/validate new commands. Run GREEN
   plus existing portable tests. Preserve drawing/controller state on updates.
3. Extend renderer for world camera, HUD, horizontal sprite strips. Add example
   9 simple platformer and 10 complete playable level; run compiler integration.
4. Bump VERSION to 0.5.0; update build/test/release paths; generate reference,
   beginner guide and demo EXE. Run full suite, sanitizer and Windows cross-build.
5. Independent final review, address significant defects, persist all artifacts.

## Progress
- Design and scope recorded. Existing local project matches current 0.4.1 files.
- Execution inline; user explicitly requested implementation and engine expansion.
- Physics, command validation, camera and animation implemented. New tests saw
  missing sciana RED, followed by GREEN. Diagonal/live-contact/mode/seam issues
  reproduced and fixed with regression tests.
- Independent review complete: three important findings fixed, no deferred minors.
- All 27 Python tests plus C suites and 100000-frame integration pass.
- Example10 won through normal keyboard input at 30/60/120FPS; loss path passes.
- ASan/UBSan platformer pass, Windows cross-build pass. GUI still untested.
