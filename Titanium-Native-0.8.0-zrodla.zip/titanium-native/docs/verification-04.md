# Titanium Native 0.4 - verification 2026-10-19

Windows x64 cross-build: PASS using build.py and Zig 0.13. PE GUI editor imports only Windows system libraries, including GDI+ and UCRT. Console exports preserve the source package and set PE CUI3. No WebView2 or browser components.

Portable test.py: 26 Python tests PASS, text normalization fixture PASS, comprehensive game_core fixture PASS, compiler+game integration fixture PASS including both shipped 2D games and 100000 frame GC test (live memory below3MB). Reference equality test proves shipped KOMENDY-TITANIUM.txt is byte-for-byte output of actual C registry. ZIP CRC checks PASS.

ASan/UBSan integration: both shipped games and 100000 frame memory test PASS. Nine simplified-syntax tests PASS under ASan/UBSan. LeakSanitizer is disabled because this execution environment blocks its /proc inspection; no leak-test claim is made.

Fresh independent review found three parser ambiguities: builtin names hijacking variables, loop variable i interpreted as AND in command arguments, and grouped first argument being mistaken for a complete legacy call. Each finding was reproduced with failing tests, fixed, and covered by green tests. Global/parameter bindings now win over inferred prefix calls. Explicit parenthesized calls remain available when a builtin name is shadowed. Space-separated commands permit grouped first arguments and preserve legacy call syntax.

Game model and renderer were implemented independently against fixed game.h/view.h contracts, then reviewed and integrated. Two model contract mismatches (window dimensions and clamping stationary/manual objects) were corrected with failing regression tests first.

The user's screenshot confirms that Native0.3 runs ordinary code on their Windows system. Native0.4 GUI and GDI+ drawing have not been run on real Windows in this environment; cross compilation and portable tests are not runtime GUI validation. Manual scenarios remain in README.
