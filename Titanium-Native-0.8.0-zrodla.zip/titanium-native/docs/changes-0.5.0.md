# Titanium Native 0.5.0

- Platformowka jedna komenda: bieg, skok spacja, grawitacja i kolizje.
- Sciany i jednostronne platformy, regulacja biegu/skoku/grawitacji.
- Ciagly ruch predkosc bez delta; fizyka prostokatow i obrazow.
- Ciagle kolizje AABB z poslizgiem, podkroki do 1/120 s.
- Bufor nacisniecia skoku 0.12 s i tolerancja po zejsciu z krawedzi 0.10 s.
- Swiat wiekszy od okna, kamera sledzaca lub reczna, HUD przypiety do ekranu.
- Patrol przeciwnikow, odbicie po nadepnieciu, punkty odrodzenia.
- Animacja obrazu z poziomego paska klatek.
- Przyklady 9 i 10, samodzielny Demo-Platformowka.exe i kurs
  PLATFORMOWKA-START.txt. Komendy nadal w jednym generowanym pliku.
- Stare znaczenie przesun i delta zachowane. Brak wymaganych wciec/tabow.

W tej wersji 19 nowych komend gier. Dzwiek, edytor map, obroty i ruchome
platformy nie sa jeszcze zaimplementowane. Fizyka nie popycha innych cial
i nie naprawia obiektow poczatkowo ustawionych wewnatrz sciany.
