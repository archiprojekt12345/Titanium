# Weryfikacja Titanium 0.6.0

- Kompilacja Windows x64, Zig 0.13.0: PASS, bez ostrzeżeń.
- `python3 test.py`: PASS, 27 testów Python i 7 grup testów C.
- Nowe testy C: autokorekta i podpowiedzi, funkcje z wielkimi i polskimi literami, brak modyfikacji przypisań, sortowanie warstw, transformacje, HUD, zoom, walidacja i wygaszanie cząsteczek.
- Zgodność: poprzednie gry, przejście poziomu 30/60/120 FPS, 100000 klatek z kontrolą pamięci.
- AddressSanitizer i UndefinedBehaviorSanitizer dla modułów assist/graphics: PASS z wyłączonym LeakSanitizer. LeakSanitizer nie działa w tym środowisku (brak odczytu /proc/task); test 100000 klatek pozostaje osobnym sprawdzeniem stabilności pamięci VM.
- Kompilacja Windows-specific `tests/editor_windows.c`: PASS. Uruchomienie pod Wine/Xvfb: niedostępne, środowisko blokuje gniazda Unix. Brak potwierdzonego testu GUI.
- Niezależny przegląd kodu: poprawiono ryzyka nazw zmiennych/funkcji, starych zakresów podpowiedzi i niedopuszczalny tryb gradientu GDI+.

Do weryfikacji w Windows: otwieranie i zapis polskich znaków, F5/Stop, lekcja 11, Ctrl+Spacja/Tab, cofanie Enter i autokorekty, przewijanie i kolorowanie, eksport EXE z assetami.
