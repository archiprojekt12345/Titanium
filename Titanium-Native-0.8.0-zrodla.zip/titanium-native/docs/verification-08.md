# Weryfikacja Titanium Studio 0.8.0 — 21.10.2026

- Pełna kompilacja Windows x64 przez Zig: PASS, bez ostrzeżeń.
- `python3 test.py`: PASS, 37 testów Python oraz przenośne testy C języka, modeli aplikacji, grafiki, fizyki, tekstu, układu i pakowania.
- Niezmienione sygnatury komend z rzeczywistych paczek 0.5.0, 0.6.0 i 0.7.0: PASS. Wszystkie 35 archiwalnych przykładów kompiluje się bez zmian. Archiwalne gry 07–11 dodatkowo wykonano z testowym hostem klatek.
- Historyczne literały `0x100000000` i `0x1p2` pozostają poprawne. Operacje bitowe nadal sprawdzają zakres uint32.
- Funkcje użytkownika zachowują nazwy pokrywające się z nowymi komendami. Pętla `zawsze` ma osobną instrukcję ramki: funkcja użytkownika `klatka` nie przechwytuje obsługi silnika. Test najpierw odtworzył błąd, a po poprawce przeszedł.
- `node compatibility/verify.cjs`: PASS, 54 oryginalne testy 0.1/0.2, sumy niezmienionych silników, detekcja składni i bezpieczne osadzenie źródła w HTML.
- Pamięć VM: 100000 klatek gry i aplikacji. Platformówka: wygrana przy 30/60/120 FPS oraz przegrana przy 60 FPS.
- Nowa grafika: limity parametrów, NaN, wygasanie i pojemność smug, stabilny HUD i wizualny wstrząs. Stan silnika pozostaje strukturą danych bez zasobów renderera.
- `tests/editor_windows.c`: kompilacja Windows z `-Werror` PASS. Test obejmuje pełny odczyt, Unicode, schowek, wyszukiwanie, dokument 250000 znaków, pozycje >65535 i podpowiedzi. Nie został uruchomiony.
- Niezależny przegląd nie wykazał potwierdzonej regresji Important/Critical dla programów przyjmowanych przez 0.7. Dwie uwagi do nowej wersji (wewnętrzna ramka i przycisk na małym oknie) poprawiono przed ostatnią kompilacją.

## Pokaz

`NEON-HARBOR-preview.png` przedstawia stan rzeczywistego modelu gry po około 10 sekundach, narysowany przenośnym rendererem Pillow/NumPy. Nie jest zrzutem Windows ani dowodem jakości natywnego renderera GDI+. Narzędzia odtworzenia: `tools/showcase_capture.c`, `tools/render_showcase.py`. Interaktywny pokaz Windows to `NEON-HARBOR.exe`, z folderem `assety` obok.

## Granice weryfikacji

Środowisko nie uruchamia interfejsu Windows. Nie potwierdzono wizualnie nowego układu, działania schowka/Undo/fokusu, płynności edytora ani efektów GDI+ na docelowym komputerze. Zrzut pustego edytora uzasadniał wymianę RichEdit/TOM, ale nie odtworzono jego przyczyny. Sprawdzenie korpusu nie dowodzi zgodności 100% wszystkich możliwych programów. Wersje 0.1/0.2 uruchamiają oryginalny język w przeglądarce i eksportują HTML, a natywna wersja eksportuje EXE.
