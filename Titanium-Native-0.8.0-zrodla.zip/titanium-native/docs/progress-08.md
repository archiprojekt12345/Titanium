# Titanium 0.8

Zakończono wymianę edytora, nowy układ Studio, zachowanie wcięć i pełnego tekstu, korpus zgodności 0.5/0.6/0.7 i oryginalne silniki przeglądarkowe 0.1/0.2. Dodano światła, poświaty, smugi, wstrząsy, sin/cos i pokaz NEON HARBOR. Zachowano aplikacje, bufory bajtów i operacje bitowe z 0.7.

Wykryte podczas przeglądu konflikty nazw funkcji, historyczne literały hex i wewnętrzną ramkę animacji poprawiono z testami regresji. Ograniczenia edytora (brak kolorowania i jeden poziom Undo) są jawne. Autokorekta jest opcjonalna i domyślnie wyłączona.

Wyniki i zakres testów: verification-08.md. Windows GUI pozostaje nieuruchomione; brak deklaracji uniwersalnej zgodności lub zmierzonej płynności.
