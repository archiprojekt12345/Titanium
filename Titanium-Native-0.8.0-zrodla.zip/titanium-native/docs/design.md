# Titanium Native 0.3 — wersja do nauki

Cel: natywna aplikacja Windows x64 z prostym szarym interfejsem, edytorem i konsolą. Jeden EXE, bez WebView2, przeglądarki, Node, Pythona i instalatora. Zachowujemy polskie polecenia Titanium w zakresie konsolowym; moduł gier graficznych z wersji 0.2 pozostaje osobną edycją.

Własny kompilator C zamienia kod na instrukcje maszyny wirtualnej. Natywna maszyna wykonuje liczby, tekst, zmienne, warunki, pętle, funkcje i wejście/wyjście. Eksport EXE zawiera ten sam natywny silnik i źródło użytkownika; nie jest kompilacją do bezpośrednich instrukcji procesora.

Widok: menu, szare przyciski Nowy/Otwórz/Zapisz/Sprawdź/Uruchom/Stop/Zbuduj EXE; biały edytor, jasna konsola poniżej, pole odpowiedzi i Wyślij. F5 uruchamia. Błędy podają numer wiersza. Program działa w procesie potomnym, więc nieskończona pętla nie blokuje edytora. Stop kończy wyłącznie własny proces potomny.

Pliki UTF-8 .ti, ostrzeganie przed utratą zmian, przykłady i krótka instrukcja nauki. Eksport tworzy samodzielny konsolowy program EXE.

Weryfikacja: przenośne testy zachowania kompilatora i VM, wejścia z konsoli, błędów, limitów, pakowania, kompilacja Windows x64 i analiza zależności. Uruchomienie okna w prawdziwym Windows wymaga potwierdzenia na Windows; nie przedstawiamy testów Linux jako testu natywnego GUI.
