# Titanium Native 0.4

User goal: one consistent, simple ASCII command language, a complete file listing only implemented commands, a native 2D preview enabled by `wywolaj 2D`, and adjacent `assety` folder. Existing gray Windows editor stays.

Syntax: one command per line; whitespace-separated arguments; parentheses and comma separators optional for compatibility; no required semicolons or property dots. Single `=` compares within conditions and assigns at statement start. Named comparison words remove the need for double-character comparisons. Bare function calls in expressions use known arity; compound arguments can still use optional grouping. Official command names, UI and teaching docs use ASCII Polish. Text in programs remains UTF-8.

Registry in commands.c is the source for compiler recognition, builtin arity and the complete KOMENDY-TITANIUM.txt plus the native command viewer. No planned functions mixed into the list. Structural keywords/operators/colors/keys are documented separately inside that same file.

2D: portable game model plus native Win32/GDI+ renderer. Rectangles/circles/sprites/text, keyboard/mouse, WASD/arrow movement, collisions and frame loop. Max 128 objects; virtual scene defaults 640x360 and scales to preview. Child program publishes scene via inherited shared mapping guarded by mutex. Parent paints small preview beside console; click it to focus controls. Standalone EXE opens native 2D window. F5/Stop and console remain available.

Images PNG/JPG/BMP are plain files in assety alongside saved .ti; unsaved code uses assety beside compiler EXE. Only plain image filenames, no traversal. Export copies asset files beside exported EXE and never silently replaces different existing files. Example folders include matching assets.

Contracts: game.h and view.h. Root integrates language/VM/editor; independent game model and renderer work against these interfaces without modifying shared files.

Tests: syntax and real programs, registry/doc parity, headless game geometry/input/state, image path rules, packaging/PE checks, sanitizer execution, Windows cross compilation. Real Windows rendering remains a separate unverified condition until observed on Windows.
