# Titanium Native 0.6.0

Nowy interfejs Studio: biblioteka komend z wyszukiwaniem i opisem, ciemny edytor RichEdit z kolorowaniem widocznych wierszy, numeracja, osobny podgląd i konsola. Przycisk Uruchom wyróżniony; eksport EXE pozostaje dostępny.

Podpowiedzi: wpisz co najmniej dwie litery lub Ctrl+Spacja, wybierz strzałkami i zatwierdź Tab. Tab nie tworzy wcięcia. Escape zamyka listę. Biblioteka po lewej wstawia samą nazwę polecenia — argumenty piszesz sam.

Autokorekta po Enter poprawia tylko jednoznaczne literówki pierwszego polecenia. Nie poprawia napisów, komentarzy, przypisań i zdefiniowanych funkcji. Można ją wyłączyć w Program > Autokorekta poleceń. Ctrl+Z cofa wpisany Enter, kolejne Ctrl+Z — poprawkę. Pliki wczytane z dysku i kompilator nie są po cichu zmieniane. Przy nieznanym poleceniu kompilator podaje sugestię, jeśli dopasowanie jest jednoznaczne.

Silnik 2D: warstwy, obrót, skala wizualna, przezroczystość, paralaksa, zoom kamery, obrysy figur, lustrzane sprite'y, gradient tła i cząsteczki. Powtórne wykorzystanie bufora obrazu zamiast tworzenia dużej bitmapy w każdej klatce. Dopuszczalna scena do 3840×2160. HUD zachowuje rozmiar przy zoomie i jest nad cząsteczkami. Warstwy są sortowane osobno w świecie i HUD; cząsteczki są nad światem. Rotacja/skala nie zmieniają kolizji.

Przykłady > 11. Nowy wymiar 2D pokazuje nowe efekty, kamerę i platformówkę. Nadal działają poprzednie lekcje i eksportowane gry.

To rozwinięcie natywnego renderera GDI+; nie jest to silnik 3D ani renderer GPU.
