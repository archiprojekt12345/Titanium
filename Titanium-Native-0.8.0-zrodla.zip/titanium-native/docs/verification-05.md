# Verification — Titanium Native 0.5.0

- Windows x64 cross-build: successful using Zig 0.13.0, GUI editor subsystem2.
- Portable suite: 27 Python tests pass; C text, legacy game, platformer and
  compiler integration tests pass, including 100000-frame memory test.
- Real example10 executed by compiler/VM and simulated keyboard input:
  won with 3 coins at 30/60/120 FPS (368/734/1466 frames).
  Death/game-over path also verified at 60 FPS (354 frames).
- AddressSanitizer + UndefinedBehaviorSanitizer: platformer tests pass.
  LeakSanitizer disabled because this environment blocks proc inspection.
- Independent reviewer identified diagonal tunneling, cached ground query,
  and missing gravity on mode transitions. Regression tests reproduced each
  and fixes passed. Additional floor-seam regression caught corner snagging;
  vertical tie resolution removes it while preserving diagonal CCD.
- Generated examples, reference, and packaged demo are verified by release
  tests. No indentation/tabs in teaching examples or generated reference.

Native GDI+ camera and sprite rendering, Windows dialogs, keyboard focus,
and export execution have not been exercised on an actual Windows desktop.
Portable engine tests and a successful PE build do not validate that UI.

Review decisions: no deferred important findings. Sound/map editor/moving
platforms deliberately excluded from 0.5.0 and stated in user documentation.
