# Titanium Studio 0.7.0

Cały interfejs ma ciemny motyw: okno, menu, biblioteka, przyciski i pola. Widok można zmieniać: przeciągany podział kod/podgląd, zwijana biblioteka, ukrywanie podglądu, F11 jako tryb skupienia. Ctrl+F wyszukuje w kodzie, Ctrl++/Ctrl+- zmieniają rozmiar liter, Ctrl+0 przywraca domyślny. Kategorie komend: język, gry, aplikacje, pamięć i bity.

Usunięto powtarzane formatowanie po każdym puszczeniu klawisza. Kolorowanie pobiera maksymalnie 8192 znaki widocznego fragmentu, przetwarza do 256 kolorowanych zakresów na przebieg i pomija niezmieniony widok. TOM formatuje zakresy bez przestawiania kursora. Podpowiedzi czytają bieżący wiersz, a tytuł okna aktualizuje się przy pierwszej zmianie. Widok > Kolorowanie składni pozwala wyłączyć kolorowanie.

Aplikacje: aplikacja, przycisk, pole, notatnik, etykieta, wybor, ustaw_tekst, wartosc, kliknieto, zaznaczone, ustaw_wybor, wlacz, widoczny, zamknij_aplikacje. Pętla zawsze obsługuje okno. Okno aplikacji otwiera się osobno od kompilatora. Zdarzenia przycisków są kolejkowane. Do 64 kontrolek, do 4095 bajtów tekstu na kontrolkę. Przyciski i kontrolki używają współrzędnych x y szerokość wysokość.

Pliki: czytaj_plik "nazwa.txt" i zapisz_plik "nazwa.txt" tekst. UTF-8 do 1 MB. Zapis nadpisuje istniejący plik. Nazwa względna odnosi się do folderu roboczego uruchomionego programu; pełna ścieżka wskazuje dokładne miejsce. Błąd odczytu/zapisu jest błędem programu. Eksport aplikacji tworzy plik EXE z podsystemem GUI. Wersja konsolowa pozostaje dostępna dla zwykłych programów.

Niski poziom: bufor, wpisz_bajt, bajt, rozmiar_bufora, zwolnij_bufor. Maksymalnie 16 nazwanych buforów po 65536 bajtów; indeksy od zera. Operacje bity_i, bity_lub, bity_xor, bity_nie, bity_lewo i bity_prawo pracują na nieujemnych 32-bitowych liczbach całkowitych. Przesunięcie 0..31. Dostęp poza buforem zgłasza błąd. 0xFF oznacza liczbę szesnastkową, 0b1010 binarną. To obsługa bajtów i bitów w Titanium; wykonywanie C/assemblera nie jest dostępne.

Przykłady: 12 — kalkulator, 13 — notatnik z zapisem, 14 — pamięć i bity. Plik > Nowa aplikacja okienkowa tworzy krótki program do samodzielnej rozbudowy. Stare komendy 2D i gry działają nadal.

Weryfikacja: kompilacja Windows x64 i testy przenośne. Testy natywnego interfejsu są dołączone jako źródła; nie uruchomiono ich w tym środowisku, więc płynność i wygląd na Windows wymagają sprawdzenia na docelowym komputerze.
