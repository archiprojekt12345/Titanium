# Weryfikacja Titanium Studio 0.7.0

- Kompilacja Windows x64 (Zig 0.13): PASS, bez ostrzeżeń.
- Pełny test.py: 32/32 testy Python i 12 grup testów C: PASS.
- Pamięć i bity: zakresy, brak dostępu poza buforem, zerowanie/reuse, uint32 i przesunięcia 0..31.
- Literały hex/binary: poprawne wartości i odrzucanie niepoprawnych cyfr/przepełnień.
- Aplikacje: model kontrolek, kolejka i ramki zdarzeń, odczyt tekstów jako niezależne migawki, klasyfikacja GUI, 100000 klatek ze stabilnym limitem pamięci.
- Przykłady kalkulatora i notatnika: kompilacja i 10 klatek przez testowego hosta.
- Pliki: odczyt/zapis UTF-8 z polską nazwą, brakujący plik.
- Edytor: test ograniczenia skanowania do 8192 znaków/256 zakresów, pomijania niezmienionego widoku i unieważniania po zmianie/scrollu. ASan/UBSan: PASS, LeakSanitizer wyłączony z powodu ograniczeń /proc środowiska.
- Gry: poprzednie przykłady, 100000 klatek VM, ukończenie platformówki przy 30/60/120 FPS.
- Niezależny przegląd: brak potwierdzonych problemów Critical/Important. Dostosowano opóźnienia natywnego testu edytora do nowego debounce 180 ms (test czeka 220 ms).
- tests/editor_windows.c i tests/app_windows.c: kompilacja Windows z -Werror PASS. Uruchomienie GUI nie zostało wykonane: środowisko blokuje gniazda Unix wymagane przez Wine/Xvfb. Brak pomiaru płynności ani wizualnego potwierdzenia na Windows.

Do sprawdzenia na Windows: wygląd menu, pasków i pól; przeciąganie podziału; F11/Ctrl+F/zoom; długie pliki/scroll/kursor/Undo; przykłady 12 i 13; wyeksportowany GUI EXE; natywna kolejka kliknięć i fokus.
