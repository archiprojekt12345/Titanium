# Titanium Native Implementation Plan

Goal: samodzielny szary edytor Titanium do nauki z konsolą Windows.
Architecture: przenośny kompilator bytecode i VM w C; Win32 controls; osobny proces dla każdego uruchomienia; źródło dołączane do eksportowanych EXE.
Tech Stack: C11, Win32, Zig cross compiler, Python unittest (tylko narzędzia budowy/testy).
Spec: design.md.

## Constraints
- Windows 10/11 x64, jeden EXE, brak WebView2.
- Kod UTF-8 do 250000 bajtów, wyraźne błędy po polsku.
- Szary interfejs, edytor, konsola, F5, Stop, wprowadzanie odpowiedzi.
- Nie deklarować testu GUI Windows bez uruchomienia na Windows.

## Review focus
- Niekompletne programy, przepełnienia parsera/stosu, błędne liczby.
- Stop podczas pytania i szybkie kolejne uruchomienia.
- Polskie znaki w kodzie, ścieżkach i wyjściu.
- Utrata niezapisanych zmian po nieudanym otwarciu.
- Uszkodzone lub ponownie eksportowane pakiety EXE.

## Tasks
1. Tests → compiler/VM: compile source to instructions; numeric/text values, Polish lexer, variables, branches, repeat/while/for, functions and builtins; tests exercise actual CLI including invalid source, bounds and stdin.
2. Native shell: Win32 edit controls and menus, save/open prompts, child pipes, input, stop; cross compile and test package structure. Interface: ti_compile/ti_execute, UTF-8 IO through FILE streams.
3. Delivery: standalone console export, six teaching examples, Polish first-run instructions; verify examples, sanitizers, PE imports and source packaging; review and save deliverables.

Progress: design grounded in user's explicit clarification; implementation proceeds autonomously under developer instructions. New isolated directory preserves preceding web edition.

Completed: all three implementation tasks; 16 portable tests plus text normalization and 11 ASan/UBSan tests pass. Windows x64 cross-build passes. Native Windows execution remains unverified; documented in verification.md and user instructions.
