# Titanium Native 0.4.1

Patch release: version names and code presentation.

- VERSION is the version source for executable labels, file properties, manifest, archive and compiler filenames, command reference and generated instructions.
- Windows distribution: Titanium-Native-0.4.1-Windows-x64.zip; compiler: Titanium-Native-0.4.1.exe; source archive: Titanium-Native-0.4.1-zrodla.zip.
- Editor Tab navigates focus instead of inserting four spaces. Loading code removes leading spaces/tabs while preserving whitespace inside text literals.
- All eight examples, the complete command reference and instructional code start at the left margin. Block structure continues to use koniec.
- Portable full suite and Windows x64 cross-build are required. Native GUI runtime remains unverified in this environment.
