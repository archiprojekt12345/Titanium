"""Portable Linux/macOS compiler and packaging checks; does not test Win32 GUI."""
import os, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
cc=os.environ.get('CC','cc')
with tempfile.TemporaryDirectory(prefix='titanium-check-') as d:
    d=Path(d)
    for test,units in [('layout08',['layout.c']),('legacy',['legacy.c']),('graphics08',['game.c','commands.c','physics.c','graphics.c']),('editor_core',['editor_core.c','commands.c']),('app',['app.c']),('lowlevel',['lowlevel.c']),('assist',['commands.c','assist.c']),('graphics06',['game.c','commands.c','physics.c','graphics.c'])]:
        binary=d/test
        subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Wno-misleading-indentation',*[str(root/'src'/u) for u in units],str(root/'tests'/(test+'.c')),'-lm','-o',str(binary)],check=True)
        subprocess.run([str(binary)],check=True)
    compiler=d/'titanium';package=d/'package';text=d/'text'
    subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Wno-misleading-indentation','-O2',
                    *[str(root/'src'/f) for f in ['compiler.c','vm.c','cli.c','commands.c','game.c','physics.c','graphics.c','assist.c','app.c','lowlevel.c','files.c']],
                    '-lm','-o',str(compiler)],check=True)
    subprocess.run([cc,'-std=c11','-Wno-misleading-indentation',str(root/'src/package.c'),
                    str(root/'tests/package_driver.c'),'-o',str(package)],check=True)
    subprocess.run([cc,'-std=c11',str(root/'tests/text.c'),'-o',str(text)],check=True)
    subprocess.run([str(text)],check=True)
    game=d/'game'
    subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Wno-misleading-indentation',str(root/'src/game.c'),str(root/'src/physics.c'),str(root/'src/graphics.c'),str(root/'src/commands.c'),str(root/'tests/game_core.c'),'-lm','-o',str(game)],check=True)
    subprocess.run([str(game)],check=True)
    platformer=d/'platformer'
    subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Wno-misleading-indentation',str(root/'src/game.c'),str(root/'src/physics.c'),str(root/'src/graphics.c'),str(root/'src/commands.c'),str(root/'tests/platformer.c'),'-lm','-o',str(platformer)],check=True)
    subprocess.run([str(platformer)],check=True)
    app_integration=d/'app-language'
    subprocess.run([cc,'-std=c11','-O2',*[str(root/'src'/f) for f in ['compiler.c','vm.c','commands.c','game.c','physics.c','graphics.c','assist.c','lowlevel.c','app.c','files.c']],str(root/'tests/app_language.c'),'-lm','-o',str(app_integration)],check=True)
    subprocess.run([str(app_integration)],check=True)
    app_examples=d/'app-examples'
    subprocess.run([cc,'-std=c11','-O2',*[str(root/'src'/f) for f in ['compiler.c','vm.c','commands.c','game.c','physics.c','graphics.c','assist.c','lowlevel.c','app.c','files.c']],str(root/'tests/app_examples.c'),'-lm','-o',str(app_examples)],check=True)
    subprocess.run([str(app_examples),str(root/'wydanie/Przyklady/12-Prosty-kalkulator.ti'),str(root/'wydanie/Przyklady/13-Moj-notatnik.ti')],check=True)
    integration=d/'game-language'  
    subprocess.run([cc,'-std=c11','-Wno-misleading-indentation','-O2',
                    *[str(root/'src'/f) for f in ['compiler.c','vm.c','commands.c','game.c','physics.c','graphics.c','assist.c','app.c','lowlevel.c','files.c']],
                    str(root/'tests/game_language.c'),'-lm','-o',str(integration)],check=True)
    games=[p for p in sorted((root/'wydanie/Przyklady').glob('*.ti')) if 7<=int(p.name[:2])<=11 or int(p.name[:2])==15]
    games.extend(p for p in sorted((root/'tests/historical').rglob('*.ti')) if p.name[:2].isdigit() and 7<=int(p.name[:2])<=11)
    subprocess.run([str(integration),*map(str,games)],check=True)
    level=d/'platform-level'
    subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Wno-misleading-indentation','-O2',
                    *[str(root/'src'/f) for f in ['compiler.c','vm.c','commands.c','game.c','physics.c','graphics.c','assist.c','app.c','lowlevel.c','files.c']],
                    str(root/'tests/platform_level.c'),'-lm','-o',str(level)],check=True)
    subprocess.run([str(level),str(root/'wydanie/Przyklady/10-Szlak-Tytana.ti')],check=True)
    env={**os.environ,'TI_TEST_EXE':str(compiler),'TI_PACKAGE_EXE':str(package)}
    subprocess.run(['python3','-m','unittest','discover','-s',str(root/'tests'),'-v'],env=env,check=True)
