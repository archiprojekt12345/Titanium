"""Build Windows x64 with Zig 0.13+ (developer tool, not needed by learners)."""
import argparse
import shutil
import subprocess
import re
from pathlib import Path

root=Path(__file__).resolve().parent
version=(root/'VERSION').read_text().strip()
if not re.fullmatch(r'\d+\.\d+\.\d+',version) or any(int(x)>65535 for x in version.split('.')):
    raise ValueError('VERSION musi miec postac major.minor.patch, kazda liczba 0..65535')
exe=f'Titanium-Native-{version}.exe'
(root/'src/version.h').write_text('#ifndef TI_VERSION_H\n#define TI_VERSION_H\n'
    f'#define TI_VERSION "{version}"\n#define TI_VERSION_W L"{version}"\n'
    f'#define TI_EXE_NAME "{exe}"\n#define TI_EXE_NAME_W L"{exe}"\n#endif\n')
for name in ['app.rc','app.manifest']:
    s=(root/'windows'/(name+'.in')).read_text()
    (root/'windows'/name).write_text(s.replace('@VERSION@',version).replace('@FILEVERSION@',version.replace('.',',')+',0').replace('@EXE@',exe))
parser=argparse.ArgumentParser()
parser.add_argument('--zig',default='zig')
args=parser.parse_args()
zig=shutil.which(args.zig) or args.zig
(root/'wydanie').mkdir(exist_ok=True)
subprocess.run([zig,'rc','/fo','app.res','app.rc'],cwd=root/'windows',check=True)
sources=['compiler.c','vm.c','cli.c','package.c','winmain.c','commands.c','game.c','physics.c','graphics.c','assist.c','app.c','lowlevel.c','files.c','editor_win.c','editor_core.c','layout.c','legacy.c','legacy_win.c','app_win.c','view.c','assets_win.c']
subprocess.run([zig,'cc','-target','x86_64-windows-gnu','-std=c11','-Wall','-Wextra',
                '-Wno-misleading-indentation',*[str(root/'src'/s) for s in sources],
                str(root/'windows/app.res'),'-o',str(root/'wydanie'/exe),
                '-municode','-Wl,--subsystem,windows','-luser32','-lgdi32','-lcomdlg32',
                '-lshell32','-lgdiplus','-ldwmapi','-luxtheme','-O2','-s'],cwd=root,check=True)
print(root/'wydanie'/exe)
