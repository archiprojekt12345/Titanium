# Titanium Native 0.8.0

Natywne Studio Windows: edytor z kolorowaniem, autokorekta i podpowiedziami, wyszukiwarka komend, konsola i podglad 2D. Polski jezyk z nazwami ASCII, argumentami rozdzielanymi spacjami i opcjonalna interpunkcja. `wywolaj 2D` wlacza scene; `zawsze ... koniec` tworzy petle klatek. Pelny spis jest generowany z rejestru w `commands.c` do `KOMENDY-TITANIUM.txt` oraz natywnego okna przycisku Komendy.

Program jest w C11: lexer UTF-8, kompilator kodu posredniego, wlasna VM, przenosny model gry i natywny renderer GDI+. Nie wymaga przegladarki, WebView2, Node, Pythona ani .NET na komputerze ucznia. Eksport EXE zawiera silnik i kod Titanium kompilowany do instrukcji VM przy starcie, a obrazy sa kopiowane do sasiedniego folderu assety. Nie jest to bezposredni kompilator do instrukcji procesora.

## Budowanie

Deweloper potrzebuje Python 3 i Zig 0.13+:

```
python build.py --zig zig
python release.py --zig zig
```

Wynik: wydanie/Titanium-Native-0.8.0.exe, Demo-Konsola.exe, Demo-2D.exe, Demo-Platformowka.exe, pietnascie lekcji, assety, instrukcje i kompletny spis komend. Wymagany Windows 10/11 x64 z systemowym UCRT i GDI+.

## Testy

Przenosny silnik (Linux/macOS z C11 i Python3):

```
python3 test.py
```

Testy: kompilator i VM, wejscie, polskie teksty i zgodnosc 0.3, uproszczona skladnia, funkcje i limity, slowne porownania, geometria, kolizje, klawisze/krawedzie nacisniec, sterowanie, walidacja assetow, pelne programy 2D przez testowy host, 100000 klatek z kontrola pamieci, autentycznosc wygenerowanego spisu wzgledem rejestru, pakowanie i naglowki PE. `release.py` generuje wlasne proste PNG do nauki.

Zrzut uzytkownika potwierdzil prace natywnego edytora 0.3. Wersja 0.8.0 jest kompilowana krzyzowo i testowana w Linux. Nowego podgladu Win32, dialogow i eksportu nie uruchomiono tutaj na Windows. Nie wolno twierdzic, ze testy przenosne potwierdzaja rysowanie GDI+ na Windows.

Do sprawdzenia Windows: przyklady 1-15; klikniecie podgladu i WASD; Escape/Stop podczas gry; ponowne F5; przytrzymanie klawiszy po utracie fokusu; pytanie w konsoli; brakujacy/uszkodzony PNG; polskie nazwy sciezek; zapis/otwarcie z potwierdzeniem zmian; eksport w nowym folderze; rozne istniejace assety; EXE uruchomiony dwuklikiem i z przekierowaniem wejscia/wyjscia.

## Pliki i zasady

`game.h`/`game.c`: model sceny, geometria i sterowanie. `physics.h`/`physics.c`: platformowki, ciagle kolizje AABB z poslizgiem, podparcie, skok, patrol i kamera. `view.h`/`view.c`: obraz/klawiatura/mysz oraz IPC z oddzielnym procesem programu. Mapa wspolna zawiera tylko dane, mutex chroni kopie sceny i wejscia, znacznik zamkniecia jest atomowy. Zabicie programu nie blokuje edytora; porzucony mutex jest obslugiwany. Automatyczny ruch i ograniczenie do ekranu dotycza obiektow ze steruj >0; steruj 0 je wylacza.

`assety` znajduje sie obok zapisanego .ti, a przy niezapisanym kodzie obok EXE kompilatora. Dozwolone proste nazwy PNG/JPG/JPEG/BMP, bez podfolderow i .. . Eksport kopiuje do 128 obrazow, 16 MB na plik, 64 MB lacznie. Nie nadpisuje roznych plikow o tej samej nazwie. Renderer ogranicza obrazy do 4096x4096 i 64 MB lacznej powierzchni RGBA na proces.

VM ogranicza kod do 250000 bajtow, wynik do 1 MB, pamiec robocza do 32 MB i instrukcje do 5000000 miedzy klatkami. Zbiera nieosiagalne teksty podczas klatek. Obiekty maja stale bufory napisow, do 128 pozycji. Polecenia czytaj_plik / zapisz_plik pozwalaja obslugiwac pliki tekstowe UTF-8. Jezyk nie udostepnia powloki ani sieci.

Format EXE pozostaje zgodny z 0.3: baza PE + zrodlo UTF-8 + 32-bajtowa stopka (16 bajtow TITANIUM-NATIVE3 bez NUL, uint64 rozmiaru bazy, uint32 rozmiaru kodu i uint32 FNV-1a). FNV wykrywa przypadkowe uszkodzenia; nie jest podpisem. Edytor ma podsystem GUI2, eksport CUI3 i moze otworzyc dodatkowe natywne okno 2D. Ponowne pakowanie nie zagniezdza poprzednich zrodel.

## Nowosci 0.5.0

`platformowka gracz` wlacza strzalki/A/D, pojedynczy skok spacja i fizyke.
`sciana ziemia` oraz `platforma polka` okreslaja nieruchome przeszkody.
`predkosc pocisk 300 0` utrzymuje ruch bez mnozenia przez delta.
`swiat`, `kamera`, `przypnij` obsluguja poziom wiekszy od okna i HUD.
`patrol`, `odrodzenie`, `odrodz`, `odbij` ulatwiaja przeciwnikow i checkpointy.
`animuj obraz 4 8` czyta poziomy pasek rownych klatek.

Fizyka pracuje w podkrokach <=1/120 s i uzywa swept AABB z poslizgiem, zeby
szybkie cialo nie przeskakiwalo przez cienka przeszkode, takze po skosie.
Bufor skoku 0.12 s, tolerancja krawedzi 0.10 s. Rozmiar swiata do 100000x100000.
Kolizje cial fizycznych sa prostokatne; kola pozostaja sensorami dotyka.
Brak popychania cial, ruchomych platform, obrotow, dzwieku i edytora map.
Nie umieszczaj ciala wewnatrz sciany: silnik nie wypycha poczatkowych nakladan.
Pozycja/odrodz zeruja predkosci ciala; przesun pozostaje natychmiastowym ruchem.
Modele fizyka/platformowka/patrol wlaczaja grawitacje 900: modyfikuj ja PO
aktywacji trybu. Przypnij wylacza fizyke i zachowuje animacje.
Przypiete obiekty nie uczestnicza w dotyka. Mysz_x/y sa pozycja na ekranie,
wiec dla punktu swiata po przewinieciu trzeba uwzglednic pozycje kamery.

Testy dodatkowe: ladowanie i sufit, cienkie sciany pionowo i po skosie, laczenia
podlog, bufory skoku, brak drugiego skoku, 30/60/120FPS, patrol, odradzanie,
zywe zapytanie o podparcie, kamera po usunieciu celu, animowane/powtarzane HUD.

## Nowosci 0.6.0

Biblioteka komend po lewej, kod z numerami wierszy i kolorowaniem po srodku, podglad i konsola po prawej. Ctrl+Spacja wywoluje podpowiedzi, strzalki wybieraja, Tab wstawia, Escape zamyka liste. Autokorekta po Enter poprawia jednoznaczne literowki pierwszego polecenia. Program > Autokorekta polecen wylacza ja. Ctrl+Z cofa Enter, kolejne Ctrl+Z poprawke. Napisow, komentarzy, przypisan i nazw zadeklarowanych funkcji nie poprawia.

Nowe komendy: warstwa, obrot, skala, przezroczystosc, paralaksa, lustro, obrys, zoom, gradient, czasteczki. Przyklady > 11: Nowy wymiar 2D. Wiecej: NOWOSCI-0.6.0.txt. Limit sceny 3840x2160; limit 128 obiektow i 512 krotko zyjacych czasteczek.

Obrot i skala sa wizualne; fizyka i dotyka uzywaja pierwotnego rozmiaru. Przezroczystosc nie wylacza kolizji. HUD jest nad czasteczkami, warstwy sortuja osobno swiat i HUD. mysz_x / mysz_y, zwracajace wspolrzedne sceny na ekranie, niezalezne od zoomu. GDI+ jest rendererem systemowym bez deklaracji akceleracji GPU.

## Nowosci 0.7.0

Pelny ciemny motyw, kategorie komend, przeciagany podzial, tryb skupienia F11, Ctrl+F, powiekszanie Ctrl++ i pomniejszanie Ctrl+-. Kolorowanie nie kopiuje calego dokumentu przy pisaniu i nie zmienia zaznaczenia. Mozna je wylaczyc w Widok.

Titanium obsluguje natywne aplikacje Windows: aplikacja, przycisk, pole, notatnik, etykieta, wybor oraz kliknieto / wartosc / ustaw_tekst. Petla zawsze obsluguje zdarzenia aplikacji. Eksport aplikacji to GUI EXE. Gry i aplikacje otwierasz osobno; nie uruchamiaj ich jednoczesnie w tym samym programie. Przyklady 12/13: kalkulator i notatnik z zapisem; 14: bufor i bity.

Niski poziom obejmuje bufory bajtow i operacje uint32. Nie wykonuje kodu C/assemblera. Wiecej: NOWOSCI-0.7.0.txt. Rozmiar edytora ograniczony do 250000 bajtow UTF-8; widoczne kolorowanie do 8192 znakow i 256 zakresow na przebieg. Systemowe dialogi pozostaja systemowe.

## Nowosci 0.8.0

Nowe Studio: projekt po lewej, duzy edytor posrodku, paleta po prawej. Podglad i konsola w dolnym, zwijanym panelu. Menu otwiera przycisk lub F10. Edytor zostal wymieniony na Unicode EDIT; bez RichEdit/TOM i kolorowania tla kodu. Wczytanie sprawdza pelny tekst i zachowuje wciecia. Podpowiedzi i wyszukiwanie pozostaja. Autokorekta domyslnie wylaczona. Natywne Undo ma jeden poziom.

Korpus zgodnosci obejmuje niezmienione przyklady i sygnatury komend 0.5/0.6/0.7. Funkcje uzytkownika maja pierwszenstwo przed nowszymi wbudowanymi nazwami. Starszy przegladarkowy jezyk 0.1/0.2 ma oryginalny tryb zgodnosci w folderze compatibility; uruchomienie lokalnie w przegladarce, eksport HTML. Natywne 0.3+ eksportuje EXE. Dla niejednoznacznego starego pliku wybierz silnik klasyczny w Menu > Program.

Pokaz silnika: NEON-HARBOR.exe lub Przyklady > 15. Nowe komendy poswiata / swiatlo / smuga / wstrzas, funkcje sin / cos. Pelny opis NOWOSCI-0.8.0.txt. Native GUI wymaga sprawdzenia na Windows.
